<?php

declare(strict_types=1);

namespace InzeOwr\RcAuth;

use pocketmine\plugin\PluginBase;
use pocketmine\player\Player;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\utils\Config;
use pocketmine\scheduler\Task;
use jojoe77777\FormAPI\CustomForm;

class Main extends PluginBase implements Listener {

    private Config $db;
    private Config $logs;
    private Config $bans;
    private array $authenticated = [];
    private array $loginAttempts = [];
    private array $authTasks = [];

    public function onEnable(): void {
        @mkdir($this->getDataFolder());
        $this->db = new Config($this->getDataFolder() . "database.yml", Config::YAML);
        $this->logs = new Config($this->getDataFolder() . "logs.yml", Config::YAML);
        $this->bans = new Config($this->getDataFolder() . "temp_bans.yml", Config::YAML);
        
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
        $this->getLogger()->info("§aRcAuth успешно запущен! Автор: §eImpotary");
    }

    public function getMskTime(): string {
        $date = new \DateTime("now", new \DateTimeZone("Europe/Moscow"));
        return $date->format("d.m.y — H:i:s");
    }

    public function addLog(string $nick, string $action, string $ip): void {
        $nick = strtolower($nick);
        $currentLogs = $this->logs->get($nick, []);
        $currentLogs[] = "§7[" . $this->getMskTime() . "] §f$action §7(IP: $ip)";
        $this->logs->set($nick, $currentLogs);
        $this->logs->save();
    }

    public function onJoin(PlayerJoinEvent $event): void {
        $player = $event->getPlayer();
        $nick = strtolower($player->getName());
        $ip = $player->getNetworkSession()->getIp();

        // Проверка временного бана по IP (5 минут)
        if ($this->bans->exists($ip)) {
            $unbanTime = $this->bans->get($ip);
            if (time() < $unbanTime) {
                $wait = $unbanTime - time();
                $player->kick("§cRussianCraft: Вы заблокированы за подбор пароля!\n§7Попробуйте снова через: §e" . $wait . " сек.");
                return;
            } else {
                $this->bans->remove($ip);
                $this->bans->save();
            }
        }

        $this->loginAttempts[$nick] = 3;

        // Таймер на 60 секунд (Лимит на вход)
        $task = new class($this, $player) extends Task {
            public function __construct(private Main $plugin, private Player $player) {}
            public function onRun(): void {
                if ($this->player->isOnline() && !$this->plugin->isAuthenticated($this->player)) {
                    $this->player->kick("§cRcAuth: Время на авторизацию (1 минута) истекло!");
                }
            }
        };
        $this->getScheduler()->scheduleDelayedTask($task, 20 * 60);
        $this->authTasks[$nick] = $task;

        $player->sendMessage("§l§fДобро пожаловать, §e" . $player->getName());

        if (!$this->db->exists($nick)) {
            $this->sendRegisterForm($player);
        } else {
            $data = $this->db->get($nick);
            if ($data["ip"] === $ip) {
                $this->authenticatePlayer($player, "Вход выполнен по IP");
            } else {
                $this->sendLoginForm($player);
            }
        }
    }

    public function isAuthenticated(Player $player): bool {
        return isset($this->authenticated[strtolower($player->getName())]);
    }

    private function authenticatePlayer(Player $player, string $logMsg): void {
        $nick = strtolower($player->getName());
        $this->authenticated[$nick] = true;
        if (isset($this->authTasks[$nick])) {
            $this->authTasks[$nick]->getHandler()->cancel();
            unset($this->authTasks[$nick]);
        }
        $this->addLog($nick, $logMsg, $player->getNetworkSession()->getIp());
        $player->sendMessage("§a[✔] Авторизация успешна. Приятной игры!");
    }

    public function sendRegisterForm(Player $player): void {
        $form = new CustomForm(function (Player $player, ?array $data) {
            if ($data === null) {
                $player->kick("§cРегистрация обязательна!");
                return;
            }

            // Исправлены индексы (удален Label)
            $login = $data[0];
            $pass = $data[1];
            $confirm = $data[2];
            $gmail = $data[3] ?? "none";

            if (strlen($pass) < 4) {
                $player->sendMessage("§cСлишком короткий пароль!");
                $this->sendRegisterForm($player);
                return;
            }

            if ($pass !== $confirm) {
                $player->sendMessage("§cПароли не совпадают!");
                $this->sendRegisterForm($player);
                return;
            }

            $this->db->set(strtolower($player->getName()), [
                "login" => $login,
                "password" => password_hash($pass, \PASSWORD_DEFAULT),
                "gmail" => ($gmail !== "") ? base64_encode($gmail) : "none",
                "ip" => $player->getNetworkSession()->getIp()
            ]);
            $this->db->save();

            $this->authenticatePlayer($player, "Первичная регистрация");
        });

        $form->setTitle("§l§9RussianCraft §r| §9РЕГИСТРАЦИЯ");
        // addLabel удален для исправления ошибки "Expected 5, got 4"
        $form->addInput("§l§eВаш Логин §9 | §6Логин лучше\n §l§aвсего создавать не похожий на пароль ник\n\n§cПридумайте данные для защиты:", "Придумайте логин");
        $form->addInput("§l§eВаш Пароль", "Придумайте пароль");
        $form->addInput("§l§eПовторите Пароль", "Повторите пароль");
        $form->addInput("§l§eПочта (необязательно)", "Ваш gmail");
        $player->sendForm($form);
    }

    public function sendLoginForm(Player $player, string $error = ""): void {
        $form = new CustomForm(function (Player $player, ?array $data) {
            if ($data === null) {
                $player->kick("§cАвторизуйтесь!");
                return;
            }

            $nick = strtolower($player->getName());
            // Исправлен индекс (удален Label)
            $pass = $data[1];
            $stored = $this->db->get($nick);

            if (password_verify($pass, $stored["password"])) {
                $stored["ip"] = $player->getNetworkSession()->getIp();
                $this->db->set($nick, $stored);
                $this->db->save();
                $this->authenticatePlayer($player, "Успешный вход по паролю");
            } else {
                $this->loginAttempts[$nick]--;
                $rem = $this->loginAttempts[$nick];
                if ($rem <= 0) {
                    $ip = $player->getNetworkSession()->getIp();
                    $this->bans->set($ip, time() + 300);
                    $this->bans->save();
                    $this->addLog($nick, "§cБАН IP (3 ошибки)", $ip);
                    $player->kick("§cВы ввели неверный пароль 3 раза!\n§7Ваш IP заблокирован на 5 минут.");
                    return;
                }
                $this->sendLoginForm($player, "§c❌ Неверный пароль! Осталось попыток: §e$rem");
            }
        });

        $form->setTitle("§l§6RussianCraft §r| §9");
        // addLabel удален. Текст ошибки перенесен в название первого поля, чтобы не ломать индексы.
        $msg = $error !== "" ? $error . "\n" : "§l§fВведите данные для входа в систему:\n";
        $form->addInput($msg . "§l§eЛогин", "Ваш логин");
        $form->addInput("§l§eПароль", "Ваш пароль");
        $player->sendForm($form);
    }

    public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool {
        if ($command->getName() === "rcauthlog") {
            if (!$sender->hasPermission("rcauth.admin")) {
                $sender->sendMessage("§cУ вас нет прав!");
                return true;
            }
            if (!isset($args[0])) {
                $sender->sendMessage("§eИспользование: /paauthlog <ник>");
                return true;
            }
            $target = strtolower($args[0]);
            if (!$this->logs->exists($target)) {
                $sender->sendMessage("§cЛогов для игрока §e$target §cне найдено.");
                return true;
            }
            $sender->sendMessage("§b--- История входов §e$target §b---");
            foreach (array_reverse($this->logs->get($target)) as $line) {
                $sender->sendMessage($line);
            }
            return true;
        }

        if ($command->getName() === "rcauth") {
            if (!$sender->hasPermission("rcauth.admin")) {
                $sender->sendMessage("§bPolis of Athens §7» §cУ вас недостаточно прав!");
                return true;
            }

            if (count($args) < 3) {
                $sender->sendMessage("§bRussianCraft §7» §eИспользование: /paauth <ник> <новый_пароль> <ваш_пароль>");
                return true;
            }

            $targetNick = strtolower($args[0]);
            $newPass = $args[1];
            $adminPass = $args[2];

            if ($sender instanceof Player) {
                $adminData = $this->db->get(strtolower($sender->getName()));
                if (!password_verify($adminPass, $adminData["password"])) {
                    $sender->sendMessage("§bRussianCraft §7» §cОшибка: Ваш пароль подтверждения неверен!");
                    return true;
                }
            }

            if ($this->db->exists($targetNick)) {
                $data = $this->db->get($targetNick);
                $data["password"] = password_hash($newPass, \PASSWORD_DEFAULT);
                $data["ip"] = "reset_" . time(); 
                $this->db->set($targetNick, $data);
                $this->db->save();

                $this->addLog($targetNick, "§6Пароль изменен админом §e" . $sender->getName(), "SYSTEM");
                $sender->sendMessage("§bRussianCraft §7» §aПароль для §e$targetNick §aизменен. IP сброшен.");
                
                $targetP = $this->getServer()->getPlayerExact($targetNick);
                if ($targetP !== null) {
                    unset($this->authenticated[$targetNick]);
                    $targetP->sendMessage("§6Администратор изменил ваш пароль. Войдите снова.");
                    $this->sendLoginForm($targetP);
                }
            } else {
                $sender->sendMessage("§cИгрок не найден.");
            }
            return true;
        }
        return false;
    }

    public function onMove(PlayerMoveEvent $event): void {
        if (!$this->isAuthenticated($event->getPlayer())) $event->cancel();
    }

    public function onChat(PlayerChatEvent $event): void {
        if (!$this->isAuthenticated($event->getPlayer())) $event->cancel();
    }
}