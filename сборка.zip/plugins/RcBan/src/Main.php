<?php

declare(strict_types=1);

namespace InzeOwr\RcBan;

use pocketmine\plugin\PluginBase;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerLoginEvent;
use pocketmine\player\Player;
use pocketmine\utils\Config;
use pocketmine\utils\TextFormat as TF;

class Main extends PluginBase implements Listener
{
    private Config $bansConfig;
    private Config $ipBansConfig;
    private Config $hardBansConfig;
    private Config $limitsConfig;
    private string $timezone;
    private string $datetimeFormat;

    /** @var array */
    private array $staffGroups = [];

    /** @var array */
    private array $limitedGroups = [];

    protected function onEnable(): void
    {
        $this->saveDefaultConfig();
        $this->validateConfig();

        @mkdir($this->getDataFolder() . "data/", 0777, true);

        $this->bansConfig = new Config($this->getDataFolder() . "data/bans.json", Config::JSON);
        $this->ipBansConfig = new Config($this->getDataFolder() . "data/ipbans.json", Config::JSON);
        $this->hardBansConfig = new Config($this->getDataFolder() . "data/hardbans.json", Config::JSON);
        $this->limitsConfig = new Config($this->getDataFolder() . "data/limits.json", Config::JSON);

        $this->timezone = $this->getConfig()->get("timezone", "Europe/Moscow");
        $this->datetimeFormat = $this->getConfig()->get("datetime_format", "H:i:s — d.m.Y");

        date_default_timezone_set($this->timezone);

        $this->staffGroups = $this->getConfig()->get("staff_groups", []);
        $this->limitedGroups = $this->getConfig()->get("limited_groups", []);

        $this->getServer()->getPluginManager()->registerEvents($this, $this);

        $rcGroup = $this->getServer()->getPluginManager()->getPlugin("RcGroup");
        if ($rcGroup === null || !$rcGroup->isEnabled()) {
            $this->getLogger()->warning("RcGroup не найден! Защита сотрудников и лимиты НЕ будут работать!");
        } else {
            $this->getLogger()->info(TF::GREEN . "RcGroup подключён успешно.");
        }

        $this->getLogger()->info(TF::GREEN . "RcBan v2.0 by InzeOwr загружен!");
        $this->getLogger()->info(TF::YELLOW . "Защищённые группы: " . implode(", ", $this->staffGroups));
        $this->getLogger()->info(TF::YELLOW . "Лимитированные группы: " . implode(", ", array_keys($this->limitedGroups)));

        $this->cleanExpiredBans();
    }

    private function validateConfig(): void
    {
        $config = $this->getConfig();
        $changed = false;

        $defaults = [
            "timezone" => "Europe/Moscow",
            "datetime_format" => "H:i:s — d.m.Y",
            "max_ban_time" => 0,
            "log_actions" => true,
            "broadcast_bans" => true,
            "broadcast_unbans" => true,
            "self_ban_protection" => true,
            "staff_groups" => [
                "CREATOR", "OWNER", "GLADMIN", "CURATOR",
                "SADMIN", "ADMIN", "MANAGER", "SMODER", "MODER"
            ],
            "limited_groups" => [
                "MIRAGE" => [
                    "max_bans" => 6,
                    "max_time_minutes" => 180,
                    "cooldown_hours" => 24,
                    "allowed_commands" => ["rcban", "rcunban"],
                    "can_unban_staff" => false
                ],
                "SPARK" => [
                    "max_bans" => 12,
                    "max_time_minutes" => 360,
                    "cooldown_hours" => 24,
                    "allowed_commands" => ["rcban", "rcunban"],
                    "can_unban_staff" => false
                ]
            ]
        ];

        foreach ($defaults as $key => $value) {
            if (!$config->exists($key)) {
                $config->set($key, $value);
                $changed = true;
                $this->getLogger()->warning("Ключ '$key' отсутствовал в конфиге — добавлен со значением по умолчанию.");
            }
        }

        if ($changed) {
            $config->save();
            $this->getLogger()->info(TF::GREEN . "Конфиг обновлён с недостающими ключами.");
        }
    }

    protected function onDisable(): void
    {
        $this->bansConfig->save();
        $this->ipBansConfig->save();
        $this->hardBansConfig->save();
        $this->limitsConfig->save();
    }

    // ==================== УТИЛИТЫ ====================

    private function formatTimestamp(int $timestamp): string
    {
        $dt = new \DateTime("@$timestamp");
        $dt->setTimezone(new \DateTimeZone($this->timezone));
        return $dt->format($this->datetimeFormat);
    }

    private function getTimeRemaining(int $expireTimestamp): string
    {
        $diff = $expireTimestamp - time();
        if ($diff <= 0) return "истёк";
        $days = floor($diff / 86400);
        $hours = floor(($diff % 86400) / 3600);
        $minutes = floor(($diff % 3600) / 60);
        $seconds = $diff % 60;
        $parts = [];
        if ($days > 0) $parts[] = $days . " дн.";
        if ($hours > 0) $parts[] = $hours . " ч.";
        if ($minutes > 0) $parts[] = $minutes . " мин.";
        if ($seconds > 0 && $days === 0) $parts[] = $seconds . " сек.";
        return implode(" ", $parts);
    }

    private function parseMinutes(string $input): ?int
    {
        if (!is_numeric($input)) return null;
        $val = (int)$input;
        if ($val <= 0) return null;
        $maxTime = $this->getConfig()->get("max_ban_time", 0);
        if ($maxTime > 0 && $val > $maxTime) return null;
        return $val;
    }

    private function findPlayer(string $name): ?Player
    {
        $name = strtolower($name);
        $found = null;
        $delta = PHP_INT_MAX;
        foreach ($this->getServer()->getOnlinePlayers() as $player) {
            $pName = strtolower($player->getName());
            if ($pName === $name) return $player;
            if (str_starts_with($pName, $name)) {
                $curDelta = strlen($pName) - strlen($name);
                if ($curDelta < $delta) {
                    $found = $player;
                    $delta = $curDelta;
                }
            }
        }
        return $found;
    }

    private function resolveTargetName(string $input): string
    {
        $player = $this->findPlayer($input);
        return $player !== null ? $player->getName() : $input;
    }

    private function getAdminName(CommandSender $sender): string
    {
        return $sender instanceof Player ? $sender->getName() : "Console";
    }

    private function broadcast(string $message): void
    {
        if ($this->getConfig()->get("broadcast_bans", true)) {
            $this->getServer()->broadcastMessage($message);
        }
    }

    private function broadcastUnban(string $message): void
    {
        if ($this->getConfig()->get("broadcast_unbans", true)) {
            $this->getServer()->broadcastMessage($message);
        }
    }

    private function logAction(string $message): void
    {
        if ($this->getConfig()->get("log_actions", true)) {
            $this->getLogger()->info(TF::clean($message));
        }
    }

    private function getPlayerIP(string $name): ?string
    {
        $player = $this->getServer()->getPlayerExact($name);
        if ($player !== null) {
            return $player->getNetworkSession()->getIp();
        }
        return null;
    }

    private function cleanExpiredBans(): void
    {
        $now = time();
        $cleaned = 0;
        foreach ($this->bansConfig->getAll() as $name => $data) {
            if ($data["type"] === "temp" && $data["expire"] <= $now) {
                $this->bansConfig->remove($name);
                $cleaned++;
            }
        }
        foreach ($this->hardBansConfig->getAll() as $name => $data) {
            if (isset($data["expire"]) && $data["expire"] <= $now) {
                $this->hardBansConfig->remove($name);
                $cleaned++;
            }
        }
        if ($cleaned > 0) {
            $this->bansConfig->save();
            $this->hardBansConfig->save();
        }
    }

    // ==================== RcGroup ИНТЕГРАЦИЯ ====================

    private function getRcGroup(): ?\InzeOwr\RcGroup\Main
    {
        $plugin = $this->getServer()->getPluginManager()->getPlugin("RcGroup");
        if ($plugin !== null && $plugin->isEnabled() && $plugin instanceof \InzeOwr\RcGroup\Main) {
            return $plugin;
        }
        return null;
    }

    private function getPlayerGroup(string $nickname): string
    {
        $rcGroup = $this->getRcGroup();
        if ($rcGroup === null) return "";
        return $rcGroup->getGroup($nickname);
    }

    private function isStaff(string $nickname): bool
    {
        $group = $this->getPlayerGroup($nickname);
        if ($group === "") return false;
        return in_array($group, $this->staffGroups, true);
    }

    private function getLimitedConfig(string $nickname): ?array
    {
        $group = $this->getPlayerGroup($nickname);
        if ($group === "") return null;
        if (isset($this->limitedGroups[$group]) && is_array($this->limitedGroups[$group])) {
            return $this->limitedGroups[$group];
        }
        return null;
    }

    private function isLimited(string $nickname): bool
    {
        return $this->getLimitedConfig($nickname) !== null;
    }

    // ==================== ПРОВЕРКИ ====================

    private function checkStaffProtection(CommandSender $sender, string $targetName): bool
    {
        if (!($sender instanceof Player)) return true;

        if ($this->isStaff($targetName)) {
            $sender->sendMessage("§c[RcBan] Вы не можете выдать наказание сотруднику проекта!");
            return false;
        }

        return true;
    }

    private function checkSelfBan(CommandSender $sender, string $targetName): bool
    {
        if ($this->getConfig()->get("self_ban_protection", true)) {
            if ($sender instanceof Player && strtolower($sender->getName()) === strtolower($targetName)) {
                $sender->sendMessage("§c[RcBan] Вы не можете забанить самого себя!");
                return false;
            }
        }
        return true;
    }

    private function checkBypass(CommandSender $sender, string $targetName): bool
    {
        $targetPlayer = $this->getServer()->getPlayerExact($targetName);
        if ($targetPlayer !== null && $targetPlayer->hasPermission("rcban.bypass")) {
            $sender->sendMessage("§c[RcBan] Этот игрок защищён от блокировок!");
            return false;
        }
        return true;
    }

    private function canBanTarget(CommandSender $sender, string $targetName): bool
    {
        if (!$this->checkSelfBan($sender, $targetName)) return false;
        if (!$this->checkBypass($sender, $targetName)) return false;
        if (!$this->checkStaffProtection($sender, $targetName)) return false;
        return true;
    }

    private function checkLimitedCommand(CommandSender $sender, string $commandName): bool
    {
        if (!($sender instanceof Player)) return true;

        $limitCfg = $this->getLimitedConfig($sender->getName());
        if ($limitCfg === null) return true;

        $allowed = $limitCfg["allowed_commands"] ?? [];
        if (!is_array($allowed)) return false;

        if (!in_array($commandName, $allowed, true)) {
            $sender->sendMessage("§c[RcBan] Ваша привилегия не позволяет использовать эту команду!");
            return false;
        }

        return true;
    }

    private function checkLimitedTime(CommandSender $sender, int $minutes): bool
    {
        if (!($sender instanceof Player)) return true;

        $senderName = $sender->getName();
        $limitCfg = $this->getLimitedConfig($senderName);
        if ($limitCfg === null) return true;

        $maxTime = (int)($limitCfg["max_time_minutes"] ?? 0);
        if ($maxTime <= 0) return true;

        if ($minutes > $maxTime) {
            $hours = floor($maxTime / 60);
            $mins = $maxTime % 60;
            $timeStr = "";
            if ($hours > 0) $timeStr .= $hours . " ч. ";
            if ($mins > 0) $timeStr .= $mins . " мин.";
            $sender->sendMessage("§c[RcBan] Максимальное время бана для вашей привилегии: §e" . trim($timeStr) . " §c(вы указали " . $minutes . " мин.)");
            return false;
        }

        return true;
    }

    private function checkAndUseBanLimit(CommandSender $sender): bool
    {
        if (!($sender instanceof Player)) return true;

        $senderName = $sender->getName();
        $limitCfg = $this->getLimitedConfig($senderName);
        if ($limitCfg === null) return true;

        $maxBans = (int)($limitCfg["max_bans"] ?? 0);
        $cooldownHours = (int)($limitCfg["cooldown_hours"] ?? 24);
        if ($maxBans <= 0) return true;

        $senderKey = strtolower($senderName);
        $limitsData = $this->limitsConfig->get($senderKey, null);

        if ($limitsData === null || !is_array($limitsData)) {
            $limitsData = [
                "bans_used" => 0,
                "period_start" => time()
            ];
        }

        $periodStart = (int)($limitsData["period_start"] ?? time());
        $bansUsed = (int)($limitsData["bans_used"] ?? 0);
        $cooldownSeconds = $cooldownHours * 3600;

        if ((time() - $periodStart) >= $cooldownSeconds) {
            $bansUsed = 0;
            $periodStart = time();
        }

        if ($bansUsed >= $maxBans) {
            $resetTime = $periodStart + $cooldownSeconds;
            $remaining = $this->getTimeRemaining($resetTime);
            $sender->sendMessage("§c[RcBan] Вы исчерпали лимит банов (§e" . $maxBans . "§c)! Сброс через: §e" . $remaining);
            return false;
        }

        $bansUsed++;
        $this->limitsConfig->set($senderKey, [
            "bans_used" => $bansUsed,
            "period_start" => $periodStart
        ]);
        $this->limitsConfig->save();

        $left = $maxBans - $bansUsed;
        $resetTime = $periodStart + $cooldownSeconds;
        $remaining = $this->getTimeRemaining($resetTime);
        $sender->sendMessage("§e[RcBan] Использовано банов: §c" . $bansUsed . "/" . $maxBans . "§e. Осталось: §c" . $left . "§e. Сброс через: §c" . $remaining);

        return true;
    }

    private function checkLimitedUnban(CommandSender $sender, array $banData): bool
    {
        if (!($sender instanceof Player)) return true;

        $limitCfg = $this->getLimitedConfig($sender->getName());
        if ($limitCfg === null) return true;

        $canUnbanStaff = (bool)($limitCfg["can_unban_staff"] ?? false);
        if ($canUnbanStaff) return true;

        $banAdmin = $banData["admin"] ?? "";
        if ($this->isStaff($banAdmin)) {
            $sender->sendMessage("§c[RcBan] Вы не можете снять наказание выданное сотрудником проекта!");
            return false;
        }

        return true;
    }

    /**
     * Проверка: может ли игрок снять перманентный бан
     * Только сотрудники и консоль могут снимать перманентные блокировки
     */
    private function canRemovePermBan(CommandSender $sender): bool
    {
        if (!($sender instanceof Player)) return true;

        if ($this->isStaff($sender->getName())) return true;

        $sender->sendMessage("§c[RcBan] Снятие перманентной блокировки доступно только сотрудникам проекта!");
        return false;
    }

    // ==================== СОБЫТИЯ ====================

    public function onPlayerLogin(PlayerLoginEvent $event): void
    {
        $player = $event->getPlayer();
        $name = strtolower($player->getName());
        $ip = $player->getNetworkSession()->getIp();

        // Обычный бан
        if ($this->bansConfig->exists($name)) {
            $data = $this->bansConfig->get($name);

            if ($data["type"] === "temp") {
                if (time() >= $data["expire"]) {
                    $this->bansConfig->remove($name);
                    $this->bansConfig->save();
                } else {
                    $expireStr = $this->formatTimestamp($data["expire"]);
                    $event->setKickMessage("§eВам была выдана блокировка игроком §c" . $data["admin"] . " §eпо причине: §c" . $data["reason"] . " §eдо разбана: §c" . $expireStr);
                    $event->cancel();
                    return;
                }
            }

            if ($data["type"] === "perm") {
                $event->setKickMessage("§eВам была выдана перманентная блокировка администратором §c" . $data["admin"] . " §eпо причине: §c" . $data["reason"] . " §eдо разбана: §cНикогда");
                $event->cancel();
                return;
            }
        }

        // IP бан
        foreach ($this->ipBansConfig->getAll() as $bannedName => $data) {
            if (isset($data["ip"]) && $data["ip"] === $ip) {
                $event->setKickMessage("§l§6Вы были внесены в чёрный список проекта администратором §f" . $data["admin"] . " §6по причине: §c" . $data["reason"]);
                $event->cancel();
                return;
            }
        }

        // Хард бан по нику
        if ($this->hardBansConfig->exists($name)) {
            $data = $this->hardBansConfig->get($name);
            if (isset($data["expire"]) && time() >= $data["expire"]) {
                $this->hardBansConfig->remove($name);
                $this->hardBansConfig->save();
            } else {
                if (!isset($data["ip"]) || $data["ip"] !== $ip) {
                    $data["ip"] = $ip;
                    $this->hardBansConfig->set($name, $data);
                    $this->hardBansConfig->save();
                }
                $expireStr = isset($data["expire"]) ? $this->formatTimestamp($data["expire"]) : "Никогда";
                $event->setKickMessage("§eВам была выдана хард-блокировка администратором §c" . $data["admin"] . " §eпо причине: §c" . $data["reason"] . " §eдо разбана: §c" . $expireStr);
                $event->cancel();
                return;
            }
        }

        // Хард бан по IP
        foreach ($this->hardBansConfig->getAll() as $bannedName => $data) {
            if ($bannedName === $name) continue;
            if (isset($data["ip"]) && $data["ip"] === $ip) {
                if (isset($data["expire"]) && time() >= $data["expire"]) {
                    $this->hardBansConfig->remove($bannedName);
                    $this->hardBansConfig->save();
                    continue;
                }
                $expireStr = isset($data["expire"]) ? $this->formatTimestamp($data["expire"]) : "Никогда";
                $event->setKickMessage("§eВам была выдана хард-блокировка администратором §c" . $data["admin"] . " §eпо причине: §c" . $data["reason"] . " §eдо разбана: §c" . $expireStr);
                $event->cancel();
                return;
            }
        }
    }

    // ==================== КОМАНДЫ ====================

    public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool
    {
        switch (strtolower($command->getName())) {
            case "rcban": return $this->handleBan($sender, $args);
            case "rcunban": return $this->handleUnban($sender, $args);
            case "rcpban": return $this->handlePBan($sender, $args);
            case "rcbanip": return $this->handleBanIP($sender, $args);
            case "rcunbanip": return $this->handleUnbanIP($sender, $args);
            case "rchardban": return $this->handleHardBan($sender, $args);
            case "rcunhardban": return $this->handleUnhardBan($sender, $args);
            case "rcbaninfo": return $this->handleBanInfo($sender, $args);
            case "rcbanlist": return $this->handleBanList($sender, $args);
        }
        return false;
    }

    // ===== /rcban =====
    private function handleBan(CommandSender $sender, array $args): bool
    {
        if (count($args) < 3) {
            $sender->sendMessage("§c[RcBan] Использование: /rcban <ник> <время_мин> <причина>");
            return true;
        }

        if (!$this->checkLimitedCommand($sender, "rcban")) return true;

        $targetInput = array_shift($args);
        $timeStr = array_shift($args);
        $reason = implode(" ", $args);

        $targetName = $this->resolveTargetName($targetInput);
        $targetKey = strtolower($targetName);
        $adminName = $this->getAdminName($sender);

        if (!$this->canBanTarget($sender, $targetName)) return true;

        $minutes = $this->parseMinutes($timeStr);
        if ($minutes === null) {
            $sender->sendMessage("§c[RcBan] Укажите корректное время в минутах (> 0)");
            return true;
        }

        if (empty(trim($reason))) {
            $sender->sendMessage("§c[RcBan] Укажите причину бана!");
            return true;
        }

        if (!$this->checkLimitedTime($sender, $minutes)) return true;

        if ($this->bansConfig->exists($targetKey)) {
            $existing = $this->bansConfig->get($targetKey);
            if ($existing["type"] === "perm") {
                $sender->sendMessage("§c[RcBan] Игрок " . $targetName . " уже имеет перманентную блокировку!");
                return true;
            }
        }

        if (!$this->checkAndUseBanLimit($sender)) return true;

        $expireTime = time() + ($minutes * 60);
        $expireStr = $this->formatTimestamp($expireTime);

        $banData = [
            "type" => "temp",
            "admin" => $adminName,
            "reason" => $reason,
            "time" => time(),
            "expire" => $expireTime,
            "date" => $this->formatTimestamp(time()),
        ];

        $this->bansConfig->set($targetKey, $banData);
        $this->bansConfig->save();

        $targetPlayer = $this->getServer()->getPlayerExact($targetName);
        if ($targetPlayer === null) $targetPlayer = $this->findPlayer($targetInput);
        if ($targetPlayer !== null) {
            $targetPlayer->kick("§eВам была выдана блокировка игроком §c" . $adminName . " §eпо причине: §c" . $reason . " §eдо разбана: §c" . $expireStr);
        }

        $this->broadcast("§eИгрок §c" . $adminName . " §eвыдал блокировку аккаунта игроку §c" . $targetName . " §eпричина: §c" . $reason . "§e. до разбана: §c" . $expireStr);
        $this->logAction("[RcBan] " . $adminName . " выдал блокировку " . $targetName . " на " . $minutes . " мин. Причина: " . $reason);

        return true;
    }

    // ===== /rcunban =====
    private function handleUnban(CommandSender $sender, array $args): bool
    {
        if (count($args) < 2) {
            $sender->sendMessage("§c[RcBan] Использование: /rcunban <ник> <причина> [-p]");
            return true;
        }

        if (!$this->checkLimitedCommand($sender, "rcunban")) return true;

        $targetInput = array_shift($args);
        $targetKey = strtolower($targetInput);
        $adminName = $this->getAdminName($sender);

        $removePerm = false;
        $lastArg = end($args);
        if (strtolower($lastArg) === "-p") {
            $removePerm = true;
            array_pop($args);
        }

        $reason = implode(" ", $args);

        if (empty(trim($reason))) {
            $sender->sendMessage("§c[RcBan] Укажите причину разбана!");
            return true;
        }

        if (!$this->bansConfig->exists($targetKey)) {
            $sender->sendMessage("§c[RcBan] Игрок " . $targetInput . " не забанен!");
            return true;
        }

        $banData = $this->bansConfig->get($targetKey);

        if ($banData["type"] === "perm" && !$removePerm) {
            $sender->sendMessage("§c[RcBan] Игрок " . $targetInput . " имеет перманентную блокировку! Добавьте -p в конце.");
            return true;
        }

        // Перманентный бан могут снять только сотрудники
        if ($banData["type"] === "perm" && $removePerm) {
            if (!$this->canRemovePermBan($sender)) return true;
        }

        if (!$this->checkLimitedUnban($sender, $banData)) return true;

        $previousAdmin = $banData["admin"];

        $this->bansConfig->remove($targetKey);
        $this->bansConfig->save();

        $this->broadcastUnban("§eИгрок §c" . $adminName . " §eснял блокировку аккаунта игроку §c" . $targetInput . " §eпричина: §c" . $reason);
        $this->getServer()->broadcastMessage(" - §eРанее было выдано сотрудником §c" . $previousAdmin);
        $this->logAction("[RcBan] " . $adminName . " снял блокировку " . $targetInput . ". Причина: " . $reason);

        return true;
    }

    // ===== /rcpban =====
    private function handlePBan(CommandSender $sender, array $args): bool
    {
        if (count($args) < 2) {
            $sender->sendMessage("§c[RcBan] Использование: /rcpban <ник> <причина>");
            return true;
        }

        if (!$this->checkLimitedCommand($sender, "rcpban")) return true;

        $targetInput = array_shift($args);
        $reason = implode(" ", $args);

        $targetName = $this->resolveTargetName($targetInput);
        $targetKey = strtolower($targetName);
        $adminName = $this->getAdminName($sender);

        if (!$this->canBanTarget($sender, $targetName)) return true;

        if (empty(trim($reason))) {
            $sender->sendMessage("§c[RcBan] Укажите причину бана!");
            return true;
        }

        $banData = [
            "type" => "perm",
            "admin" => $adminName,
            "reason" => $reason,
            "time" => time(),
            "expire" => -1,
            "date" => $this->formatTimestamp(time()),
        ];

        $this->bansConfig->set($targetKey, $banData);
        $this->bansConfig->save();

        $targetPlayer = $this->getServer()->getPlayerExact($targetName);
        if ($targetPlayer === null) $targetPlayer = $this->findPlayer($targetInput);
        if ($targetPlayer !== null) {
            $targetPlayer->kick("§eВам была выдана перманентная блокировка администратором §c" . $adminName . " §eпо причине: §c" . $reason . " §eдо разбана: §cНикогда");
        }

        $this->broadcast("§eАдминистратор §c" . $adminName . " §eвыдал перманентную блокировку аккаунта игроку §c" . $targetName . " §eпричина: §c" . $reason);
        $this->logAction("[RcBan] " . $adminName . " выдал перманентную блокировку " . $targetName . ". Причина: " . $reason);

        return true;
    }

    // ===== /rcbanip =====
    private function handleBanIP(CommandSender $sender, array $args): bool
    {
        if (count($args) < 2) {
            $sender->sendMessage("§c[RcBan] Использование: /rcbanip <ник> <причина>");
            return true;
        }

        if (!$this->checkLimitedCommand($sender, "rcbanip")) return true;

        $targetInput = array_shift($args);
        $reason = implode(" ", $args);

        $targetName = $this->resolveTargetName($targetInput);
        $targetKey = strtolower($targetName);
        $adminName = $this->getAdminName($sender);

        if (!$this->canBanTarget($sender, $targetName)) return true;

        if (empty(trim($reason))) {
            $sender->sendMessage("§c[RcBan] Укажите причину!");
            return true;
        }

        $ip = $this->getPlayerIP($targetName);
        if ($ip === null) {
            $sender->sendMessage("§c[RcBan] Игрок " . $targetName . " должен быть онлайн для IP-бана!");
            return true;
        }

        $banData = [
            "admin" => $adminName,
            "reason" => $reason,
            "ip" => $ip,
            "time" => time(),
            "date" => $this->formatTimestamp(time()),
        ];

        $this->ipBansConfig->set($targetKey, $banData);
        $this->ipBansConfig->save();

        foreach ($this->getServer()->getOnlinePlayers() as $online) {
            if ($online->getNetworkSession()->getIp() === $ip) {
                $online->kick("§l§6Вы были внесены в чёрный список проекта администратором §f" . $adminName . " §6по причине: §c" . $reason);
            }
        }

        $this->broadcast("§l§6Администратор §f" . $adminName . " §6внёс в чёрный список проекта аккаунт игрока §f" . $targetName . " §6причина: §c" . $reason);
        $this->logAction("[RcBan] " . $adminName . " внёс в чёрный список " . $targetName . " (IP: " . $ip . "). Причина: " . $reason);

        return true;
    }

    // ===== /rcunbanip =====
    private function handleUnbanIP(CommandSender $sender, array $args): bool
    {
        if (count($args) < 1) {
            $sender->sendMessage("§c[RcBan] Использование: /rcunbanip <ник>");
            return true;
        }

        if (!$this->checkLimitedCommand($sender, "rcunbanip")) return true;

        $targetInput = $args[0];
        $targetKey = strtolower($targetInput);
        $adminName = $this->getAdminName($sender);

        if (!$this->ipBansConfig->exists($targetKey)) {
            $sender->sendMessage("§c[RcBan] Игрок " . $targetInput . " не в чёрном списке!");
            return true;
        }

        $this->ipBansConfig->remove($targetKey);
        $this->ipBansConfig->save();

        $this->broadcastUnban("§l§6Администратор §f" . $adminName . " §6вынес из чёрного списка проекта аккаунт игрока §f" . $targetInput);
        $this->logAction("[RcBan] " . $adminName . " вынес из чёрного списка " . $targetInput);

        return true;
    }

    // ===== /rchardban =====
    private function handleHardBan(CommandSender $sender, array $args): bool
    {
        if (count($args) < 3) {
            $sender->sendMessage("§c[RcBan] Использование: /rchardban <ник> <время_мин> <причина>");
            return true;
        }

        if (!$this->checkLimitedCommand($sender, "rchardban")) return true;

        $targetInput = array_shift($args);
        $timeStr = array_shift($args);
        $reason = implode(" ", $args);

        $targetName = $this->resolveTargetName($targetInput);
        $targetKey = strtolower($targetName);
        $adminName = $this->getAdminName($sender);

        if (!$this->canBanTarget($sender, $targetName)) return true;

        $minutes = $this->parseMinutes($timeStr);
        if ($minutes === null) {
            $sender->sendMessage("§c[RcBan] Укажите корректное время в минутах!");
            return true;
        }

        if (empty(trim($reason))) {
            $sender->sendMessage("§c[RcBan] Укажите причину!");
            return true;
        }

        $ip = $this->getPlayerIP($targetName);
        if ($ip === null) {
            $sender->sendMessage("§c[RcBan] Игрок " . $targetName . " должен быть онлайн для хард-блокировки!");
            return true;
        }

        $expireTime = time() + ($minutes * 60);
        $expireStr = $this->formatTimestamp($expireTime);

        $banData = [
            "admin" => $adminName,
            "reason" => $reason,
            "ip" => $ip,
            "time" => time(),
            "expire" => $expireTime,
            "date" => $this->formatTimestamp(time()),
        ];

        $this->hardBansConfig->set($targetKey, $banData);
        $this->hardBansConfig->save();

        foreach ($this->getServer()->getOnlinePlayers() as $online) {
            if ($online->getNetworkSession()->getIp() === $ip) {
                $online->kick("§eВам была выдана хард-блокировка администратором §c" . $adminName . " §eпо причине: §c" . $reason . " §eдо разбана: §c" . $expireStr);
            }
        }

        $this->broadcast("§eАдминистратор §f" . $adminName . " §eвыдал хард-блокировку аккаунта игрока §e" . $targetName . " §eпричина: §c" . $reason . " §eдо разбана: §c" . $expireStr);
        $this->logAction("[RcBan] " . $adminName . " выдал хард-блокировку " . $targetName . " (IP: " . $ip . ") на " . $minutes . " мин. Причина: " . $reason);

        return true;
    }

    // ===== /rcunhardban =====
    private function handleUnhardBan(CommandSender $sender, array $args): bool
    {
        if (count($args) < 2) {
            $sender->sendMessage("§c[RcBan] Использование: /rcunhardban <ник> <причина>");
            return true;
        }

        if (!$this->checkLimitedCommand($sender, "rcunhardban")) return true;

        $targetInput = array_shift($args);
        $reason = implode(" ", $args);
        $targetKey = strtolower($targetInput);
        $adminName = $this->getAdminName($sender);

        if (empty(trim($reason))) {
            $sender->sendMessage("§c[RcBan] Укажите причину!");
            return true;
        }

        if (!$this->hardBansConfig->exists($targetKey)) {
            $sender->sendMessage("§c[RcBan] Игрок " . $targetInput . " не имеет хард-блокировки!");
            return true;
        }

        $banData = $this->hardBansConfig->get($targetKey);

        if (!$this->checkLimitedUnban($sender, $banData)) return true;

        $this->hardBansConfig->remove($targetKey);
        $this->hardBansConfig->save();

        $this->broadcastUnban("§eАдминистратор §f" . $adminName . " §eснял хард-блокировку аккаунта игрока §e" . $targetInput . " §eпричина: §c" . $reason);
        $this->logAction("[RcBan] " . $adminName . " снял хард-блокировку " . $targetInput . ". Причина: " . $reason);

        return true;
    }

    // ===== /rcbaninfo =====
    private function handleBanInfo(CommandSender $sender, array $args): bool
    {
        if (count($args) < 1) {
            $sender->sendMessage("§c[RcBan] Использование: /rcbaninfo <ник>");
            return true;
        }

        $targetKey = strtolower($args[0]);
        $found = false;

        $group = $this->getPlayerGroup($args[0]);
        if ($group !== "") {
            $sender->sendMessage("§e[RcBan] Группа игрока §f" . $args[0] . "§e: §c" . $group);
        }

        if ($this->bansConfig->exists($targetKey)) {
            $data = $this->bansConfig->get($targetKey);
            $found = true;
            if ($data["type"] === "temp") {
                if (time() >= $data["expire"]) {
                    $sender->sendMessage("§7[Обычный бан] Истёк");
                    $this->bansConfig->remove($targetKey);
                    $this->bansConfig->save();
                } else {
                    $sender->sendMessage("§c[Временная блокировка] §eАдминистратор: §c" . $data["admin"] . " §eПричина: §c" . $data["reason"] . " §eДо: §c" . $this->formatTimestamp($data["expire"]) . " §eОсталось: §c" . $this->getTimeRemaining($data["expire"]));
                }
            } elseif ($data["type"] === "perm") {
                $sender->sendMessage("§4[Перманентная блокировка] §eАдминистратор: §c" . $data["admin"] . " §eПричина: §c" . $data["reason"] . " §eДо: §cНикогда");
            }
        }

        if ($this->ipBansConfig->exists($targetKey)) {
            $data = $this->ipBansConfig->get($targetKey);
            $found = true;
            $sender->sendMessage("§6[Чёрный список] §eАдминистратор: §c" . $data["admin"] . " §eПричина: §c" . $data["reason"] . " §eIP: §c" . ($data["ip"] ?? "?"));
        }

        if ($this->hardBansConfig->exists($targetKey)) {
            $data = $this->hardBansConfig->get($targetKey);
            $found = true;
            if (isset($data["expire"]) && time() >= $data["expire"]) {
                $sender->sendMessage("§7[Хард-блокировка] Истёк");
                $this->hardBansConfig->remove($targetKey);
                $this->hardBansConfig->save();
            } else {
                $expireStr = isset($data["expire"]) ? $this->formatTimestamp($data["expire"]) : "Никогда";
                $sender->sendMessage("§c[Хард-блокировка] §eАдминистратор: §c" . $data["admin"] . " §eПричина: §c" . $data["reason"] . " §eIP: §c" . ($data["ip"] ?? "?") . " §eДо: §c" . $expireStr);
            }
        }

        if (!$found) {
            $sender->sendMessage("§a[RcBan] Блокировок не найдено для " . $args[0]);
        }

        return true;
    }

    // ===== /rcbanlist =====
    private function handleBanList(CommandSender $sender, array $args): bool
    {
        $page = isset($args[0]) && is_numeric($args[0]) ? max(1, (int)$args[0]) : 1;
        $perPage = 8;
        $allBans = [];

        foreach ($this->bansConfig->getAll() as $name => $data) {
            $type = $data["type"] === "perm" ? "§4ПЕРМ" : "§cВРЕМ";
            if ($data["type"] === "temp" && time() >= $data["expire"]) $type = "§7ИСТЁК";
            $allBans[] = $type . " §f" . $name . " §7| §f" . $data["admin"] . " §7| §f" . $data["reason"];
        }

        foreach ($this->ipBansConfig->getAll() as $name => $data) {
            $allBans[] = "§6IP §f" . $name . " §7| §f" . $data["admin"] . " §7| §f" . $data["reason"];
        }

        foreach ($this->hardBansConfig->getAll() as $name => $data) {
            $expired = isset($data["expire"]) && time() >= $data["expire"];
            $type = $expired ? "§7ХАРД(ист.)" : "§cХАРД";
            $allBans[] = $type . " §f" . $name . " §7| §f" . $data["admin"] . " §7| §f" . $data["reason"];
        }

        $total = count($allBans);
        $maxPage = max(1, (int)ceil($total / $perPage));
        $page = min($page, $maxPage);

        $sender->sendMessage("§e[RcBan] Список банов (стр. $page/$maxPage, всего: $total)");

        if ($total === 0) {
            $sender->sendMessage("§a Список пуст.");
        } else {
            $offset = ($page - 1) * $perPage;
            $slice = array_slice($allBans, $offset, $perPage);
            $i = $offset + 1;
            foreach ($slice as $line) {
                $sender->sendMessage("§f" . $i . ". " . $line);
                $i++;
            }
        }

        return true;
    }
}