<?php
declare(strict_types=1);

namespace InzeOwr\RcBus;

use pocketmine\plugin\PluginBase;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\utils\Config;
use pocketmine\scheduler\ClosureTask;
use pocketmine\entity\EntityDataHelper;
use pocketmine\entity\EntityFactory;
use pocketmine\entity\Human;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\world\World;
use pocketmine\world\particle\FloatingTextParticle;
use pocketmine\world\particle\DustParticle;
use pocketmine\color\Color;
use pocketmine\math\Vector3;
use pocketmine\event\Listener;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\player\PlayerJoinEvent;
use onebone\economyapi\EconomyAPI;
use InzeOwr\RcBus\entity\ManagerNPC;
use InzeOwr\RcBus\entity\ShopNPC;
use InzeOwr\RcBus\form\BusinessForms;
use InzeOwr\RcBus\shop\ShopCatalog;

class Main extends PluginBase implements Listener
{
    private static Main $instance;
    private Config $businessData;
    private array $floatingTexts = [];
    private array $cooldown = [];
    private BusinessForms $forms;
    private int $particleTick = 0;

    public function onEnable(): void
    {
        self::$instance = $this;
        @mkdir($this->getDataFolder());

        $this->businessData = new Config($this->getDataFolder() . "businesses.json", Config::JSON);

        $this->forms = new BusinessForms($this);

        EntityFactory::getInstance()->register(ManagerNPC::class, function (World $world, CompoundTag $nbt): ManagerNPC {
            return new ManagerNPC(EntityDataHelper::parseLocation($nbt, $world), Human::parseSkinNBT($nbt), $nbt);
        }, ["ManagerNPC"]);

        EntityFactory::getInstance()->register(ShopNPC::class, function (World $world, CompoundTag $nbt): ShopNPC {
            return new ShopNPC(EntityDataHelper::parseLocation($nbt, $world), Human::parseSkinNBT($nbt), $nbt);
        }, ["ShopNPC"]);

        $this->getServer()->getPluginManager()->registerEvents($this, $this);

        $this->getScheduler()->scheduleRepeatingTask(new ClosureTask(function (): void {
            $this->checkRentExpiry();
            $this->checkDeliveries();
        }), 20 * 60);

        $this->getScheduler()->scheduleRepeatingTask(new ClosureTask(function (): void {
            $this->generatePassiveIncome();
            $this->checkWeeklyReset();
        }), 20 * 300);

        $this->getScheduler()->scheduleRepeatingTask(new ClosureTask(function (): void {
            $this->recreateAllFloatingTexts();
        }), 20 * 180);

        $this->getScheduler()->scheduleRepeatingTask(new ClosureTask(function (): void {
            $this->spawnNPCParticles();
        }), 15);

        $this->loadFloatingTexts();

        $this->getLogger()->info("§l§aRcBus загружен успешно! Автор: InzeOwr | Формы: jojo");
    }

    public function onDisable(): void
    {
        $this->businessData->save();
    }

    public static function getInstance(): Main
    {
        return self::$instance;
    }

    public function getBusinessData(): Config
    {
        return $this->businessData;
    }

    public function getForms(): BusinessForms
    {
        return $this->forms;
    }

    /* ============================================================
     *  NPC PARTICLES
     * ============================================================ */

    private function spawnNPCParticles(): void
    {
        $this->particleTick++;

        foreach ($this->getServer()->getWorldManager()->getWorlds() as $world) {
            foreach ($world->getEntities() as $entity) {
                $color = null;

                if ($entity instanceof ManagerNPC) {
                    $color = new Color(255, 170, 0);
                } elseif ($entity instanceof ShopNPC) {
                    $color = match ($entity->getShopType()) {
                        1 => new Color(85, 255, 85),
                        2 => new Color(170, 0, 0),
                        3 => new Color(85, 255, 255),
                        4 => new Color(255, 85, 85),
                        5 => new Color(255, 85, 255),
                        default => new Color(255, 255, 255)
                    };
                }

                if ($color === null) continue;

                $pos = $entity->getPosition();
                $radius = 0.8;
                $points = 8;
                $angleOffset = ($this->particleTick * 0.15);

                for ($i = 0; $i < $points; $i++) {
                    $angle = $angleOffset + (($i / $points) * 2 * M_PI);
                    $x = $pos->getX() + $radius * cos($angle);
                    $z = $pos->getZ() + $radius * sin($angle);
                    $y = $pos->getY() + 0.1 + sin($this->particleTick * 0.1 + $i) * 0.15;

                    $particle = new DustParticle($color);
                    $world->addParticle(new Vector3($x, $y, $z), $particle);
                }
            }
        }
    }

    /* ============================================================
     *  COMMANDS
     * ============================================================ */

    public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool
    {
        if (!$sender instanceof Player) {
            $sender->sendMessage("§l§cКоманда доступна только для игроков.");
            return true;
        }

        switch ($command->getName()) {
            case "rcnewbus":
                $this->cmdNewBusiness($sender, $args);
                break;
            case "rcsetmanager":
                $this->cmdSetManager($sender, $args);
                break;
            case "rcsetshop":
                $this->cmdSetShop($sender, $args);
                break;
            case "rcbuslist":
                $this->cmdBusinessList($sender);
                break;
            case "rcdelbus":
                $this->cmdDeleteBusiness($sender, $args);
                break;
        }

        return true;
    }

    private function cmdNewBusiness(Player $player, array $args): void
    {
        if (count($args) < 3) {
            $player->sendMessage("§l§6[Бизнес] §fИспользование: §e/rcnewbus <тех.название> <цена> <Название>");
            $player->sendMessage("§l§6[Бизнес] §7Пример: §e/rcnewbus bar_01 100000 Бар У Дороги");
            return;
        }

        $techName = array_shift($args);
        $price = (int) array_shift($args);
        $displayName = implode(" ", $args);

        if ($price < 1000) {
            $player->sendMessage("§l§6[Бизнес] §cМинимальная стоимость бизнеса: §e1 000₽");
            return;
        }

        $data = $this->businessData->getAll();
        if (isset($data[$techName])) {
            $player->sendMessage("§l§6[Бизнес] §cБизнес с тех. названием §e{$techName} §cуже существует.");
            return;
        }

        $pos = $player->getPosition();
        $businessInfo = [
            "tech_name" => $techName,
            "display_name" => $displayName,
            "price" => $price,
            "owner" => null,
            "balance" => 0,
            "products" => 0,
            "rent_days" => 0,
            "rent_timestamp" => 0,
            "total_earned" => 0,
            "daily_profit" => [],
            "delivery_time" => 0,
            "delivery_amount" => 0,
            "world" => $pos->getWorld()->getFolderName(),
            "x" => round($pos->getX(), 2),
            "y" => round($pos->getY(), 2),
            "z" => round($pos->getZ(), 2),
            "created_at" => time()
        ];

        $data[$techName] = $businessInfo;
        $this->businessData->setAll($data);
        $this->businessData->save();

        $this->createFloatingText($techName, $businessInfo);

        $player->sendMessage("§l§6[Бизнес] §aБизнес успешно зарегистрирован!");
        $player->sendMessage("§l§6[Бизнес] §eНазвание: §f{$displayName}");
        $player->sendMessage("§l§6[Бизнес] §eТех. название: §f{$techName}");
        $player->sendMessage("§l§6[Бизнес] §eСтоимость: §a" . number_format($price, 0, ".", ".") . "₽");
        $player->sendMessage("§l§6[Бизнес] §7Установите персонал:");
        $player->sendMessage("§l§6[Бизнес] §e  /rcsetmanager {$techName}");
        $player->sendMessage("§l§6[Бизнес] §e  /rcsetshop {$techName} <1-5>");
    }

    private function cmdSetManager(Player $player, array $args): void
    {
        if (count($args) < 1) {
            $player->sendMessage("§l§6[Бизнес] §fИспользование: §e/rcsetmanager <тех.название>");
            return;
        }

        $techName = $args[0];
        $data = $this->businessData->getAll();

        if (!isset($data[$techName])) {
            $player->sendMessage("§l§6[Бизнес] §cБизнес §e{$techName} §cне найден.");
            return;
        }

        $this->spawnManagerNPC($player, $techName);
        $player->sendMessage("§l§6[Бизнес] §aМенеджер бизнеса §e{$data[$techName]['display_name']} §aуспешно назначен!");
    }

    private function cmdSetShop(Player $player, array $args): void
    {
        if (count($args) < 2) {
            $player->sendMessage("§l§6[Бизнес] §fИспользование: §e/rcsetshop <тех.название> <тип>");
            $player->sendMessage("");
            $player->sendMessage("§l§6[Бизнес] §aТипы коммерческих объектов:");
            $player->sendMessage("§l§a  1 §7— §fМагазин 24/7 §7(продукты питания)");
            $player->sendMessage("§l§4  2 §7— §cЧёрный рынок §7(нелегальные товары)");
            $player->sendMessage("§l§b  3 §7— §fАптека §7(медикаменты, тотемы)");
            $player->sendMessage("§l§c  4 §7— §fОружейный магазин §7(оружие, броня)");
            $player->sendMessage("§l§d  5 §7— §fМебельный салон §7(мебель, декор)");
            return;
        }

        $techName = $args[0];
        $shopType = (int) $args[1];

        if ($shopType < 1 || $shopType > 5) {
            $player->sendMessage("§l§6[Бизнес] §cТип магазина должен быть от §e1 §cдо §e5§c.");
            return;
        }

        $data = $this->businessData->getAll();

        if (!isset($data[$techName])) {
            $player->sendMessage("§l§6[Бизнес] §cБизнес §e{$techName} §cне найден.");
            return;
        }

        $this->spawnShopNPC($player, $techName, $shopType);

        $typeName = match ($shopType) {
            1 => "§aМагазин 24/7",
            2 => "§cЧёрный рынок",
            3 => "§bАптека",
            4 => "§cОружейный магазин",
            5 => "§dМебельный салон",
            default => "§fМагазин"
        };

        $player->sendMessage("§l§6[Бизнес] §aПродавец бизнеса §e{$data[$techName]['display_name']} §aназначен!");
        $player->sendMessage("§l§6[Бизнес] §fТип: {$typeName}");
    }

    private function cmdBusinessList(Player $player): void
    {
        $data = $this->businessData->getAll();

        if (empty($data)) {
            $player->sendMessage("§l§6[Бизнес] §7Зарегистрированных бизнесов не найдено.");
            return;
        }

        $player->sendMessage("§l§6✦ Реестр коммерческих объектов РФ ✦");
        $player->sendMessage("");

        foreach ($data as $tech => $info) {
            $owner = $info["owner"] ?? "§7Государство РФ";
            $status = $info["owner"] !== null ? "§l§aВ собственности" : "§l§eНа продажу";
            $level = ShopCatalog::getBusinessLevel($info["total_earned"]);

            $player->sendMessage("§l§e  ✦ {$info['display_name']} §7({$tech})");
            $player->sendMessage("§l§f    Владелец: §e{$owner} §7| {$status}");
            $player->sendMessage("§l§f    Уровень: {$level['name']}");
            $player->sendMessage("§l§f    Цена: §a" . number_format($info["price"], 0, ".", ".") . "₽");
            $player->sendMessage("");
        }
    }

    private function cmdDeleteBusiness(Player $player, array $args): void
    {
        if (count($args) < 1) {
            $player->sendMessage("§l§6[Бизнес] §fИспользование: §e/rcdelbus <тех.название>");
            return;
        }

        $techName = $args[0];
        $data = $this->businessData->getAll();

        if (!isset($data[$techName])) {
            $player->sendMessage("§l§6[Бизнес] §cБизнес §e{$techName} §cне найден.");
            return;
        }

        $name = $data[$techName]["display_name"];
        $this->removeFloatingText($techName);
        $this->removeNPCsByTech($techName);

        unset($data[$techName]);
        $this->businessData->setAll($data);
        $this->businessData->save();

        $player->sendMessage("§l§6[Бизнес] §aБизнес §e{$name} §aисключён из реестра.");
    }

    /* ============================================================
     *  EVENT LISTENERS
     * ============================================================ */

    /**
     * @param EntityDamageEvent $event
     * @priority HIGHEST
     * @handleCancelled
     */
    public function onEntityDamage(EntityDamageEvent $event): void
    {
        $entity = $event->getEntity();

        if ($entity instanceof ManagerNPC || $entity instanceof ShopNPC) {
            $event->cancel();
        }

        if (!$event instanceof EntityDamageByEntityEvent) return;

        $damager = $event->getDamager();
        if (!$damager instanceof Player) return;

        $name = $damager->getName();
        $now = microtime(true);
        if (isset($this->cooldown[$name]) && ($now - $this->cooldown[$name]) < 1.0) {
            return;
        }
        $this->cooldown[$name] = $now;

        if ($entity instanceof ManagerNPC) {
            $techName = $entity->getBusinessTech();
            if ($techName === "") return;
            $this->forms->openManagerMenu($damager, $techName);
        }

        if ($entity instanceof ShopNPC) {
            $techName = $entity->getBusinessTech();
            if ($techName === "") return;
            $shopType = $entity->getShopType();
            $this->forms->openShopMenu($damager, $techName, $shopType);
        }
    }

    /**
     * @param PlayerJoinEvent $event
     * @priority NORMAL
     */
    public function onPlayerJoin(PlayerJoinEvent $event): void
    {
        $this->getScheduler()->scheduleDelayedTask(new ClosureTask(function (): void {
            $this->recreateAllFloatingTexts();
        }), 40);
    }

    /* ============================================================
     *  FLOATING TEXTS
     * ============================================================ */

    public function createFloatingText(string $techName, array $data): void
    {
        $world = $this->getServer()->getWorldManager()->getWorldByName($data["world"]);
        if ($world === null) return;

        $pos = new Vector3($data["x"], $data["y"] + 2.5, $data["z"]);

        if (isset($this->floatingTexts[$techName])) {
            $this->floatingTexts[$techName]->setInvisible(true);
            $world->addParticle($pos, $this->floatingTexts[$techName]);
            unset($this->floatingTexts[$techName]);
        }

        $text = $this->buildFloatingText($data);
        $particle = new FloatingTextParticle($text);
        $this->floatingTexts[$techName] = $particle;
        $world->addParticle($pos, $particle);
    }

    public function updateFloatingText(string $techName): void
    {
        $data = $this->businessData->getAll();
        if (!isset($data[$techName])) return;
        $this->createFloatingText($techName, $data[$techName]);
    }

    private function buildFloatingText(array $data): string
    {
        $level = ShopCatalog::getBusinessLevel($data["total_earned"]);

        if ($data["owner"] === null) {
            return "§l§6✦ " . $data["display_name"] . " ✦\n" .
                "§l§aСтоимость: §f" . number_format($data["price"], 0, ".", ".") . "₽\n" .
                "§l§7Собственность Государства РФ\n" .
                "§l§eДоступно для приобретения";
        } else {
            return "§l§6✦ " . $data["display_name"] . " ✦\n" .
                "§l§bВладелец: §f" . $data["owner"] . "\n" .
                "§l§eУровень: {$level['name']}\n" .
                "§l§aОткрыто";
        }
    }

    public function removeFloatingText(string $techName): void
    {
        $data = $this->businessData->getAll();
        if (!isset($data[$techName])) return;

        $info = $data[$techName];
        $world = $this->getServer()->getWorldManager()->getWorldByName($info["world"]);
        if ($world === null) return;

        if (isset($this->floatingTexts[$techName])) {
            $pos = new Vector3($info["x"], $info["y"] + 2.5, $info["z"]);
            $this->floatingTexts[$techName]->setInvisible(true);
            $world->addParticle($pos, $this->floatingTexts[$techName]);
            unset($this->floatingTexts[$techName]);
        }
    }

    public function loadFloatingTexts(): void
    {
        foreach ($this->businessData->getAll() as $techName => $info) {
            $this->createFloatingText($techName, $info);
        }
    }

    public function recreateAllFloatingTexts(): void
    {
        $data = $this->businessData->getAll();

        foreach ($this->floatingTexts as $techName => $particle) {
            if (isset($data[$techName])) {
                $info = $data[$techName];
                $world = $this->getServer()->getWorldManager()->getWorldByName($info["world"]);
                if ($world !== null) {
                    $pos = new Vector3($info["x"], $info["y"] + 2.5, $info["z"]);
                    $particle->setInvisible(true);
                    $world->addParticle($pos, $particle);
                }
            }
        }

        $this->floatingTexts = [];

        foreach ($data as $techName => $info) {
            $this->createFloatingText($techName, $info);
        }
    }

    /* ============================================================
     *  NPC SPAWNING
     * ============================================================ */

    public function spawnManagerNPC(Player $player, string $techName): void
    {
        $this->removeNPCsByTechAndType($techName, "manager");

        $location = $player->getLocation();
        $skin = $player->getSkin();
        $data = $this->businessData->getAll();
        $displayName = $data[$techName]["display_name"] ?? $techName;

        $nbt = CompoundTag::create();
        $nbt->setString("BusinessTech", $techName);
        $nbt->setString("NPCType", "manager");

        $entity = new ManagerNPC($location, $skin, $nbt);
        $entity->setNameTag("§l§6✦ Менеджер ✦\n§l§7Бизнес: §f{$displayName}");
        $entity->setNameTagAlwaysVisible(true);
        $entity->setNoClientPredictions(true);
        $entity->spawnToAll();
    }

    public function spawnShopNPC(Player $player, string $techName, int $shopType = 1): void
    {
        $this->removeNPCsByTechAndType($techName, "shop");

        $location = $player->getLocation();
        $skin = $player->getSkin();
        $data = $this->businessData->getAll();
        $displayName = $data[$techName]["display_name"] ?? $techName;

        $nbt = CompoundTag::create();
        $nbt->setString("BusinessTech", $techName);
        $nbt->setString("NPCType", "shop");
        $nbt->setInt("ShopType", $shopType);

        $entity = new ShopNPC($location, $skin, $nbt);
        $entity->setNameTag(ShopCatalog::getShopNPCName($shopType, $displayName));
        $entity->setNameTagAlwaysVisible(true);
        $entity->setNoClientPredictions(true);
        $entity->spawnToAll();
    }

    private function removeNPCsByTech(string $techName): void
    {
        foreach ($this->getServer()->getWorldManager()->getWorlds() as $world) {
            foreach ($world->getEntities() as $entity) {
                if (($entity instanceof ManagerNPC || $entity instanceof ShopNPC) && $entity->getBusinessTech() === $techName) {
                    $entity->flagForDespawn();
                }
            }
        }
    }

    private function removeNPCsByTechAndType(string $techName, string $type): void
    {
        foreach ($this->getServer()->getWorldManager()->getWorlds() as $world) {
            foreach ($world->getEntities() as $entity) {
                if ($type === "manager" && $entity instanceof ManagerNPC && $entity->getBusinessTech() === $techName) {
                    $entity->flagForDespawn();
                }
                if ($type === "shop" && $entity instanceof ShopNPC && $entity->getBusinessTech() === $techName) {
                    $entity->flagForDespawn();
                }
            }
        }
    }

    /* ============================================================
     *  BUSINESS LOGIC
     * ============================================================ */

    public function purchaseBusiness(Player $player, string $techName): bool
    {
        $data = $this->businessData->getAll();
        if (!isset($data[$techName])) return false;

        $info = $data[$techName];
        if ($info["owner"] !== null) return false;

        $price = $info["price"];
        $money = $this->getPlayerMoney($player);

        if ($money < $price) {
            $player->sendMessage("§l§6[Бизнес] §cНедостаточно средств для приобретения данного объекта.");
            $player->sendMessage("§l§6[Бизнес] §eНеобходимо: §f" . number_format($price, 0, ".", ".") . "₽");
            $player->sendMessage("§l§6[Бизнес] §eВаш баланс: §f" . number_format($money, 0, ".", ".") . "₽");
            return false;
        }

        $this->removePlayerMoney($player, $price);

        $data[$techName]["owner"] = $player->getName();
        $data[$techName]["balance"] = 0;
        $data[$techName]["products"] = 100;
        $data[$techName]["rent_days"] = 1;
        $data[$techName]["rent_timestamp"] = time() + 86400;
        $data[$techName]["total_earned"] = 0;
        $data[$techName]["daily_profit"] = [];
        $data[$techName]["delivery_time"] = 0;
        $data[$techName]["delivery_amount"] = 0;

        $this->businessData->setAll($data);
        $this->businessData->save();
        $this->updateFloatingText($techName);

        return true;
    }

    public function sellBusinessToState(Player $player, string $techName): int
    {
        $data = $this->businessData->getAll();
        if (!isset($data[$techName])) return 0;

        $info = $data[$techName];
        $refund = (int) ($info["price"] * 0.7);
        $totalReturn = $refund + $info["balance"];

        $this->addPlayerMoney($player, $totalReturn);
        $this->resetBusiness($techName);

        return $refund;
    }

    public function resetBusiness(string $techName): void
    {
        $data = $this->businessData->getAll();
        if (!isset($data[$techName])) return;

        $data[$techName]["owner"] = null;
        $data[$techName]["balance"] = 0;
        $data[$techName]["products"] = 0;
        $data[$techName]["rent_days"] = 0;
        $data[$techName]["rent_timestamp"] = 0;
        $data[$techName]["total_earned"] = 0;
        $data[$techName]["daily_profit"] = [];
        $data[$techName]["delivery_time"] = 0;
        $data[$techName]["delivery_amount"] = 0;

        $this->businessData->setAll($data);
        $this->businessData->save();
        $this->updateFloatingText($techName);
    }

    public function collectProfit(Player $player, string $techName): bool
    {
        $data = $this->businessData->getAll();
        if (!isset($data[$techName])) return false;

        $balance = $data[$techName]["balance"];
        if ($balance <= 0) {
            $player->sendMessage("§l§6[Бизнес] §7На расчётном счёте бизнеса отсутствуют средства для вывода.");
            return false;
        }

        $this->addPlayerMoney($player, $balance);

        $data[$techName]["balance"] = 0;
        $this->businessData->setAll($data);
        $this->businessData->save();

        return true;
    }

    public function extendRent(string $techName, int $days): void
    {
        $data = $this->businessData->getAll();
        if (!isset($data[$techName])) return;

        $currentTimestamp = $data[$techName]["rent_timestamp"];
        if ($currentTimestamp < time()) {
            $currentTimestamp = time();
        }

        $data[$techName]["rent_timestamp"] = $currentTimestamp + ($days * 86400);
        $data[$techName]["rent_days"] += $days;

        $this->businessData->setAll($data);
        $this->businessData->save();
    }

    public function orderProducts(string $techName, int $amount, bool $express): void
    {
        $data = $this->businessData->getAll();
        if (!isset($data[$techName])) return;

        $deliverySeconds = $express ? 1800 : 3600;
        $data[$techName]["delivery_time"] = time() + $deliverySeconds;
        $data[$techName]["delivery_amount"] = $amount;

        $this->businessData->setAll($data);
        $this->businessData->save();
    }

    public function addProfitToBusiness(string $techName, int $amount): void
    {
        $data = $this->businessData->getAll();
        if (!isset($data[$techName])) return;

        $data[$techName]["balance"] += $amount;
        $data[$techName]["total_earned"] += $amount;

        $today = date("Y-m-d");
        $daily = $data[$techName]["daily_profit"] ?? [];

        $weekStart = date("Y-m-d", strtotime("monday this week"));
        $filtered = [];
        foreach ($daily as $date => $val) {
            if ($date >= $weekStart) {
                $filtered[$date] = $val;
            }
        }

        $filtered[$today] = ($filtered[$today] ?? 0) + $amount;
        $data[$techName]["daily_profit"] = $filtered;

        $this->businessData->setAll($data);
        $this->businessData->save();

        $this->checkLevelUp($techName, $data[$techName]);
    }

    private function checkLevelUp(string $techName, array $info): void
    {
        $thresholds = [100000, 500000, 1000000, 2000000, 5000000];
        $totalEarned = $info["total_earned"];
        $previousEarned = $totalEarned - ($info["balance"] > 0 ? 0 : 0);

        foreach ($thresholds as $threshold) {
            $beforeLevel = ShopCatalog::getBusinessLevel($totalEarned - 1);
            $afterLevel = ShopCatalog::getBusinessLevel($totalEarned);

            if ($beforeLevel["level"] < $afterLevel["level"] && $totalEarned >= $threshold && ($totalEarned - 200) < $threshold) {
                $ownerName = $info["owner"] ?? null;
                if ($ownerName !== null) {
                    $owner = $this->getServer()->getPlayerExact($ownerName);
                    if ($owner !== null) {
                        $profitPercent = (int) (ShopCatalog::getOwnerProfitPercent($totalEarned) * 100);
                        $owner->sendMessage("§l§6[Бизнес] §a🎉 Поздравляем! Ваш бизнес достиг нового уровня!");
                        $owner->sendMessage("§l§6[Бизнес] §fНовый уровень: {$afterLevel['name']}");
                        $owner->sendMessage("§l§6[Бизнес] §fВаш процент с продаж теперь: §a{$profitPercent}%");
                    }
                }
                $this->updateFloatingText($techName);
                break;
            }
        }
    }

    public function getRemainingRentTime(string $techName): string
    {
        $data = $this->businessData->getAll();
        if (!isset($data[$techName])) return "§l§7Нет данных";

        $timestamp = $data[$techName]["rent_timestamp"];
        if ($timestamp <= time()) {
            return "§l§cИстекла";
        }

        $diff = $timestamp - time();
        $days = floor($diff / 86400);
        $hours = floor(($diff % 86400) / 3600);
        $minutes = floor(($diff % 3600) / 60);

        return "§l§a{$days} §fдн. §e{$hours} §fч. §b{$minutes} §fмин.";
    }

    /* ============================================================
     *  SCHEDULED TASKS
     * ============================================================ */

    private function checkRentExpiry(): void
    {
        $data = $this->businessData->getAll();

        foreach ($data as $techName => $info) {
            if ($info["owner"] === null) continue;
            if ($info["rent_timestamp"] <= 0) continue;

            if ($info["rent_timestamp"] <= time()) {
                $ownerName = $info["owner"];
                $owner = $this->getServer()->getPlayerExact($ownerName);

                if ($owner !== null) {
                    $owner->sendMessage("§l§6[Бизнес] §cСрок аренды бизнеса §e{$info['display_name']} §cистёк!");
                    $owner->sendMessage("§l§6[Бизнес] §cОбъект изъят в пользу Государства РФ.");
                    $owner->sendMessage("§l§6[Бизнес] §7Средства на расчётном счёте аннулированы.");
                    $owner->sendMessage("§l§6[Бизнес] §7Продукция на складе конфискована ФТС.");
                }

                $this->resetBusiness($techName);
                $this->getLogger()->info("§lБизнес {$techName} ({$info['display_name']}) изъят у {$ownerName} — истёк срок аренды.");
            }
        }
    }

    private function checkDeliveries(): void
    {
        $data = $this->businessData->getAll();
        $changed = false;

        foreach ($data as $techName => &$info) {
            if (($info["delivery_time"] ?? 0) > 0 && $info["delivery_time"] <= time() && ($info["delivery_amount"] ?? 0) > 0) {
                $info["products"] += $info["delivery_amount"];

                $ownerName = $info["owner"];
                if ($ownerName !== null) {
                    $owner = $this->getServer()->getPlayerExact($ownerName);
                    if ($owner !== null) {
                        $owner->sendMessage("§l§6[Бизнес] §a📦 Доставка продукции завершена!");
                        $owner->sendMessage("§l§6[Бизнес] §fНа склад поступило: §e{$info['delivery_amount']} шт.");
                        $owner->sendMessage("§l§6[Бизнес] §fВсего на складе: §e{$info['products']} шт.");
                    }
                }

                $info["delivery_time"] = 0;
                $info["delivery_amount"] = 0;
                $changed = true;
            }
        }

        if ($changed) {
            $this->businessData->setAll($data);
            $this->businessData->save();
        }
    }

    private function generatePassiveIncome(): void
    {
        $data = $this->businessData->getAll();

        foreach ($data as $techName => $info) {
            if ($info["owner"] === null) continue;
            if (($info["products"] ?? 0) <= 0) continue;
            if (($info["rent_timestamp"] ?? 0) <= time()) continue;

            $passiveIncome = rand(50, 200);
            $this->addProfitToBusiness($techName, $passiveIncome);
        }
    }

    private function checkWeeklyReset(): void
    {
        $now = time();
        $mondayThisWeek = strtotime("monday this week 00:00:00");
        $lastCleanup = $this->getConfig()->get("last_weekly_cleanup", 0);

        if ($lastCleanup < $mondayThisWeek && $now >= $mondayThisWeek) {
            $allData = $this->businessData->getAll();
            foreach ($allData as $tech => &$bInfo) {
                $bInfo["daily_profit"] = [];
            }
            $this->businessData->setAll($allData);
            $this->businessData->save();

            $this->getConfig()->set("last_weekly_cleanup", $now);
            $this->getConfig()->save();

            $this->getLogger()->info("§l§aЕженедельная очистка статистики ФНС выполнена.");
        }
    }

    /* ============================================================
     *  ECONOMY — EconomyAPI
     * ============================================================ */

    public function getPlayerMoney(Player $player): int
    {
        return (int) EconomyAPI::getInstance()->myMoney($player);
    }

    public function addPlayerMoney(Player $player, int $amount): void
    {
        EconomyAPI::getInstance()->addMoney($player, $amount);
    }

    public function removePlayerMoney(Player $player, int $amount): void
    {
        EconomyAPI::getInstance()->reduceMoney($player, $amount);
    }
}