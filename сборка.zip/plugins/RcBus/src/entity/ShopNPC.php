<?php

declare(strict_types=1);

namespace InzeOwr\RcBus\entity;

use pocketmine\entity\Human;
use pocketmine\entity\Location;
use pocketmine\entity\Skin;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\math\Vector3;

class ShopNPC extends Human
{
    private string $businessTech = "";
    private int $shopType = 1;

    public function __construct(Location $location, Skin $skin, ?CompoundTag $nbt = null)
    {
        parent::__construct($location, $skin, $nbt);
        if ($nbt !== null) {
            $this->businessTech = $nbt->getString("BusinessTech", "");
            $this->shopType = $nbt->getInt("ShopType", 1);
        }
    }

    public function getBusinessTech(): string
    {
        return $this->businessTech;
    }

    public function getShopType(): int
    {
        return $this->shopType;
    }

    public function saveNBT(): CompoundTag
    {
        $nbt = parent::saveNBT();
        $nbt->setString("BusinessTech", $this->businessTech);
        $nbt->setString("NPCType", "shop");
        $nbt->setInt("ShopType", $this->shopType);
        return $nbt;
    }

    protected function entityBaseTick(int $tickDiff = 1): bool
    {
        $this->motion = new Vector3(0, 0, 0);
        return parent::entityBaseTick($tickDiff);
    }

    protected function initEntity(CompoundTag $nbt): void
    {
        parent::initEntity($nbt);
        $this->setNoClientPredictions(true);
        $this->setNameTagAlwaysVisible(true);
        $this->gravity = 0.0;
        $this->gravityEnabled = false;
        $this->businessTech = $nbt->getString("BusinessTech", "");
        $this->shopType = $nbt->getInt("ShopType", 1);
    }
}