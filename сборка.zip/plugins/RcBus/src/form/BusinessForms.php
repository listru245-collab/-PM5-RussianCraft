<?php

/*
 * Автор форм: jojo (jojoe77777/FormAPI)
 */

declare(strict_types=1);

namespace InzeOwr\RcBus\form;

use pocketmine\player\Player;
use pocketmine\item\StringToItemParser;
use pocketmine\item\Item;
use jojoe77777\FormAPI\SimpleForm;
use jojoe77777\FormAPI\CustomForm;
use jojoe77777\FormAPI\ModalForm;
use InzeOwr\RcBus\Main;
use InzeOwr\RcBus\shop\ShopCatalog;

class BusinessForms
{
    private Main $plugin;

    public function __construct(Main $plugin)
    {
        $this->plugin = $plugin;
    }

    public function openManagerMenu(Player $player, string $techName): void
    {
        $data = $this->plugin->getBusinessData()->getAll();
        if (!isset($data[$techName])) return;

        $info = $data[$techName];

        if ($info["owner"] === null) {
            $this->openPurchaseForm($player, $techName, $info);
        } elseif ($info["owner"] === $player->getName()) {
            $this->openOwnerForm($player, $techName, $info);
        } else {
            $player->sendMessage("§l§6[Бизнес] §7Данный бизнес принадлежит игроку §e" . $info["owner"]);
            $player->sendMessage("§l§6[Бизнес] §7Вы не можете взаимодействовать с панелью управления.");
        }
    }

    public function openShopMenu(Player $player, string $techName, int $shopType): void
    {
        $data = $this->plugin->getBusinessData()->getAll();
        if (!isset($data[$techName])) return;

        $info = $data[$techName];

        if ($info["owner"] === null) {
            $player->sendMessage("§l§6[Магазин] §7Данный магазин в настоящее время закрыт.");
            $player->sendMessage("§l§6[Магазин] §7Объект ожидает нового владельца.");
            return;
        }

        if ($info["products"] <= 0) {
            $player->sendMessage("§l§6[Магазин] §cК сожалению, товар на складе закончился.");
            $player->sendMessage("§l§6[Магазин] §7Пожалуйста, загляните позже.");
            return;
        }

        $this->openShopItemsForm($player, $techName, $info, $shopType);
    }

    private function openPurchaseForm(Player $player, string $techName, array $info): void
    {
        $price = number_format($info["price"], 0, ".", ".");
        $taxPercent = (int) (ShopCatalog::getTaxPercent() * 100);

        $form = new SimpleForm(function (Player $player, ?int $data) use ($techName, $info): void {
            if ($data === null) return;

            if ($data === 0) {
                $result = $this->plugin->purchaseBusiness($player, $techName);
                if ($result) {
                    $priceF = number_format($info["price"], 0, ".", ".");
                    $player->sendMessage("§l§6[Бизнес] §aПоздравляем с успешным приобретением!");
                    $player->sendMessage("§l§6[Бизнес] §fВы стали владельцем бизнеса §e" . $info["display_name"]);
                    $player->sendMessage("§l§6[Бизнес] §fС вашего счёта списано: §c{$priceF}₽");
                    $player->sendMessage("§l§6[Бизнес] §fВам начислено: §a100 единиц продукции");
                    $player->sendMessage("§l§6[Бизнес] §fАренда оплачена на: §e1 день");
                    $player->sendMessage("§l§6[Бизнес] §7Не забывайте продлевать аренду и заказывать продукцию!");
                }
            }
        });

        $form->setTitle("§l§6✦ Приобретение бизнеса ✦");
        $form->setContent(
            "§l§fДобро пожаловать в отдел регистрации\n" .
            "§l§fкоммерческой недвижимости Российской Федерации!\n\n" .
            "§l§eОбъект: §f" . $info["display_name"] . "\n" .
            "§l§eСтоимость: §a{$price}₽\n" .
            "§l§eТекущий статус: §aСвободен\n\n" .
            "§l§bУсловия приобретения:\n" .
            "§l§a  ✔ §f100 единиц продукции\n" .
            "§l§a  ✔ §f1 день оплаченной аренды\n" .
            "§l§a  ✔ §fНалог на прибыль: §c{$taxPercent}%\n\n" .
            "§l§7Стоимость аренды: §e20 000₽ §7в сутки\n\n" .
            "§l§dЖелаете оформить сделку?"
        );
        $form->addButton("§l§2✔ Оформить покупку\n§r§l§8Подписать договор купли-продажи");
        $form->addButton("§l§4✘ Отказаться\n§r§l§8Вернуться назад");

        $player->sendForm($form);
    }

    private function openOwnerForm(Player $player, string $techName, array $info): void
    {
        $balance = number_format($info["balance"], 0, ".", ".");
        $products = $info["products"];
        $rentTime = $this->plugin->getRemainingRentTime($techName);
        $totalEarned = number_format($info["total_earned"], 0, ".", ".");

        $level = ShopCatalog::getBusinessLevel($info["total_earned"]);
        $progressBar = ShopCatalog::getLevelProgressBar($info["total_earned"]);
        $profitPercent = (int) (ShopCatalog::getOwnerProfitPercent($info["total_earned"]) * 100);
        $taxPercent = (int) (ShopCatalog::getTaxPercent() * 100);

        $deliveryStatus = "";
        if (($info["delivery_time"] ?? 0) > time()) {
            $remaining = (int) (($info["delivery_time"] - time()) / 60);
            $deliveryStatus = "\n§l§eДоставка: §f{$info['delivery_amount']} шт. §7(через {$remaining} мин.)";
        }

        $form = new SimpleForm(function (Player $player, ?int $data) use ($techName): void {
            if ($data === null) return;

            $refreshData = $this->plugin->getBusinessData()->getAll();
            if (!isset($refreshData[$techName])) return;
            $info = $refreshData[$techName];

            switch ($data) {
                case 0:
                    $bal = $info["balance"];
                    $result = $this->plugin->collectProfit($player, $techName);
                    if ($result) {
                        $formatted = number_format($bal, 0, ".", ".");
                        $player->sendMessage("§l§6[Бизнес] §aПрибыль успешно выведена на ваш личный счёт!");
                        $player->sendMessage("§l§6[Бизнес] §fСумма вывода: §a{$formatted}₽");
                        $player->sendMessage("§l§6[Бизнес] §7Средства зачислены. Спасибо за ведение бизнеса!");
                    }
                    break;
                case 1:
                    $this->openProfitStatsForm($player, $techName, $info);
                    break;
                case 2:
                    $this->openRentForm($player, $techName, $info);
                    break;
                case 3:
                    $this->openOrderForm($player, $techName, $info);
                    break;
                case 4:
                    $this->openSellConfirmForm($player, $techName, $info);
                    break;
            }
        });

        $form->setTitle("§l§6✦ Панель управления ✦");
        $form->setContent(
            "§l§eБизнес: §f" . $info["display_name"] . "\n" .
            "§l§eВладелец: §b" . $info["owner"] . "\n" .
            "§l§eУровень: {$level['name']}\n" .
            "§l§eПрогресс: {$progressBar}\n\n" .
            "§l§aБаланс: §f{$balance}₽\n" .
            "§l§dСклад: §f{$products} шт.\n" .
            "§l§cАренда: §f{$rentTime}\n" .
            "§l§9Доход: §f{$totalEarned}₽\n" .
            "§l§eВаш процент: §a{$profitPercent}% §7(налог {$taxPercent}%){$deliveryStatus}"
        );
        $form->addButton("§l§2Собрать прибыль\n§r§l§8На балансе: {$balance}₽");
        $form->addButton("§l§9Финансовый отчёт\n§r§l§8Отчёт за неделю ФНС");
        $form->addButton("§l§6Продлить аренду\n§r§l§8Осталось: {$rentTime}");
        $form->addButton("§l§5Заказать продукцию\n§r§l§8На складе: {$products} шт.");
        $form->addButton("§l§4Продать государству\n§r§l§8Компенсация 70%");

        $player->sendForm($form);
    }

    private function openProfitStatsForm(Player $player, string $techName, array $info): void
    {
        $daily = $info["daily_profit"] ?? [];

        $level = ShopCatalog::getBusinessLevel($info["total_earned"]);
        $progressBar = ShopCatalog::getLevelProgressBar($info["total_earned"]);
        $profitPercent = (int) (ShopCatalog::getOwnerProfitPercent($info["total_earned"]) * 100);
        $taxPercent = (int) (ShopCatalog::getTaxPercent() * 100);

        $content = "§l§6✦ Налоговая отчётность (ФНС РФ) ✦\n\n";
        $content .= "§l§eУровень бизнеса: {$level['name']}\n";
        $content .= "§l§eПрогресс: {$progressBar}\n";
        $content .= "§l§aВаш процент: §f{$profitPercent}% §7| Налог: §c{$taxPercent}%\n\n";
        $content .= "§l§bДоходы за текущую неделю:\n\n";

        $weekDays = ["Понедельник", "Вторник", "Среда", "Четверг", "Пятница", "Суббота", "Воскресенье"];
        $monday = strtotime("monday this week");
        $totalWeek = 0;

        for ($i = 0; $i < 7; $i++) {
            $date = date("Y-m-d", $monday + ($i * 86400));
            $dayName = $weekDays[$i];
            $amount = $daily[$date] ?? 0;
            $totalWeek += $amount;
            $formatted = number_format($amount, 0, ".", ".");

            if ($date === date("Y-m-d")) {
                $content .= "§l§e  ► {$dayName}: §a{$formatted}₽ §d(сегодня)\n";
            } elseif ($date < date("Y-m-d")) {
                $content .= "§l§f  ◆ {$dayName}: §a{$formatted}₽\n";
            } else {
                $content .= "§l§7  ○ {$dayName}: §8ожидается\n";
            }
        }

        $totalFormatted = number_format($totalWeek, 0, ".", ".");
        $taxAmount = number_format((int) ($totalWeek * ShopCatalog::getTaxPercent()), 0, ".", ".");
        $content .= "\n§l§bИтого за неделю: §a{$totalFormatted}₽";
        $content .= "\n§l§cУдержано налогов: §f{$taxAmount}₽";
        $content .= "\n§l§9Общий доход за всё время: §a" . number_format($info["total_earned"], 0, ".", ".") . "₽";

        $form = new SimpleForm(function (Player $player, ?int $data): void {});

        $form->setTitle("§l§6✦ Финансовый отчёт ФНС ✦");
        $form->setContent($content);
        $form->addButton("§l§8Закрыть отчёт");

        $player->sendForm($form);
    }

    private function openRentForm(Player $player, string $techName, array $info): void
    {
        $rentTime = $this->plugin->getRemainingRentTime($techName);

        $form = new CustomForm(function (Player $player, ?array $data) use ($techName): void {
            if ($data === null) return;

            $days = (int) ($data[1] ?? 1);
            if ($days < 1) $days = 1;
            if ($days > 30) $days = 30;

            $cost = $days * 20000;
            $money = $this->plugin->getPlayerMoney($player);

            if ($money < $cost) {
                $formatted = number_format($cost, 0, ".", ".");
                $player->sendMessage("§l§6[Бизнес] §cНедостаточно средств для продления аренды.");
                $player->sendMessage("§l§6[Бизнес] §fНеобходимо: §e{$formatted}₽");
                return;
            }

            $this->plugin->removePlayerMoney($player, $cost);
            $this->plugin->extendRent($techName, $days);

            $formatted = number_format($cost, 0, ".", ".");
            $player->sendMessage("§l§6[Бизнес] §aДоговор аренды успешно продлён на §e{$days} дн.");
            $player->sendMessage("§l§6[Бизнес] §fС вашего счёта списано: §c{$formatted}₽");
            $player->sendMessage("§l§6[Бизнес] §7Документы зарегистрированы в Росреестре.");
        });

        $form->setTitle("§l§6✦ Продление аренды ✦");
        $form->addLabel(
            "§l§6Росреестр Российской Федерации\n\n" .
            "§l§eТекущий срок аренды: §f{$rentTime}\n" .
            "§l§aСтоимость: §f20 000₽ §7за сутки\n\n" .
            "§l§bУкажите срок продления договора:"
        );
        $form->addSlider("§l§fКоличество дней", 1, 30, 1, 1);

        $player->sendForm($form);
    }

    private function openOrderForm(Player $player, string $techName, array $info): void
    {
        $products = $info["products"];
        $deliveryInfo = "";
        if (($info["delivery_time"] ?? 0) > time()) {
            $rem = (int) (($info["delivery_time"] - time()) / 60);
            $deliveryInfo = "\n§l§eАктивная доставка: §f{$info['delivery_amount']} шт. §7через {$rem} мин.";
        }

        $form = new CustomForm(function (Player $player, ?array $data) use ($techName, $info): void {
            if ($data === null) return;

            $amount = (int) ($data[1] ?? 1);
            if ($amount < 1) $amount = 1;
            if ($amount > 1000) $amount = 1000;

            $express = (bool) ($data[2] ?? false);

            $cost = $amount * 10;
            if ($express) $cost += 50000;

            $money = $this->plugin->getPlayerMoney($player);
            if ($money < $cost) {
                $formatted = number_format($cost, 0, ".", ".");
                $player->sendMessage("§l§6[Бизнес] §cНедостаточно средств для заказа продукции.");
                $player->sendMessage("§l§6[Бизнес] §fНеобходимо: §e{$formatted}₽");
                return;
            }

            $refreshData = $this->plugin->getBusinessData()->getAll();
            if (($refreshData[$techName]["delivery_time"] ?? 0) > time()) {
                $player->sendMessage("§l§6[Бизнес] §cПредыдущая доставка ещё в пути. Дождитесь её получения.");
                return;
            }

            $this->plugin->removePlayerMoney($player, $cost);
            $this->plugin->orderProducts($techName, $amount, $express);

            $formatted = number_format($cost, 0, ".", ".");
            $deliveryTime = $express ? "30 минут" : "60 минут";
            $player->sendMessage("§l§6[Бизнес] §aНакладная на поставку продукции оформлена!");
            $player->sendMessage("§l§6[Бизнес] §fКоличество: §e{$amount} шт.");
            $player->sendMessage("§l§6[Бизнес] §fС вашего счёта списано: §c{$formatted}₽");
            $player->sendMessage("§l§6[Бизнес] §fОжидаемое время доставки: §e{$deliveryTime}");
            if ($express) {
                $player->sendMessage("§l§6[Бизнес] §a Экспресс-доставка «СДЭК Бизнес» активирована!");
            } else {
                $player->sendMessage("§l§6[Бизнес] §7Доставка «Почта России» — стандартная.");
            }
        });

        $form->setTitle("§l§6✦ Заказ продукции ✦");
        $form->addLabel(
            "§l§6Служба снабжения\n\n" .
            "§l§dНа складе: §f{$products} шт.\n" .
            "§l§aСтоимость: §f10₽ §7за единицу\n" .
            "§l§eДоставка «Почта России»: §f60 минут\n" .
            "§l§cДоставка «СДЭК Бизнес»: §f30 минут §7(+50 000₽){$deliveryInfo}\n\n" .
            "§l§bУкажите количество продукции:"
        );
        $form->addSlider("§l§fКоличество единиц", 1, 1000, 1, 100);
        $form->addToggle("§l§c СДЭК Бизнес §7(экспресс +50 000₽)", false);

        $player->sendForm($form);
    }

    private function openSellConfirmForm(Player $player, string $techName, array $info): void
    {
        $refund = (int) ($info["price"] * 0.7);
        $refundFormatted = number_format($refund, 0, ".", ".");
        $balanceFormatted = number_format($info["balance"], 0, ".", ".");

        $form = new ModalForm(function (Player $player, ?bool $data) use ($techName, $info, $refundFormatted, $balanceFormatted): void {
            if ($data === null) return;

            if ($data === true) {
                $result = $this->plugin->sellBusinessToState($player, $techName);
                if ($result > 0) {
                    $formatted = number_format($result, 0, ".", ".");
                    $player->sendMessage("§l§6[Бизнес] §aДоговор купли-продажи зарегистрирован.");
                    $player->sendMessage("§l§6[Бизнес] §fКомпенсация: §a{$formatted}₽ §7(70% от кадастровой стоимости)");
                    if ($info["balance"] > 0) {
                        $player->sendMessage("§l§6[Бизнес] §fОстаток с баланса: §a{$balanceFormatted}₽");
                    }
                    $player->sendMessage("§l§6[Бизнес] §7Благодарим за ведение предпринимательской деятельности!");
                    $player->sendMessage("§l§6[Бизнес] §7Документы направлены в ФНС для снятия с учёта.");
                }
            }
        });

        $form->setTitle("§l§4✦ Ликвидация бизнеса ✦");
        $form->setContent(
            "§l§6Росреестр Российской Федерации\n" .
            "§l§7Заявление о ликвидации ИП\n\n" .
            "§l§fОбъект: §e" . $info["display_name"] . "\n\n" .
            "§l§aКомпенсация: §f{$refundFormatted}₽\n" .
            "§l§7(70% от кадастровой стоимости)\n\n" .
            "§l§eОстаток на расчётном счёте: §f{$balanceFormatted}₽\n" .
            "§l§7Средства будут перечислены на ваш счёт.\n\n" .
            "§l§c⚠ Внимание! Данное действие необратимо.\n" .
            "§l§c⚠ Лицензия аннулируется, товар конфискуется."
        );
        $form->setButton1("§l§4✘ Подписать заявление");
        $form->setButton2("§l§2✔ Отклонить заявление");

        $player->sendForm($form);
    }

    private function openShopItemsForm(Player $player, string $techName, array $info, int $shopType): void
    {
        $items = ShopCatalog::getItems($shopType);
        $title = ShopCatalog::getShopTitle($shopType);

        $level = ShopCatalog::getBusinessLevel($info["total_earned"]);
        $profitPercent = (int) (ShopCatalog::getOwnerProfitPercent($info["total_earned"]) * 100);
        $taxPercent = (int) (ShopCatalog::getTaxPercent() * 100);

        $form = new SimpleForm(function (Player $player, ?int $data) use ($techName, $info, $shopType, $items): void {
            if ($data === null) return;
            if (!isset($items[$data])) return;

            $selected = $items[$data];
            $this->openShopBuyForm($player, $techName, $info, $selected, $shopType);
        });

        $form->setTitle($title);

        $ownerColor = match ($shopType) {
            2 => "§c",
            3 => "§b",
            4 => "§c",
            5 => "§d",
            default => "§a"
        };

        $isOwner = ($info["owner"] === $player->getName());
        $ownerNote = $isOwner ? "\n§l§7(Вы являетесь владельцем — выручка зачисляется на баланс)" : "";

        $form->setContent(
            "§l§fДобро пожаловать!\n\n" .
            "§l§eВладелец: {$ownerColor}{$info['owner']}\n" .
            "§l§eУровень: {$level['name']}\n" .
            "§l§dТовар на складе: §f{$info['products']} шт.\n" .
            "§l§7Налог: §c{$taxPercent}% §7| Владельцу: §a{$profitPercent}%{$ownerNote}\n\n" .
            "§l§bВыберите товар для покупки:"
        );

        foreach ($items as $item) {
            $price = number_format($item["price"], 0, ".", ".");
            $color = $item["color"] ?? "§f";
            $form->addButton("§l{$color}{$item['name']}\n§r§l§8{$price}₽");
        }

        $player->sendForm($form);
    }

    private function openShopBuyForm(Player $player, string $techName, array $info, array $item, int $shopType): void
    {
        $price = number_format($item["price"], 0, ".", ".");
        $title = ShopCatalog::getShopTitle($shopType);
        $color = $item["color"] ?? "§f";

        $profitPercent = (int) (ShopCatalog::getOwnerProfitPercent($info["total_earned"]) * 100);
        $taxPercent = (int) (ShopCatalog::getTaxPercent() * 100);

        $form = new CustomForm(function (Player $player, ?array $data) use ($techName, $item): void {
            if ($data === null) return;

            $quantity = (int) ($data[1] ?? 1);
            if ($quantity < 1) $quantity = 1;
            if ($quantity > 64) $quantity = 64;

            $refreshData = $this->plugin->getBusinessData()->getAll();
            if (!isset($refreshData[$techName])) return;
            $currentInfo = $refreshData[$techName];

            if ($currentInfo["products"] < $quantity) {
                $player->sendMessage("§l§6[Магазин] §cНа складе недостаточно товара.");
                $player->sendMessage("§l§6[Магазин] §fДоступно: §e{$currentInfo['products']} шт.");
                return;
            }

            $totalCost = $item["price"] * $quantity;
            $money = $this->plugin->getPlayerMoney($player);

            if ($money < $totalCost) {
                $formatted = number_format($totalCost, 0, ".", ".");
                $player->sendMessage("§l§6[Магазин] §cНедостаточно средств для совершения покупки.");
                $player->sendMessage("§l§6[Магазин] §fСтоимость: §e{$formatted}₽");
                return;
            }

            $itemObj = $this->resolveItem($item["id"], $quantity, $item["custom_name"] ?? $item["name"]);
            if ($itemObj === null) {
                $player->sendMessage("§l§6[Магазин] §cОшибка при выдаче товара. Обратитесь к администрации.");
                return;
            }

            $this->plugin->removePlayerMoney($player, $totalCost);

            $ownerProfitPercent = ShopCatalog::getOwnerProfitPercent($currentInfo["total_earned"]);
            $profit = (int) ($totalCost * $ownerProfitPercent);
            $this->plugin->addProfitToBusiness($techName, $profit);

            $refreshData[$techName]["products"] -= $quantity;
            $this->plugin->getBusinessData()->setAll($refreshData);
            $this->plugin->getBusinessData()->save();

            $player->getInventory()->addItem($itemObj);

            $formatted = number_format($totalCost, 0, ".", ".");
            $profitFormatted = number_format($profit, 0, ".", ".");
            $player->sendMessage("§l§6[Магазин] §aПокупка совершена успешно!");
            $player->sendMessage("§l§6[Магазин] §fТовар: §e{$item['name']} §fx{$quantity}");
            $player->sendMessage("§l§6[Магазин] §fС вашего счёта списано: §c{$formatted}₽");

            $ownerName = $currentInfo["owner"] ?? null;
            if ($ownerName === $player->getName()) {
                $player->sendMessage("§l§6[Магазин] §7На баланс бизнеса зачислено: §a{$profitFormatted}₽ §7(после налога)");
            } else {
                $player->sendMessage("§l§6[Магазин] §7Спасибо за покупку! Ждём вас снова.");
                if ($ownerName !== null) {
                    $owner = $this->plugin->getServer()->getPlayerExact($ownerName);
                    if ($owner !== null) {
                        $owner->sendMessage("§l§6[Бизнес] §a Продажа! §f{$item['name']} §7x{$quantity} §fна сумму §a{$formatted}₽");
                        $owner->sendMessage("§l§6[Бизнес] §fНа баланс зачислено: §a{$profitFormatted}₽ §7(после налога)");
                    }
                }
            }
        });

        $form->setTitle($title);
        $form->addLabel(
            "§l{$color}Товар: §f{$item['name']}\n" .
            "§l{$item['description']}\n\n" .
            "§l§aЦена за единицу: §f{$price}₽\n" .
            "§l§dНа складе: §f{$info['products']} шт.\n" .
            "§l§7Налог ФНС: §c{$taxPercent}% §7| Владельцу: §a{$profitPercent}%\n\n" .
            "§l§bУкажите количество:"
        );
        $form->addSlider("§l§fКоличество", 1, 64, 1, 1);

        $player->sendForm($form);
    }

    private function resolveItem(string $id, int $count, string $customName): ?Item
    {
        $item = StringToItemParser::getInstance()->parse($id);
        if ($item !== null) {
            $item->setCount($count);
            $item->setCustomName($customName);
            return $item;
        }

        return null;
    }
}