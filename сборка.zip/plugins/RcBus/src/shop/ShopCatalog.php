<?php

declare(strict_types=1);

namespace InzeOwr\RcBus\shop;

class ShopCatalog
{
    public static function getItems(int $shopType): array
    {
        return match ($shopType) {
            1 => self::getRegularShop(),
            2 => self::getIllegalShop(),
            3 => self::getPharmacy(),
            4 => self::getWeaponShop(),
            5 => self::getFurnitureShop(),
            default => self::getRegularShop()
        };
    }

    public static function getShopTitle(int $shopType): string
    {
        return match ($shopType) {
            1 => "§l§a✦ Магазин 24/7 ✦",
            2 => "§l§4✦ Чёрный Рынок ✦",
            3 => "§l§b✦ Аптека «Здоровье» ✦",
            4 => "§l§c✦ Оружейная «Арсенал» ✦",
            5 => "§l§d✦ Мебельный салон «Уют» ✦",
            default => "§l§a✦ Магазин ✦"
        };
    }

    public static function getShopNPCName(int $shopType, string $displayName): string
    {
        return match ($shopType) {
            1 => "§l§a✦ Продавец ✦\n§l§7Магазин: §f{$displayName}",
            2 => "§l§4✦ Барыга ✦\n§l§7Точка: §c{$displayName}",
            3 => "§l§b✦ Фармацевт ✦\n§l§7Аптека: §f{$displayName}",
            4 => "§l§c✦ Оружейник ✦\n§l§7Магазин: §f{$displayName}",
            5 => "§l§d✦ Консультант ✦\n§l§7Салон: §f{$displayName}",
            default => "§l§a✦ Продавец ✦\n§l§7{$displayName}"
        };
    }

    public static function getBusinessLevel(int $totalEarned): array
    {
        if ($totalEarned >= 5000000) {
            return ["name" => "§l§6✦ Корпорация ✦", "level" => 5, "bonus" => 0.25, "color" => "§6"];
        } elseif ($totalEarned >= 2000000) {
            return ["name" => "§l§5✦ Крупный бизнес ✦", "level" => 4, "bonus" => 0.20, "color" => "§5"];
        } elseif ($totalEarned >= 1000000) {
            return ["name" => "§l§b✦ Средний бизнес ✦", "level" => 3, "bonus" => 0.15, "color" => "§b"];
        } elseif ($totalEarned >= 500000) {
            return ["name" => "§l§a✦ Малый бизнес ✦", "level" => 2, "bonus" => 0.10, "color" => "§a"];
        } elseif ($totalEarned >= 100000) {
            return ["name" => "§l§e✦ Стартап ✦", "level" => 1, "bonus" => 0.05, "color" => "§e"];
        } else {
            return ["name" => "§l§7✦ Новый бизнес ✦", "level" => 0, "bonus" => 0.0, "color" => "§7"];
        }
    }

    public static function getLevelProgressBar(int $totalEarned): string
    {
        $thresholds = [0, 100000, 500000, 1000000, 2000000, 5000000];
        $level = self::getBusinessLevel($totalEarned);
        $currentLevel = $level["level"];

        if ($currentLevel >= 5) {
            return "§l§6[§a██████████§6] §fMAX";
        }

        $nextThreshold = $thresholds[$currentLevel + 1];
        $currentThreshold = $thresholds[$currentLevel];
        $progress = ($totalEarned - $currentThreshold) / ($nextThreshold - $currentThreshold);
        $filled = (int) ($progress * 10);
        $empty = 10 - $filled;

        $bar = "§a" . str_repeat("█", $filled) . "§8" . str_repeat("█", $empty);
        $nextFormatted = number_format($nextThreshold, 0, ".", ".");

        return "§l{$level['color']}[{$bar}{$level['color']}] §f{$nextFormatted}₽";
    }

    public static function getTaxPercent(): float
    {
        return 0.13;
    }

    public static function getOwnerProfitPercent(int $totalEarned): float
    {
        $level = self::getBusinessLevel($totalEarned);
        $base = 0.70;
        $bonus = $level["bonus"];
        $tax = self::getTaxPercent();
        return $base + $bonus - $tax;
    }

    private static function getRegularShop(): array
    {
        return [
            ["name" => "§fСвежий белый хлеб", "custom_name" => "§r§6✦ §fСвежий белый хлеб §6✦", "id" => "bread", "price" => 50, "description" => "§7Ароматный хлеб из местной пекарни", "color" => "§e"],
            ["name" => "§fСтейк из свинины", "custom_name" => "§r§6✦ §fСтейк из свинины §6✦", "id" => "cooked_porkchop", "price" => 120, "description" => "§7Прожаренный стейк средней прожарки", "color" => "§6"],
            ["name" => "§fГовядина на гриле", "custom_name" => "§r§6✦ §fГовядина на гриле §6✦", "id" => "cooked_beef", "price" => 100, "description" => "§7Сочная говядина приготовленная на углях", "color" => "§6"],
            ["name" => "§fШоколадное печенье", "custom_name" => "§r§d✦ §fШоколадное печенье §d✦", "id" => "cookie", "price" => 30, "description" => "§7Домашнее печенье с шоколадной крошкой", "color" => "§d"],
            ["name" => "§fЖареная курица", "custom_name" => "§r§6✦ §fЖареная курица §6✦", "id" => "cooked_chicken", "price" => 80, "description" => "§7Куриная грудка запечённая в духовке", "color" => "§e"],
            ["name" => "§fАрбузная долька", "custom_name" => "§r§a✦ §fАрбузная долька §a✦", "id" => "melon_slice", "price" => 25, "description" => "§7Свежий сладкий арбуз", "color" => "§a"],
            ["name" => "§fМорковный сок", "custom_name" => "§r§6✦ §fМорковный сок §6✦", "id" => "golden_carrot", "price" => 200, "description" => "§7Свежевыжатый сок из отборной моркови", "color" => "§6"],
            ["name" => "§fТыквенный пирог", "custom_name" => "§r§6✦ §fТыквенный пирог §6✦", "id" => "pumpkin_pie", "price" => 150, "description" => "§7Домашний пирог с тыквенной начинкой", "color" => "§6"],
            ["name" => "§fВяленая говядина", "custom_name" => "§r§c✦ §fВяленая говядина §c✦", "id" => "dried_kelp", "price" => 40, "description" => "§7Сушёное мясо для перекуса в дорогу", "color" => "§c"],
            ["name" => "§fЯблочный компот", "custom_name" => "§r§a✦ §fЯблочный компот §a✦", "id" => "apple", "price" => 35, "description" => "§7Домашний компот из свежих яблок", "color" => "§a"]
        ];
    }

    private static function getIllegalShop(): array
    {
        return [
            ["name" => "§cМетамфетамин", "custom_name" => "§r§4✦ §cМетамфетамин §4✦", "id" => "sugar", "price" => 5000, "description" => "§8Кристаллический порошок. Запрещено.", "color" => "§4"],
            ["name" => "§cКокаин", "custom_name" => "§r§4✦ §cКокаин §4✦", "id" => "glowstone_dust", "price" => 8000, "description" => "§8Белый порошок высшего качества", "color" => "§4"],
            ["name" => "§cГероин", "custom_name" => "§r§4✦ §cГероин §4✦", "id" => "gunpowder", "price" => 12000, "description" => "§8Опасное вещество. Крайне запрещено.", "color" => "§4"],
            ["name" => "§cМарихуана", "custom_name" => "§r§2✦ §cМарихуана §2✦", "id" => "dried_kelp", "price" => 3000, "description" => "§8Сушёные листья конопли", "color" => "§2"],
            ["name" => "§cЛСД Марка", "custom_name" => "§r§5✦ §cЛСД Марка §5✦", "id" => "paper", "price" => 6000, "description" => "§8Психоделическое вещество на бумаге", "color" => "§5"],
            ["name" => "§cЭкстази", "custom_name" => "§r§d✦ §cЭкстази §d✦", "id" => "magma_cream", "price" => 7000, "description" => "§8Таблетки с MDMA. Опасно для жизни.", "color" => "§d"],
            ["name" => "§cАмфетамин", "custom_name" => "§r§e✦ §cАмфетамин §e✦", "id" => "blaze_powder", "price" => 4500, "description" => "§8Стимулирующее вещество", "color" => "§e"],
            ["name" => "§cСинтетика «Спайс»", "custom_name" => "§r§4✦ §cСинтетика «Спайс» §4✦", "id" => "fermented_spider_eye", "price" => 9000, "description" => "§8Синтетический каннабиноид. Смертельно.", "color" => "§4"],
            ["name" => "§cОпиум", "custom_name" => "§r§6✦ §cОпиум §6✦", "id" => "honeycomb", "price" => 10000, "description" => "§8Натуральный опиат. Крайне опасен.", "color" => "§6"],
            ["name" => "§cФенциклидин (PCP)", "custom_name" => "§r§9✦ §cФенциклидин §9✦", "id" => "phantom_membrane", "price" => 15000, "description" => "§8Диссоциативный анестетик. Запрещён.", "color" => "§9"]
        ];
    }

    private static function getPharmacy(): array
    {
        return [
            ["name" => "§bЗолотое яблоко", "custom_name" => "§r§6✦ §bПремиум витамины §6✦", "id" => "golden_apple", "price" => 5000, "description" => "§7Комплекс витаминов премиум-класса", "color" => "§6"],
            ["name" => "§bТотем бессмертия", "custom_name" => "§r§a✦ §bТотем реанимации §a✦", "id" => "totem", "price" => 750000, "description" => "§7Экспериментальный медицинский прибор", "color" => "§a"],
            ["name" => "§bЗачарованное золотое яблоко", "custom_name" => "§r§5✦ §bУльтра-лекарство §5✦", "id" => "enchanted_golden_apple", "price" => 50000, "description" => "§7Экспериментальный препарат полного исцеления", "color" => "§5"],
            ["name" => "§bБинт", "custom_name" => "§r§f✦ §bМедицинский бинт §f✦", "id" => "paper", "price" => 500, "description" => "§7Стерильный бинт для перевязки ран", "color" => "§f"],
            ["name" => "§bОбезболивающее", "custom_name" => "§r§b✦ §bОбезболивающее §b✦", "id" => "sugar", "price" => 1500, "description" => "§7Таблетки для снятия болевого синдрома", "color" => "§b"],
            ["name" => "§bАнтибиотик", "custom_name" => "§r§a✦ §bАнтибиотик §a✦", "id" => "nether_wart", "price" => 3000, "description" => "§7Сильнодействующий антибиотик широкого спектра", "color" => "§a"],
            ["name" => "§bАнтидот", "custom_name" => "§r§e✦ §bАнтидот §e✦", "id" => "milk_bucket", "price" => 2000, "description" => "§7Универсальное противоядие", "color" => "§e"],
            ["name" => "§bАдреналин", "custom_name" => "§r§c✦ §bАдреналин §c✦", "id" => "ghast_tear", "price" => 8000, "description" => "§7Экстренная инъекция для реанимации", "color" => "§c"],
            ["name" => "§bМорфин", "custom_name" => "§r§5✦ §bМорфин §5✦", "id" => "rabbit_foot", "price" => 12000, "description" => "§7Сильнодействующее обезболивающее", "color" => "§5"],
            ["name" => "§bМедицинская аптечка", "custom_name" => "§r§c✦ §bМедицинская аптечка §c✦", "id" => "golden_carrot", "price" => 4000, "description" => "§7Полный набор первой помощи", "color" => "§c"]
        ];
    }

    private static function getWeaponShop(): array
    {
        return [
            ["name" => "§fДеревянный нож", "custom_name" => "§r§6✦ §fТренировочный клинок §6✦", "id" => "wooden_sword", "price" => 500, "description" => "§7Деревянный учебный клинок", "color" => "§6"],
            ["name" => "§fКаменный нож", "custom_name" => "§r§7✦ §fОхотничий нож §7✦", "id" => "stone_sword", "price" => 1500, "description" => "§7Каменный нож для охоты", "color" => "§7"],
            ["name" => "§fЖелезный клинок", "custom_name" => "§r§f✦ §fБоевой клинок §f✦", "id" => "iron_sword", "price" => 5000, "description" => "§7Стальной боевой клинок", "color" => "§f"],
            ["name" => "§fЗолотой клинок", "custom_name" => "§r§e✦ §fЗолотой клинок «Люкс» §e✦", "id" => "golden_sword", "price" => 8000, "description" => "§7Декоративный позолоченный клинок", "color" => "§e"],
            ["name" => "§fАлмазный клинок", "custom_name" => "§r§b✦ §fАлмазный клинок «Элита» §b✦", "id" => "diamond_sword", "price" => 25000, "description" => "§7Клинок из закалённого алмаза", "color" => "§b"],
            ["name" => "§fНеритовый клинок", "custom_name" => "§r§4✦ §fНеритовый клинок «Абсолют» §4✦", "id" => "netherite_sword", "price" => 100000, "description" => "§7Легендарный клинок из незерита", "color" => "§4"],
            ["name" => "§fЖелезный топор", "custom_name" => "§r§f✦ §fБоевой топор §f✦", "id" => "iron_axe", "price" => 4000, "description" => "§7Стальной топор двойного назначения", "color" => "§f"],
            ["name" => "§fАлмазный топор", "custom_name" => "§r§b✦ §fАлмазный топор «Секира» §b✦", "id" => "diamond_axe", "price" => 20000, "description" => "§7Тяжёлая алмазная секира", "color" => "§b"],
            ["name" => "§fНеритовый топор", "custom_name" => "§r§4✦ §fНеритовая секира «Палач» §4✦", "id" => "netherite_axe", "price" => 80000, "description" => "§7Неразрушимая секира из незерита", "color" => "§4"],
            ["name" => "§fКожаный шлем", "custom_name" => "§r§6✦ §fКожаный шлем §6✦", "id" => "leather_cap", "price" => 800, "description" => "§7Лёгкий защитный шлем", "color" => "§6"],
            ["name" => "§fКожаная куртка", "custom_name" => "§r§6✦ §fКожаная куртка §6✦", "id" => "leather_tunic", "price" => 1200, "description" => "§7Куртка из натуральной кожи", "color" => "§6"],
            ["name" => "§fКожаные штаны", "custom_name" => "§r§6✦ §fКожаные штаны §6✦", "id" => "leather_pants", "price" => 1000, "description" => "§7Прочные кожаные штаны", "color" => "§6"],
            ["name" => "§fКожаные ботинки", "custom_name" => "§r§6✦ §fКожаные ботинки §6✦", "id" => "leather_boots", "price" => 600, "description" => "§7Удобные кожаные ботинки", "color" => "§6"],
            ["name" => "§fСтальной шлем", "custom_name" => "§r§f✦ §fСтальной шлем §f✦", "id" => "iron_helmet", "price" => 3000, "description" => "§7Бронированный стальной шлем", "color" => "§f"],
            ["name" => "§fСтальной бронежилет", "custom_name" => "§r§f✦ §fСтальной бронежилет §f✦", "id" => "iron_chestplate", "price" => 5000, "description" => "§7Бронежилет из закалённой стали", "color" => "§f"],
            ["name" => "§fСтальные поножи", "custom_name" => "§r§f✦ §fСтальные поножи §f✦", "id" => "iron_leggings", "price" => 4000, "description" => "§7Стальные наголенники", "color" => "§f"],
            ["name" => "§fСтальные берцы", "custom_name" => "§r§f✦ §fСтальные берцы §f✦", "id" => "iron_boots", "price" => 2500, "description" => "§7Армейские берцы со стальной вставкой", "color" => "§f"],
            ["name" => "§bАлмазный шлем", "custom_name" => "§r§b✦ §fАлмазный шлем «Титан» §b✦", "id" => "diamond_helmet", "price" => 15000, "description" => "§7Бронешлем класса «Титан»", "color" => "§b"],
            ["name" => "§bАлмазный бронежилет", "custom_name" => "§r§b✦ §fАлмазный бронежилет «Титан» §b✦", "id" => "diamond_chestplate", "price" => 25000, "description" => "§7Бронежилет высшего класса защиты", "color" => "§b"],
            ["name" => "§bАлмазные поножи", "custom_name" => "§r§b✦ §fАлмазные поножи «Титан» §b✦", "id" => "diamond_leggings", "price" => 20000, "description" => "§7Усиленные алмазные наголенники", "color" => "§b"],
            ["name" => "§bАлмазные берцы", "custom_name" => "§r§b✦ §fАлмазные берцы «Титан» §b✦", "id" => "diamond_boots", "price" => 12000, "description" => "§7Тактические ботинки с алмазной защитой", "color" => "§b"],
            ["name" => "§4Неритовый шлем", "custom_name" => "§r§4✦ §fНеритовый шлем «Абсолют» §4✦", "id" => "netherite_helmet", "price" => 80000, "description" => "§7Непробиваемый шлем из незерита", "color" => "§4"],
            ["name" => "§4Неритовый бронежилет", "custom_name" => "§r§4✦ §fНеритовый бронежилет «Абсолют» §4✦", "id" => "netherite_chestplate", "price" => 150000, "description" => "§7Абсолютная защита корпуса", "color" => "§4"],
            ["name" => "§4Неритовые поножи", "custom_name" => "§r§4✦ §fНеритовые поножи «Абсолют» §4✦", "id" => "netherite_leggings", "price" => 120000, "description" => "§7Поножи из неразрушимого незерита", "color" => "§4"],
            ["name" => "§4Неритовые берцы", "custom_name" => "§r§4✦ §fНеритовые берцы «Абсолют» §4✦", "id" => "netherite_boots", "price" => 70000, "description" => "§7Тактические ботинки «Абсолют»", "color" => "§4"]
        ];
    }

    private static function getFurnitureShop(): array
    {
        return [
            ["name" => "§dКровать (красная)", "custom_name" => "§r§c✦ §dКровать «Комфорт» §c✦", "id" => "red_bed", "price" => 2000, "description" => "§7Мягкая двуспальная кровать", "color" => "§c"],
            ["name" => "§dКровать (белая)", "custom_name" => "§r§f✦ §dКровать «Элегант» §f✦", "id" => "white_bed", "price" => 2500, "description" => "§7Элегантная белая кровать", "color" => "§f"],
            ["name" => "§dКровать (синяя)", "custom_name" => "§r§9✦ §dКровать «Океан» §9✦", "id" => "blue_bed", "price" => 2000, "description" => "§7Кровать в морском стиле", "color" => "§9"],
            ["name" => "§dПечка", "custom_name" => "§r§7✦ §dДомашняя печь §7✦", "id" => "furnace", "price" => 1500, "description" => "§7Классическая каменная печь", "color" => "§7"],
            ["name" => "§dКоптильня", "custom_name" => "§r§6✦ §dДомашняя коптильня §6✦", "id" => "smoker", "price" => 3000, "description" => "§7Для приготовления копчёностей", "color" => "§6"],
            ["name" => "§dВерстак", "custom_name" => "§r§e✦ §dРабочий верстак §e✦", "id" => "crafting_table", "price" => 1000, "description" => "§7Многофункциональный рабочий стол", "color" => "§e"],
            ["name" => "§dКнижная полка", "custom_name" => "§r§6✦ §dКнижная полка §6✦", "id" => "bookshelf", "price" => 3500, "description" => "§7Дубовая полка с книгами", "color" => "§6"],
            ["name" => "§dФонарь", "custom_name" => "§r§e✦ §dДекоративный фонарь §e✦", "id" => "lantern", "price" => 800, "description" => "§7Красивый подвесной фонарь", "color" => "§e"],
            ["name" => "§dЦветочный горшок", "custom_name" => "§r§6✦ §dЦветочный горшок §6✦", "id" => "flower_pot", "price" => 500, "description" => "§7Глиняный горшок для цветов", "color" => "§6"],
            ["name" => "§dКовёр (красный)", "custom_name" => "§r§c✦ §dКрасный ковёр §c✦", "id" => "red_carpet", "price" => 600, "description" => "§7Мягкий шерстяной ковёр", "color" => "§c"],
            ["name" => "§dКовёр (белый)", "custom_name" => "§r§f✦ §dБелый ковёр §f✦", "id" => "white_carpet", "price" => 600, "description" => "§7Белоснежный шерстяной ковёр", "color" => "§f"],
            ["name" => "§dДубовая листва", "custom_name" => "§r§a✦ §dДекоративная листва §a✦", "id" => "oak_leaves", "price" => 300, "description" => "§7Искусственная зелёная листва", "color" => "§a"],
            ["name" => "§dБерёзовая листва", "custom_name" => "§r§a✦ §dБерёзовая декор-листва §a✦", "id" => "birch_leaves", "price" => 300, "description" => "§7Светлая декоративная листва", "color" => "§a"],
            ["name" => "§dСвеча", "custom_name" => "§r§e✦ §dАроматическая свеча §e✦", "id" => "candle", "price" => 400, "description" => "§7Ароматическая восковая свеча", "color" => "§e"],
            ["name" => "§dЦепь", "custom_name" => "§r§7✦ §dДекоративная цепь §7✦", "id" => "chain", "price" => 700, "description" => "§7Металлическая декоративная цепь", "color" => "§7"],
            ["name" => "§dСтеклянная панель", "custom_name" => "§r§f✦ §dСтеклянная панель §f✦", "id" => "glass_pane", "price" => 200, "description" => "§7Прозрачная стеклянная панель", "color" => "§f"],
            ["name" => "§dЖелезная решётка", "custom_name" => "§r§7✦ §dДекоративная решётка §7✦", "id" => "iron_bars", "price" => 500, "description" => "§7Кованая железная решётка", "color" => "§7"],
            ["name" => "§dСундук", "custom_name" => "§r§6✦ §dДубовый сундук §6✦", "id" => "chest", "price" => 1500, "description" => "§7Вместительный деревянный сундук", "color" => "§6"],
            ["name" => "§dБочка", "custom_name" => "§r§6✦ §dДеревянная бочка §6✦", "id" => "barrel", "price" => 1200, "description" => "§7Декоративная дубовая бочка", "color" => "§6"],
            ["name" => "§dКолокол", "custom_name" => "§r§e✦ §dДекоративный колокол §e✦", "id" => "bell", "price" => 5000, "description" => "§7Бронзовый колокол ручной работы", "color" => "§e"]
        ];
    }
}