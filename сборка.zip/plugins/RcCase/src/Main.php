<?php
declare(strict_types=1);

namespace InzeOwr\RcCase;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\entity\EntityDataHelper;
use pocketmine\entity\Human;
use pocketmine\entity\Skin;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\math\Vector3;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\nbt\tag\DoubleTag;
use pocketmine\nbt\tag\FloatTag;
use pocketmine\nbt\tag\ListTag;
use pocketmine\player\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\scheduler\ClosureTask;
use pocketmine\scheduler\TaskHandler;
use pocketmine\utils\Config;
use pocketmine\utils\TextFormat as C;
use pocketmine\world\particle\HugeExplodeSeedParticle;
use pocketmine\world\particle\LavaParticle;
use pocketmine\world\particle\HugeExplodeParticle;
use pocketmine\world\particle\FlameParticle;
use pocketmine\world\particle\HeartParticle;
use pocketmine\world\particle\RedstoneParticle;
use pocketmine\world\particle\SmokeParticle;
use pocketmine\world\particle\DustParticle;
use pocketmine\color\Color;
use pocketmine\world\sound\XpLevelUpSound;
use pocketmine\world\sound\BlazeShootSound;
use pocketmine\world\sound\AnvilFallSound;
use pocketmine\world\sound\PopSound;
use pocketmine\world\sound\ClickSound;
use pocketmine\world\sound\FizzSound;
use pocketmine\world\sound\ExplodeSound;
use pocketmine\world\sound\EndermanTeleportSound;
use jojoe77777\FormAPI\SimpleForm;
use jojoe77777\FormAPI\CustomForm;

class Main extends PluginBase implements Listener {

    private Config $cfg;
    private Config $keysData;
    private Config $dailyKeysData;
    private Config $guaranteeData;
    private Config $totalSpinsData;
    private Config $npcData;
    private Config $playtimeData;
    private Config $giftCooldownData;
    private Config $pendingGiftsData;
    private Config $lastDailyData;

    private array $caseEntities = [];
    private array $dailyCaseEntities = [];
    private bool $boostEnabled = false;

    /** @var array<string, bool> playerName => true (крутит кейс) */
    private array $spinningPlayers = [];

    /** @var array<string, TaskHandler> playerName => TaskHandler */
    private array $playerTaskHandlers = [];

    /** @var array<string, int> playerName => joinTimestamp */
    private array $sessionStart = [];

    private const FUNNY_MESSAGES = [
        "§l§cВы мошенник! Так не бывает!",
        "§l§eНе может так везти... или может?",
        "§l§cInzeOwr уже следит за вами...",
        "§l§cERROR 404: Везение не найдено...",
        "§l§6Система подозревает читы на удачу!",
        "§l§dАдминистрация в шоке!",
        "§l§cERROR: Файл luck.exe поврежден!",
        "§l§eВы подкупили генератор случайных чисел?",
        "§l§cСлужба безопасности активирована!",
        "§l§cERROR 228: Такого везения не существует!",
        "§l§6Проверяем IP на читы удачи...",
        "§l§dЭто вообще легально?!",
        "§l§cАномальный уровень везения!",
        "§l§eInzeOwr хочет поговорить...",
        "§l§cERROR 1337: Везучесть зашкаливает!",
        "§l§cАккаунт помечен как подозрительный",
        "§l§6Генератор сломался из-за вас!",
        "§l§dКейс спонсирован вашей удачей",
        "§l§cFATAL ERROR: Luck overflow!",
        "§l§eДаже разработчик так не выбивал...",
        "§l§cОбнаружен хакер удачи!",
        "§l§cERROR 666: Дьявольское везение!",
        "§l§6Сервер требует перезагрузки...",
        "§l§dВаша удача нарушает физику!",
        "§l§cПолиграф назначен на завтра.",
        "§l§eStackOverflowLuckException!",
        "§l§cInzeOwr отправил жалобу!",
        "§l§cВы продали душу за этот дроп",
        "§l§6Античит удачи сработал!",
        "§l§dРаз в миллион лет... и это сейчас",
    ];

    private const SPIN_MESSAGES_STAGE = [
        1 => "§l§7Открытие...",
        2 => "§l§7Открытие...",
        3 => "§l§eПочти открылось...",
        4 => "§l§eПочти открылось...",
        5 => "§l§6Вот-вот...",
        6 => "§l§6Вот-вот...",
        7 => "§l§dСейчас узнаем...",
        8 => "§l§cМомент истины...",
    ];

    public function onEnable(): void {
        @mkdir($this->getDataFolder());
        $this->saveResource("config.yml");

        $this->cfg = new Config($this->getDataFolder() . "config.yml", Config::YAML);
        $this->keysData = new Config($this->getDataFolder() . "keys.yml", Config::YAML);
        $this->dailyKeysData = new Config($this->getDataFolder() . "daily_keys.yml", Config::YAML);
        $this->guaranteeData = new Config($this->getDataFolder() . "guarantee.yml", Config::YAML);
        $this->totalSpinsData = new Config($this->getDataFolder() . "totalspins.yml", Config::YAML);
        $this->npcData = new Config($this->getDataFolder() . "npcs.yml", Config::YAML);
        $this->playtimeData = new Config($this->getDataFolder() . "playtime.yml", Config::YAML);
        $this->giftCooldownData = new Config($this->getDataFolder() . "gift_cooldown.yml", Config::YAML);
        $this->pendingGiftsData = new Config($this->getDataFolder() . "pending_gifts.yml", Config::YAML);
        $this->lastDailyData = new Config($this->getDataFolder() . "last_daily.yml", Config::YAML);

        $this->getServer()->getPluginManager()->registerEvents($this, $this);
        $this->getLogger()->info(C::GREEN . "RcCase v2.0 by InzeOwr loaded!");

        $this->getScheduler()->scheduleDelayedTask(new ClosureTask(
            function(): void {
                $this->loadSavedNpcs();
            }
        ), 20);

        $this->getScheduler()->scheduleRepeatingTask(new ClosureTask(
            function(): void {
                $this->updatePlaytime();
            }
        ), 20 * 60);
    }

    public function onDisable(): void {
        $this->saveAllPlaytime();
        $this->keysData->save();
        $this->dailyKeysData->save();
        $this->guaranteeData->save();
        $this->totalSpinsData->save();
        $this->npcData->save();
        $this->playtimeData->save();
        $this->giftCooldownData->save();
        $this->pendingGiftsData->save();
        $this->lastDailyData->save();
    }

    // ==================== СОБЫТИЯ ====================

    public function onJoin(PlayerJoinEvent $event): void {
        $player = $event->getPlayer();
        $name = strtolower($player->getName());
        $this->sessionStart[$name] = time();

        $pending = $this->pendingGiftsData->get($name, []);
        if (!empty($pending)) {
            $this->getScheduler()->scheduleDelayedTask(new ClosureTask(
                function() use ($player): void {
                    if ($player->isOnline()) {
                        $this->showPendingGiftsForm($player);
                    }
                }
            ), 40);
        }
    }

    public function onQuit(PlayerQuitEvent $event): void {
        $name = strtolower($event->getPlayer()->getName());
        
        if (isset($this->sessionStart[$name])) {
            $this->savePlayerPlaytime($name);
            unset($this->sessionStart[$name]);
        }
        
        // Очищаем данные игрока
        unset($this->spinningPlayers[$name]);
        if (isset($this->playerTaskHandlers[$name])) {
            $this->playerTaskHandlers[$name]->cancel();
            unset($this->playerTaskHandlers[$name]);
        }
    }

    // ==================== ВРЕМЯ ИГРЫ ====================

    private function updatePlaytime(): void {
        $requiredHours = (float)$this->cfg->get("daily-playtime-hours", 6);
        $requiredSeconds = $requiredHours * 3600;

        foreach ($this->getServer()->getOnlinePlayers() as $player) {
            $name = strtolower($player->getName());
            
            $totalPlaytime = $this->getAccumulatedPlaytime($name);
            
            $lastDaily = $this->lastDailyData->get($name, 0);
            $now = time();
            
            if ($totalPlaytime >= $requiredSeconds && ($now - $lastDaily) >= 86400) {
                $this->addDailyKeys($name, 1);
                $this->lastDailyData->set($name, $now);
                $this->lastDailyData->save();
                $this->resetAccumulatedPlaytime($name);
                
                $player->sendMessage("§l§bВы получили ежедневный ключ за §e6 часов §bигры!");
                $player->getWorld()->addSound($player->getPosition(), new XpLevelUpSound(10));
            }
        }
    }

    private function getAccumulatedPlaytime(string $name): int {
        $saved = (int)$this->playtimeData->get($name, 0);
        if (isset($this->sessionStart[$name])) {
            $saved += (time() - $this->sessionStart[$name]);
        }
        return $saved;
    }

    private function savePlayerPlaytime(string $name): void {
        if (isset($this->sessionStart[$name])) {
            $current = (int)$this->playtimeData->get($name, 0);
            $session = time() - $this->sessionStart[$name];
            $this->playtimeData->set($name, $current + $session);
            $this->playtimeData->save();
            $this->sessionStart[$name] = time();
        }
    }

    private function saveAllPlaytime(): void {
        foreach ($this->sessionStart as $name => $startTime) {
            $current = (int)$this->playtimeData->get($name, 0);
            $session = time() - $startTime;
            $this->playtimeData->set($name, $current + $session);
        }
        $this->playtimeData->save();
    }

    private function resetAccumulatedPlaytime(string $name): void {
        $this->playtimeData->set($name, 0);
        $this->playtimeData->save();
        if (isset($this->sessionStart[$name])) {
            $this->sessionStart[$name] = time();
        }
    }

    // ==================== NPC ====================

    private function loadSavedNpcs(): void {
        $npcs = $this->npcData->get("normal", []);
        foreach ($npcs as $npcInfo) {
            $this->spawnNpcFromData($npcInfo, "normal");
        }

        $dailyNpcs = $this->npcData->get("daily", []);
        foreach ($dailyNpcs as $npcInfo) {
            $this->spawnNpcFromData($npcInfo, "daily");
        }
    }

    private function spawnNpcFromData(array $npcInfo, string $type): void {
        $worldName = $npcInfo["world"] ?? null;
        if ($worldName === null) return;

        $world = $this->getServer()->getWorldManager()->getWorldByName($worldName);
        if ($world === null) {
            $this->getServer()->getWorldManager()->loadWorld($worldName);
            $world = $this->getServer()->getWorldManager()->getWorldByName($worldName);
            if ($world === null) return;
        }

        $this->spawnCaseNpc(
            $world,
            (float)$npcInfo["x"],
            (float)$npcInfo["y"],
            (float)$npcInfo["z"],
            (float)$npcInfo["yaw"],
            $type
        );
    }

    private function saveNpcLocation(string $type, string $worldName, float $x, float $y, float $z, float $yaw): void {
        $npcs = $this->npcData->get($type, []);
        $npcs[] = [
            "world" => $worldName,
            "x" => $x,
            "y" => $y,
            "z" => $z,
            "yaw" => $yaw,
        ];
        $this->npcData->set($type, $npcs);
        $this->npcData->save();
    }

    private function spawnCaseNpc($world, float $x, float $y, float $z, float $yaw, string $type): void {
        $nbt = CompoundTag::create()
            ->setTag("Pos", new ListTag([
                new DoubleTag($x),
                new DoubleTag($y),
                new DoubleTag($z),
            ]))
            ->setTag("Rotation", new ListTag([
                new FloatTag($yaw),
                new FloatTag(0.0),
            ]))
            ->setString("RcCaseNpc", $type);

        $skinData = str_repeat("\xFF\x00\xFF\xFF", 64 * 64);
        $skin = new Skin("RcCase_" . $type, $skinData, "", "geometry.humanoid.custom", "");

        $entity = new Human(EntityDataHelper::parseLocation($nbt, $world), $skin, $nbt);

        $npcName = ($type === "daily") 
            ? $this->cfg->getNested("npc.daily-name", "§l§bЕжедневные кейсы")
            : $this->cfg->getNested("npc.normal-name", "§l§6Кейсы");
        
        $entity->setNameTag($npcName);
        $entity->setNameTagAlwaysVisible(true);
        $entity->setNoClientPredictions(true);

        $entity->spawnToAll();

        if ($type === "daily") {
            $this->dailyCaseEntities[$entity->getId()] = 1;
        } else {
            $this->caseEntities[$entity->getId()] = 1;
        }
    }

    // ==================== КЛЮЧИ ====================

    public function getKeys(string $name): int {
        return (int)$this->keysData->get(strtolower($name), 0);
    }

    public function setKeys(string $name, int $count): void {
        $name = strtolower($name);
        if ($count <= 0) {
            $this->keysData->remove($name);
        } else {
            $this->keysData->set($name, $count);
        }
        $this->keysData->save();
    }

    public function addKeys(string $name, int $count): void {
        $this->setKeys($name, $this->getKeys($name) + $count);
    }

    public function removeKeys(string $name, int $count): bool {
        $keys = $this->getKeys($name);
        if ($keys < $count) return false;
        $this->setKeys($name, $keys - $count);
        return true;
    }

    public function getDailyKeys(string $name): int {
        return (int)$this->dailyKeysData->get(strtolower($name), 0);
    }

    public function setDailyKeys(string $name, int $count): void {
        $name = strtolower($name);
        if ($count <= 0) {
            $this->dailyKeysData->remove($name);
        } else {
            $this->dailyKeysData->set($name, $count);
        }
        $this->dailyKeysData->save();
    }

    public function addDailyKeys(string $name, int $count): void {
        $this->setDailyKeys($name, $this->getDailyKeys($name) + $count);
    }

    public function removeDailyKeys(string $name, int $count): bool {
        $keys = $this->getDailyKeys($name);
        if ($keys < $count) return false;
        $this->setDailyKeys($name, $keys - $count);
        return true;
    }

    // ==================== ГАРАНТ И СТАТИСТИКА ====================

    public function getGuaranteeCount(string $name): int {
        return (int)$this->guaranteeData->get(strtolower($name), 0);
    }

    public function incrementGuarantee(string $name): int {
        $name = strtolower($name);
        $count = $this->getGuaranteeCount($name) + 1;
        $this->guaranteeData->set($name, $count);
        $this->guaranteeData->save();
        return $count;
    }

    public function resetGuarantee(string $name): void {
        $this->guaranteeData->remove(strtolower($name));
        $this->guaranteeData->save();
    }

    public function getTotalSpins(string $name): int {
        return (int)$this->totalSpinsData->get(strtolower($name), 0);
    }

    public function incrementTotalSpins(string $name, int $count = 1): void {
        $name = strtolower($name);
        $total = $this->getTotalSpins($name) + $count;
        $this->totalSpinsData->set($name, $total);
        $this->totalSpinsData->save();
    }

    // ==================== РЕПУТАЦИЯ ====================

    private function getPrivilegeReputation(string $privGroup): int {
        $rcGroup = $this->getServer()->getPluginManager()->getPlugin("RcGroup");
        if ($rcGroup !== null && $rcGroup->isEnabled()) {
            return $rcGroup->getReputation($privGroup);
        }
        
        $privs = $this->cfg->get("privileges", []);
        foreach ($privs as $name => $data) {
            if (($data["group"] ?? $name) === $privGroup) {
                return (int)($data["reputation"] ?? 0);
            }
        }
        return 0;
    }

    private function getPlayerGroup(string $playerName): string {
        $rcGroup = $this->getServer()->getPluginManager()->getPlugin("RcGroup");
        if ($rcGroup !== null && $rcGroup->isEnabled()) {
            return $rcGroup->getGroup($playerName);
        }
        return "Игрок";
    }

    private function getPlayerReputation(string $playerName): int {
        $group = $this->getPlayerGroup($playerName);
        return $this->getPrivilegeReputation($group);
    }

    // ==================== ПОДАРКИ ====================

    private function canGiftPrivilege(string $playerName): bool {
        $cooldownDays = (float)$this->cfg->get("gift-cooldown-days", 10.5);
        $cooldownSeconds = $cooldownDays * 86400;
        
        $lastGift = (int)$this->giftCooldownData->get(strtolower($playerName), 0);
        return (time() - $lastGift) >= $cooldownSeconds;
    }

    private function setGiftCooldown(string $playerName): void {
        $this->giftCooldownData->set(strtolower($playerName), time());
        $this->giftCooldownData->save();
    }

    private function addPendingGift(string $fromPlayer, string $privName, string $privGroup, string $color): void {
        $pending = $this->pendingGiftsData->get(strtolower($fromPlayer), []);
        $pending[] = [
            "priv" => $privName,
            "group" => $privGroup,
            "color" => $color,
            "time" => time(),
        ];
        $this->pendingGiftsData->set(strtolower($fromPlayer), $pending);
        $this->pendingGiftsData->save();
    }

    private function getPendingGifts(string $playerName): array {
        return $this->pendingGiftsData->get(strtolower($playerName), []);
    }

    private function removePendingGift(string $playerName, int $index): void {
        $pending = $this->getPendingGifts($playerName);
        if (isset($pending[$index])) {
            unset($pending[$index]);
            $pending = array_values($pending);
            if (empty($pending)) {
                $this->pendingGiftsData->remove(strtolower($playerName));
            } else {
                $this->pendingGiftsData->set(strtolower($playerName), $pending);
            }
            $this->pendingGiftsData->save();
        }
    }

    // ==================== КОМАНДЫ ====================

    public function onCommand(CommandSender $sender, Command $cmd, string $label, array $args): bool {
        switch ($cmd->getName()) {
            case "rccase":
                return $this->handleCaseCommand($sender, "normal");
            case "rccased":
                return $this->handleCaseCommand($sender, "daily");
            case "rcgivecase":
                return $this->handleGiveCaseCommand($sender, $args);
            case "rccaseboost":
                return $this->handleBoostCommand($sender);
            case "rcwandcase":
                return $this->handleWandCaseCommand($sender);
            case "rccaseremove":
                return $this->handleRemoveCommand($sender);
        }
        return true;
    }

    private function handleCaseCommand(CommandSender $sender, string $type): bool {
        if (!($sender instanceof Player)) {
            $sender->sendMessage("§l§cТолько для игроков!");
            return true;
        }

        $pos = $sender->getPosition();
        $world = $pos->getWorld();

        $this->saveNpcLocation(
            $type,
            $world->getFolderName(),
            $pos->getX(),
            $pos->getY(),
            $pos->getZ(),
            $sender->getLocation()->getYaw()
        );

        $nbt = CompoundTag::create()
            ->setTag("Pos", new ListTag([
                new DoubleTag($pos->getX()),
                new DoubleTag($pos->getY()),
                new DoubleTag($pos->getZ()),
            ]))
            ->setTag("Rotation", new ListTag([
                new FloatTag($sender->getLocation()->getYaw()),
                new FloatTag(0.0),
            ]))
            ->setString("RcCaseNpc", $type);

        $skinData = $sender->getSkin();
        $skin = new Skin(
            $skinData->getSkinId(),
            $skinData->getSkinData(),
            $skinData->getCapeData(),
            $skinData->getGeometryName(),
            $skinData->getGeometryData()
        );

        $entity = new Human(EntityDataHelper::parseLocation($nbt, $world), $skin, $nbt);

        $npcName = ($type === "daily")
            ? $this->cfg->getNested("npc.daily-name", "§l§bЕжедневные кейсы")
            : $this->cfg->getNested("npc.normal-name", "§l§6Кейсы");

        $entity->setNameTag($npcName);
        $entity->setNameTagAlwaysVisible(true);
        $entity->setNoClientPredictions(true);

        $entity->spawnToAll();

        if ($type === "daily") {
            $this->dailyCaseEntities[$entity->getId()] = 1;
            $sender->sendMessage("§l§bНПС с ежедневными кейсами установлен");
        } else {
            $this->caseEntities[$entity->getId()] = 1;
            $sender->sendMessage("§l§6НПС с кейсами установлен");
        }

        $world->addParticle($pos, new HugeExplodeSeedParticle());
        $world->addSound($pos, new EndermanTeleportSound());

        return true;
    }

    private function handleGiveCaseCommand(CommandSender $sender, array $args): bool {
        if (count($args) < 2) {
            $sender->sendMessage("§l§6Использование:");
            $sender->sendMessage("§l§e/rcgivecase <ник> <+число|-число|-> [1/2] [1]");
            $sender->sendMessage("§l§71 §8- §7обычный ключ, §l§72 §8- §7ежедневный");
            $sender->sendMessage("§l§7В конце §e1 §8- §7выдать всем онлайн");
            return true;
        }

        $targetName = $args[0];
        $action = $args[1];
        $keyType = (int)($args[2] ?? 1);
        $toAll = (($args[3] ?? "") === "1") || (($args[2] ?? "") === "1" && !isset($args[3]));

        $isDaily = ($keyType === 2);

        if ($toAll || $targetName === "1") {
            $amount = 1;
            if (str_starts_with($action, "+")) {
                $amount = (int)substr($action, 1);
                if ($amount <= 0) $amount = 1;
            } elseif (is_numeric($action)) {
                $amount = (int)$action;
            }

            $count = 0;
            foreach ($this->getServer()->getOnlinePlayers() as $player) {
                if ($isDaily) {
                    $this->addDailyKeys($player->getName(), $amount);
                } else {
                    $this->addKeys($player->getName(), $amount);
                }
                $player->sendMessage("§l§aВам выдано §e{$amount} §a" . ($isDaily ? "ежедневных " : "") . "ключей");
                $player->getWorld()->addSound($player->getPosition(), new XpLevelUpSound(10));
                $count++;
            }

            $typeName = $isDaily ? "ежедневных" : "обычных";
            $sender->sendMessage("§l§aВыдано §e{$amount} §a{$typeName} ключей §e{$count} §aигрокам");
            return true;
        }

        if (str_starts_with($action, "+")) {
            $amount = (int)substr($action, 1);
            if ($amount <= 0) $amount = 1;

            if ($isDaily) {
                $this->addDailyKeys($targetName, $amount);
                $total = $this->getDailyKeys($targetName);
            } else {
                $this->addKeys($targetName, $amount);
                $total = $this->getKeys($targetName);
            }

            $typeName = $isDaily ? "ежедневных" : "";
            $sender->sendMessage("§l§aВыдано §e{$amount} §a{$typeName} ключей игроку §6{$targetName}§a, итого: §e{$total}");

            $target = $this->getServer()->getPlayerExact($targetName);
            if ($target !== null) {
                $target->sendMessage("§l§aВам выдано §e{$amount} §a{$typeName} ключей от кейсов");
                $target->getWorld()->addSound($target->getPosition(), new XpLevelUpSound(10));
            }
        } elseif ($action === "-") {
            if ($isDaily) {
                $old = $this->getDailyKeys($targetName);
                $this->setDailyKeys($targetName, 0);
            } else {
                $old = $this->getKeys($targetName);
                $this->setKeys($targetName, 0);
            }
            $sender->sendMessage("§l§cВсе ключи игрока §6{$targetName} §cаннулированы §7(было: {$old})");

            $target = $this->getServer()->getPlayerExact($targetName);
            if ($target !== null) {
                $target->sendMessage("§l§cВаши ключи от кейсов аннулированы");
            }
        } elseif (str_starts_with($action, "-")) {
            $amount = (int)substr($action, 1);
            if ($amount <= 0) $amount = 1;

            if ($isDaily) {
                $current = $this->getDailyKeys($targetName);
                $newAmount = max(0, $current - $amount);
                $this->setDailyKeys($targetName, $newAmount);
            } else {
                $current = $this->getKeys($targetName);
                $newAmount = max(0, $current - $amount);
                $this->setKeys($targetName, $newAmount);
            }

            $removed = $current - $newAmount;
            $sender->sendMessage("§l§cУбрано §e{$removed} §cключей у §6{$targetName}§c, осталось: §e{$newAmount}");
        } else {
            $sender->sendMessage("§l§cНеверный формат");
        }

        return true;
    }

    private function handleBoostCommand(CommandSender $sender): bool {
        $this->boostEnabled = !$this->boostEnabled;
        $status = $this->boostEnabled ? "§l§aвключен" : "§l§cвыключен";
        $mult = $this->cfg->get("boost-multiplier", 1.3);
        
        $this->getServer()->broadcastMessage("§l§6Буст удачи " . $status . " §7(x{$mult})");
        return true;
    }

    private function handleWandCaseCommand(CommandSender $sender): bool {
        if (!($sender instanceof Player)) {
            $sender->sendMessage("§l§cТолько для игроков!");
            return true;
        }

        $this->showPendingGiftsForm($sender);
        return true;
    }

    private function handleRemoveCommand(CommandSender $sender): bool {
        if (!($sender instanceof Player)) {
            $sender->sendMessage("§l§cТолько для игроков!");
            return true;
        }

        $sender->sendMessage("§l§eУдарьте НПС кейсов чтобы удалить его");
        return true;
    }

    // ==================== НПС НАЖАТИЕ ====================

    public function onEntityDamage(EntityDamageEvent $event): void {
        $entity = $event->getEntity();
        
        $npcType = null;
        
        if (isset($this->caseEntities[$entity->getId()])) {
            $npcType = "normal";
        } elseif (isset($this->dailyCaseEntities[$entity->getId()])) {
            $npcType = "daily";
        } elseif ($entity instanceof Human) {
            $nbt = $entity->saveNBT();
            $tag = $nbt->getString("RcCaseNpc", "");
            if ($tag === "normal") {
                $this->caseEntities[$entity->getId()] = 1;
                $npcType = "normal";
            } elseif ($tag === "daily") {
                $this->dailyCaseEntities[$entity->getId()] = 1;
                $npcType = "daily";
            }
        }
        
        if ($npcType === null) return;

        $event->cancel();

        if (!($event instanceof EntityDamageByEntityEvent)) return;

        $damager = $event->getDamager();
        if (!($damager instanceof Player)) return;

        $playerName = strtolower($damager->getName());

        // Проверяем только этого игрока
        if (isset($this->spinningPlayers[$playerName])) {
            $damager->sendMessage("§l§cПодождите, ваш кейс ещё крутится");
            return;
        }

        $this->openCaseForm($damager, $npcType);
    }

    // ==================== ФОРМЫ ====================

    private function openCaseForm(Player $player, string $type): void {
        $isDaily = ($type === "daily");
        $keys = $isDaily ? $this->getDailyKeys($player->getName()) : $this->getKeys($player->getName());
        $totalSpins = $this->getTotalSpins($player->getName());
        $guaranteeCount = $this->getGuaranteeCount($player->getName());
        $untilGuarantee = max(0, 50 - $guaranteeCount);

        $form = new SimpleForm(function (Player $player, ?int $data) use ($isDaily, $keys) {
            if ($data === null) return;

            if ($data === 0) {
                $this->startCaseSpin($player, $isDaily ? "daily" : "normal", 1);
            } elseif ($data === 1) {
                $this->openMultiSpinForm($player, $isDaily ? "daily" : "normal", $keys);
            }
        });

        $title = $isDaily ? "§l§bЕжедневные кейсы" : "§l§6Кейсы";
        $form->setTitle($title);

        $content = "";
        
        if ($isDaily) {
            $content .= "§l§bДоступные призы:\n\n";
            $content .= "§l§aFLEX §8- §7маленький шанс\n";
            $content .= "§l§eLUFFY §8- §7очень маленький шанс\n";
            $content .= "§l§6APEX §8- §7крошечный шанс\n\n";
        } else {
            $content .= "§l§6Доступные привилегии:\n\n";
            $content .= "§l§aFLEX §8- §7обычная\n";
            $content .= "§l§eLUFFY §8- §7редкая\n";
            $content .= "§l§6APEX §8- §7эпическая\n";
            $content .= "§l§dNEXUS §8- §7легендарная\n";
            $content .= "§l§5MIRAGE §8- §7мифическая\n";
            $content .= "§l§4SPARK §8- §7божественная\n\n";
        }

        $content .= "§l§aДенежные призы:\n\n";
        $content .= "§l§a10,000$ §8/ §l§e50,000$ §8/ §l§6100,000$\n";
        $content .= "§l§d500,000$ §8/ §l§c1,000,000$\n\n";
        $content .= "§l§bПерекрут §8- §7бонусный ключ\n\n";
        $content .= "§l§7Всего открыто: §e{$totalSpins}\n";
        
        if (!$isDaily) {
            $content .= "§l§7До гаранта привы: §a{$untilGuarantee}\n";
        }
        
        if ($this->boostEnabled) {
            $content .= "\n§l§dБуст удачи активен!\n";
        }

        $form->setContent($content);

        $form->addButton("§l§aОткрыть кейс\n§r§l§7Ключей: §e{$keys}");
        $form->addButton("§l§eОткрыть несколько\n§r§l§7Выбрать количество");
        $form->addButton("§l§cЗакрыть");

        $player->sendForm($form);
    }

    private function openMultiSpinForm(Player $player, string $type, int $maxKeys): void {
        $form = new SimpleForm(function (Player $player, ?int $data) use ($type, $maxKeys) {
            if ($data === null) return;

            $amounts = [3, 6, 9, 12, 15, 18, 21, 24, 27, 30, 33, 36, 39, 42, 45, 48, 50];
            if (isset($amounts[$data])) {
                $count = $amounts[$data];
                if ($count <= $maxKeys) {
                    $this->startCaseSpin($player, $type, $count);
                } else {
                    $player->sendMessage("§l§cНедостаточно ключей!");
                }
            }
        });

        $form->setTitle("§l§eВыберите количество");

        $amounts = [3, 6, 9, 12, 15, 18, 21, 24, 27, 30, 33, 36, 39, 42, 45, 48, 50];
        foreach ($amounts as $amount) {
            $available = $amount <= $maxKeys;
            $color = $available ? "§a" : "§c";
            $form->addButton("§l{$color}{$amount} кейсов\n§r§l§7" . ($available ? "Доступно" : "Недостаточно"));
        }

        $player->sendForm($form);
    }

    private function showPendingGiftsForm(Player $player): void {
        $pending = $this->getPendingGifts($player->getName());

        if (empty($pending)) {
            $player->sendMessage("§l§7У вас нет привилегий для подарка");
            return;
        }

        $form = new SimpleForm(function (Player $player, ?int $data) {
            if ($data === null) return;

            $pending = $this->getPendingGifts($player->getName());
            if (!isset($pending[$data])) return;

            $gift = $pending[$data];
            $this->showGiftTargetForm($player, $data, $gift);
        });

        $form->setTitle("§l§dПодарить привилегию");
        $form->setContent("§l§7Выберите привилегию для подарка:\n§l§8Можно дарить до §eAPEX §8раз в §e10.5 дней");

        foreach ($pending as $i => $gift) {
            $form->addButton($gift["color"] . "§l" . $gift["priv"]);
        }

        $form->addButton("§l§cЗакрыть");

        $player->sendForm($form);
    }

    private function showGiftTargetForm(Player $player, int $giftIndex, array $gift): void {
        if (!$this->canGiftPrivilege($player->getName())) {
            $player->sendMessage("§l§cВы недавно дарили привилегию, подождите 10.5 дней");
            return;
        }

        $form = new CustomForm(function (Player $player, ?array $data) use ($giftIndex, $gift) {
            if ($data === null) return;

            $targetName = trim($data[0] ?? "");
            if ($targetName === "") {
                $player->sendMessage("§l§cВведите ник игрока");
                return;
            }

            $this->giftPrivilegeToPlayer($player, $targetName, $giftIndex, $gift);
        });

        $form->setTitle("§l§dПодарить " . $gift["color"] . $gift["priv"]);
        $form->addInput("§l§7Введите ник игрока:", "Ник");

        $player->sendForm($form);
    }

    private function giftPrivilegeToPlayer(Player $fromPlayer, string $targetName, int $giftIndex, array $gift): void {
        $target = $this->getServer()->getPlayerExact($targetName);
        
        if ($target === null) {
            $fromPlayer->sendMessage("§l§cИгрок не в сети");
            return;
        }

        if (strtolower($target->getName()) === strtolower($fromPlayer->getName())) {
            $fromPlayer->sendMessage("§l§cНельзя подарить себе");
            return;
        }

        $rcGroup = $this->getServer()->getPluginManager()->getPlugin("RcGroup");
        if ($rcGroup !== null && $rcGroup->isEnabled()) {
            $rcGroup->setGroup($target->getName(), $gift["group"]);
        }

        $this->removePendingGift($fromPlayer->getName(), $giftIndex);
        $this->setGiftCooldown($fromPlayer->getName());

        $label = $gift["color"] . "§l" . $gift["priv"];
        
        $fromPlayer->sendMessage("§l§aВы подарили §6{$target->getName()} §aпривилегию {$label}");
        $target->sendMessage("§l§6{$fromPlayer->getName()} §aподарил вам привилегию {$label}");
        $target->getWorld()->addSound($target->getPosition(), new XpLevelUpSound(30));
    }

    // ==================== ОТКРЫТИЕ КЕЙСА ====================

    public function startCaseSpin(Player $player, string $type, int $count): void {
        $name = $player->getName();
        $nameLower = strtolower($name);
        $isDaily = ($type === "daily");

        $keys = $isDaily ? $this->getDailyKeys($name) : $this->getKeys($name);

        if ($keys < $count) {
            $player->sendMessage("§l§cНедостаточно ключей!");
            $player->getWorld()->addSound($player->getPosition(), new FizzSound());
            return;
        }

        // Проверяем только этого игрока
        if (isset($this->spinningPlayers[$nameLower])) {
            $player->sendMessage("§l§cПодождите, ваш кейс ещё крутится");
            return;
        }

        // Забираем ключи
        if ($isDaily) {
            $this->removeDailyKeys($name, $count);
        } else {
            $this->removeKeys($name, $count);
        }

        $this->spinningPlayers[$nameLower] = true;
        $this->incrementTotalSpins($name, $count);

        if ($count === 1) {
            $guaranteeCount = $this->incrementGuarantee($name);
            $prize = $this->determinePrize($player, $guaranteeCount, $isDaily);
            $this->animateSpin($player, $prize, $type);
        } else {
            $this->processMultiSpin($player, $type, $count);
        }
    }

    private function processMultiSpin(Player $player, string $type, int $count): void {
        $name = $player->getName();
        $nameLower = strtolower($name);
        $isDaily = ($type === "daily");

        $totalMoney = 0;
        $bestPriv = null;
        $bestPrivRep = 0;
        $rerolls = 0;
        $giftsToAdd = [];

        for ($i = 0; $i < $count; $i++) {
            if (!$isDaily) {
                $guaranteeCount = $this->incrementGuarantee($name);
            } else {
                $guaranteeCount = 0;
            }

            $prize = $this->determinePrize($player, $guaranteeCount, $isDaily);

            switch ($prize["type"]) {
                case "money":
                    $totalMoney += $prize["amount"];
                    break;
                case "privilege":
                    $privRep = $this->getPrivilegeReputation($prize["group"]);
                    if ($privRep > $bestPrivRep) {
                        $bestPrivRep = $privRep;
                        $bestPriv = $prize;
                    }
                    break;
                case "reroll":
                    $rerolls++;
                    break;
                case "gift":
                    $giftsToAdd[] = $prize;
                    break;
            }
        }

        // Выдаём результаты
        if ($totalMoney > 0) {
            $economy = $this->getServer()->getPluginManager()->getPlugin("EconomyAPI");
            if ($economy !== null && $economy->isEnabled()) {
                $economy->addMoney($name, $totalMoney);
            }
        }

        if ($bestPriv !== null) {
            $rcGroup = $this->getServer()->getPluginManager()->getPlugin("RcGroup");
            if ($rcGroup !== null && $rcGroup->isEnabled()) {
                $rcGroup->setGroup($name, $bestPriv["group"]);
            }
            if (!$isDaily) {
                $this->resetGuarantee($name);
            }
        }

        if ($rerolls > 0) {
            if ($isDaily) {
                $this->addDailyKeys($name, $rerolls);
            } else {
                $this->addKeys($name, $rerolls);
            }
        }

        foreach ($giftsToAdd as $gift) {
            $this->addPendingGift($name, $gift["name"], $gift["group"], $gift["color"]);
        }

        $this->showMultiSpinResults($player, $count, $totalMoney, $bestPriv, $rerolls, count($giftsToAdd));

        // Освобождаем игрока
        unset($this->spinningPlayers[$nameLower]);
    }

    private function showMultiSpinResults(Player $player, int $count, int $totalMoney, ?array $bestPriv, int $rerolls, int $gifts): void {
        $name = $player->getName();

        $player->sendMessage("§l§6Результаты открытия §e{$count} §6кейсов:");
        
        if ($totalMoney > 0) {
            $moneyFormatted = number_format($totalMoney, 0, "", ",");
            $player->sendMessage("§l§aПолучено денег: §e{$moneyFormatted}$");
        }

        if ($bestPriv !== null) {
            $player->sendMessage("§l§dЛучшая привилегия: " . $bestPriv["color"] . "§l" . $bestPriv["name"]);
        }

        if ($rerolls > 0) {
            $player->sendMessage("§l§bПерекрутов: §e{$rerolls}");
        }

        if ($gifts > 0) {
            $player->sendMessage("§l§5Привилегий для подарка: §e{$gifts} §7(/rcwandcase)");
        }

        $pos = $player->getPosition();
        $world = $player->getWorld();
        
        $world->addParticle($pos->add(0, 1, 0), new HugeExplodeSeedParticle());
        $world->addSound($pos, new XpLevelUpSound(30));

        // Бродкаст
        if ($totalMoney >= 500000 || $bestPriv !== null) {
            if ($bestPriv !== null) {
                $broadcast = $this->cfg->get("broadcast-multi-priv", "");
                $broadcast = str_replace(
                    ["{player}", "{count}", "{prize}"],
                    [$name, $count, $bestPriv["color"] . "§l" . $bestPriv["name"]],
                    $broadcast
                );
            } else {
                $broadcast = $this->cfg->get("broadcast-multi", "");
                $broadcast = str_replace(
                    ["{player}", "{count}", "{money}"],
                    [$name, $count, number_format($totalMoney, 0, "", ",")],
                    $broadcast
                );
            }
            $this->getServer()->broadcastMessage($broadcast);
        }
    }

    // ==================== ОПРЕДЕЛЕНИЕ ПРИЗА ====================

    private function determinePrize(Player $player, int $guaranteeCount, bool $isDaily): array {
        $playerName = $player->getName();
        $guaranteedSpin = (int)$this->cfg->get("guaranteed-spin", 50);

        $boostMult = $this->boostEnabled ? (float)$this->cfg->get("boost-multiplier", 1.3) : 1.0;

        if (!$isDaily && $guaranteeCount >= $guaranteedSpin) {
            $prize = $this->getRandomPrivilege($player, true, $isDaily);
            $this->resetGuarantee($playerName);
            return $prize;
        }

        $roll = mt_rand(1, 10000);
        $cumulative = 0;

        $rerollChance = (int)($this->cfg->get("reroll-chance", 135) * $boostMult);
        $cumulative += $rerollChance;
        if ($roll <= $cumulative) {
            return [
                "type" => "reroll",
                "label" => "§l§bПерекрут",
                "color" => "§b",
                "amount" => 1,
            ];
        }

        $privileges = $isDaily ? $this->cfg->get("daily-privileges", []) : $this->cfg->get("privileges", []);
        $allPrivileges = $this->cfg->get("privileges", []);

        foreach ($privileges as $privName => $privData) {
            $chance = (int)(($privData["chance"] ?? 0) * $boostMult);
            $cumulative += $chance;
            
            if ($roll <= $cumulative) {
                $fullData = $allPrivileges[$privName] ?? $privData;
                $prizeGroup = $fullData["group"] ?? $privName;
                
                $result = $this->checkPrivilegeResult($playerName, $privName, $prizeGroup, $fullData);
                if ($result !== null) {
                    return $result;
                }
                
                if (!$isDaily) {
                    $this->resetGuarantee($playerName);
                }
                
                return [
                    "type" => "privilege",
                    "name" => $privName,
                    "group" => $prizeGroup,
                    "color" => $fullData["color"] ?? "§a",
                    "label" => ($fullData["color"] ?? "§a") . "§l" . $privName,
                ];
            }
        }

        $moneyPrizes = $isDaily ? $this->cfg->get("daily-money", []) : $this->cfg->get("money", []);
        $moneyRoll = mt_rand(1, 10000);
        $mCum = 0;

        foreach ($moneyPrizes as $amount => $mData) {
            $mCum += (int)$mData["chance"];
            if ($moneyRoll <= $mCum) {
                return [
                    "type" => "money",
                    "amount" => (int)$amount,
                    "label" => $mData["label"],
                    "color" => "§a",
                ];
            }
        }

        return [
            "type" => "money",
            "amount" => 10000,
            "label" => "§l§a10,000$",
            "color" => "§a",
        ];
    }

    private function checkPrivilegeResult(string $playerName, string $privName, string $prizeGroup, array $privData): ?array {
        $playerRep = $this->getPlayerReputation($playerName);
        $prizeRep = $this->getPrivilegeReputation($prizeGroup);

        if ($prizeRep <= $playerRep) {
            $giftChance = (int)$this->cfg->get("gift-chance", 50);
            $canGift = $privData["canGift"] ?? false;

            if ($canGift && mt_rand(1, 1000) <= $giftChance && $this->canGiftPrivilege($playerName)) {
                return [
                    "type" => "gift",
                    "name" => $privName,
                    "group" => $prizeGroup,
                    "color" => $privData["color"] ?? "§a",
                    "label" => ($privData["color"] ?? "§a") . "§l" . $privName,
                ];
            }

            return [
                "type" => "reroll",
                "label" => "§l§bПерекрут",
                "color" => "§b",
                "amount" => 1,
                "reason" => "duplicate",
            ];
        }

        return null;
    }

    private function getRandomPrivilege(Player $player, bool $guaranteed, bool $isDaily): array {
        $privileges = $this->cfg->get("privileges", []);
        $playerName = $player->getName();
        $playerRep = $this->getPlayerReputation($playerName);

        $availablePrivs = [];
        foreach ($privileges as $pName => $pData) {
            $privRep = $this->getPrivilegeReputation($pData["group"] ?? $pName);
            if ($privRep > $playerRep) {
                $availablePrivs[$pName] = $pData;
            }
        }

        if (empty($availablePrivs)) {
            return [
                "type" => "reroll",
                "label" => "§l§bПерекрут",
                "color" => "§b",
                "amount" => 1,
                "reason" => "max_rank",
            ];
        }

        if ($guaranteed) {
            $weights = [];
            foreach ($availablePrivs as $pName => $pData) {
                $weights[$pName] = max(1, 1000 - (int)($pData["chance"] ?? 100));
            }

            $totalWeight = array_sum($weights);
            $roll = mt_rand(1, $totalWeight);
            $cum = 0;

            foreach ($weights as $pName => $w) {
                $cum += $w;
                if ($roll <= $cum) {
                    return [
                        "type" => "privilege",
                        "name" => $pName,
                        "group" => $availablePrivs[$pName]["group"] ?? $pName,
                        "color" => $availablePrivs[$pName]["color"] ?? "§a",
                        "label" => ($availablePrivs[$pName]["color"] ?? "§a") . "§l" . $pName,
                        "guaranteed" => true,
                    ];
                }
            }
        }

        $first = array_key_first($availablePrivs);
        return [
            "type" => "privilege",
            "name" => $first,
            "group" => $availablePrivs[$first]["group"] ?? $first,
            "color" => $availablePrivs[$first]["color"] ?? "§a",
            "label" => ($availablePrivs[$first]["color"] ?? "§a") . "§l" . $first,
        ];
    }

    // ==================== АНИМАЦИЯ ====================

    private function animateSpin(Player $player, array $prize, string $type): void {
        $playerName = strtolower($player->getName());
        
        $player->sendMessage("§l§6Кейс открывается...");
        $player->getWorld()->addSound($player->getPosition(), new ClickSound());

        $plugin = $this;
        $step = 0;
        $totalSteps = 8;

        $handler = $this->getScheduler()->scheduleRepeatingTask(new ClosureTask(
            function () use ($plugin, $player, $prize, $type, &$step, $totalSteps, $playerName): void {
                if (!$player->isOnline()) {
                    unset($plugin->spinningPlayers[$playerName]);
                    if (isset($plugin->playerTaskHandlers[$playerName])) {
                        $plugin->playerTaskHandlers[$playerName]->cancel();
                        unset($plugin->playerTaskHandlers[$playerName]);
                    }
                    return;
                }

                $step++;
                $pos = $player->getPosition();
                $world = $player->getWorld();

                if ($step <= $totalSteps) {
                    $msg = self::SPIN_MESSAGES_STAGE[$step] ?? "§l§7Открытие...";
                    $bar = "§e" . str_repeat("|", $step) . "§7" . str_repeat("|", $totalSteps - $step);
                    $player->sendMessage("§7[{$bar}§7] " . $msg);

                    $world->addSound($pos, new ClickSound());

                    $angle = $step * (M_PI / 4);
                    $radius = 2.0;
                    for ($i = 0; $i < 4; $i++) {
                        $a = $angle + ($i * M_PI / 2);
                        $particlePos = $pos->add(
                            cos($a) * $radius,
                            1.5 + sin($step * 0.5) * 0.5,
                            sin($a) * $radius
                        );
                        $world->addParticle($particlePos, new FlameParticle());
                        $world->addParticle($particlePos, new RedstoneParticle($step * 2));
                    }

                    for ($j = 0; $j < 3; $j++) {
                        $sa = ($step * 0.8) + ($j * M_PI * 2 / 3);
                        $sr = 1.0 + ($step * 0.15);
                        $sPos = $pos->add(
                            cos($sa) * $sr,
                            0.5 + ($step * 0.25),
                            sin($sa) * $sr
                        );
                        $world->addParticle($sPos, new DustParticle(new Color(255, 215, 0)));
                    }

                    $progress = str_repeat("§e|", $step) . str_repeat("§7|", $totalSteps - $step);
                    $player->sendTip("§l§6Крутим... §r§7[{$progress}§7]");

                } elseif ($step === $totalSteps + 1) {
                    $plugin->revealPrize($player, $prize, $type);
                    unset($plugin->spinningPlayers[$playerName]);
                    if (isset($plugin->playerTaskHandlers[$playerName])) {
                        $plugin->playerTaskHandlers[$playerName]->cancel();
                        unset($plugin->playerTaskHandlers[$playerName]);
                    }
                }
            }
        ), 5);

        $this->playerTaskHandlers[$playerName] = $handler;
    }

    public function revealPrize(Player $player, array $prize, string $type): void {
        $pos = $player->getPosition();
        $world = $player->getWorld();

        $player->sendTip("");

        $world->addParticle($pos->add(0, 1, 0), new HugeExplodeSeedParticle());
        $world->addParticle($pos->add(0, 2, 0), new HugeExplodeParticle());

        for ($i = 0; $i < 36; $i++) {
            $angle = deg2rad($i * 10);
            $px = $pos->getX() + cos($angle) * 3;
            $pz = $pos->getZ() + sin($angle) * 3;
            $world->addParticle(new Vector3($px, $pos->getY() + 1, $pz), new FlameParticle());
            $world->addParticle(new Vector3($px, $pos->getY() + 1.5, $pz), new LavaParticle());
        }

        for ($y = 0; $y < 5; $y++) {
            $world->addParticle($pos->add(0, $y, 0), new DustParticle(new Color(148, 0, 211)));
            $world->addParticle($pos->add(0, $y, 0), new RedstoneParticle(15));
        }

        for ($i = 0; $i < 8; $i++) {
            $world->addParticle($pos->add(
                mt_rand(-20, 20) / 10,
                mt_rand(10, 30) / 10,
                mt_rand(-20, 20) / 10
            ), new HeartParticle());
        }

        $world->addSound($pos, new XpLevelUpSound(30));
        $world->addSound($pos, new ExplodeSound());

        $isDaily = ($type === "daily");

        switch ($prize["type"]) {
            case "privilege":
                $this->givePrivilege($player, $prize, $isDaily);
                break;
            case "money":
                $this->giveMoney($player, $prize);
                break;
            case "reroll":
                $this->giveReroll($player, $prize, $isDaily);
                break;
            case "gift":
                $this->giveGiftOption($player, $prize);
                break;
        }

        $this->getScheduler()->scheduleDelayedTask(new ClosureTask(
            function () use ($player, $pos, $world): void {
                if ($player->isOnline()) {
                    for ($i = 0; $i < 12; $i++) {
                        $world->addParticle($pos->add(
                            mt_rand(-30, 30) / 10,
                            mt_rand(5, 25) / 10,
                            mt_rand(-30, 30) / 10
                        ), new SmokeParticle());
                    }
                    $world->addSound($pos, new PopSound());
                }
            }
        ), 10);
    }

    // ==================== ВЫДАЧА ПРИЗОВ ====================

    private function givePrivilege(Player $player, array $prize, bool $isDaily): void {
        $playerName = $player->getName();
        $privName = $prize["name"];
        $groupName = $prize["group"];
        $label = $prize["label"];
        $guaranteed = $prize["guaranteed"] ?? false;

        $rcGroup = $this->getServer()->getPluginManager()->getPlugin("RcGroup");
        if ($rcGroup !== null && $rcGroup->isEnabled()) {
            $rcGroup->setGroup($playerName, $groupName);
        }

        $player->sendTitle("§l§6Привилегия!", $label, 20, 60, 20);

        $player->sendMessage("§l§6Поздравляем!");
        $player->sendMessage("§l§7Вы выиграли привилегию: " . $label);
        if ($guaranteed) {
            $player->sendMessage("§l§aГарантированный выигрыш!");
        }

        $funny = self::FUNNY_MESSAGES[array_rand(self::FUNNY_MESSAGES)];
        $player->sendMessage($funny);

        $broadcast = $this->cfg->get("broadcast-privilege", "");
        $broadcast = str_replace(["{player}", "{prize}"], [$playerName, $label], $broadcast);
        $this->getServer()->broadcastMessage($broadcast);

        if (!$isDaily) {
            $this->resetGuarantee($playerName);
        }

        $player->getWorld()->addSound($player->getPosition(), new BlazeShootSound());
    }

    private function giveMoney(Player $player, array $prize): void {
        $playerName = $player->getName();
        $amount = $prize["amount"];
        $label = $prize["label"];

        $economy = $this->getServer()->getPluginManager()->getPlugin("EconomyAPI");
        if ($economy !== null && $economy->isEnabled()) {
            $economy->addMoney($playerName, $amount);
        }

        $player->sendTitle("§l§aДеньги!", $label, 20, 60, 20);

        $player->sendMessage("§l§aВыигрыш!");
        $player->sendMessage("§l§7Вы получили: " . $label);

        if ($amount >= 500000) {
            $funny = self::FUNNY_MESSAGES[array_rand(self::FUNNY_MESSAGES)];
            $player->sendMessage($funny);

            $broadcast = $this->cfg->get("broadcast-money", "");
            $broadcast = str_replace(["{player}", "{prize}"], [$playerName, $label], $broadcast);
            $this->getServer()->broadcastMessage($broadcast);

            $player->getWorld()->addSound($player->getPosition(), new AnvilFallSound());
        }
    }

    private function giveReroll(Player $player, array $prize, bool $isDaily): void {
        $playerName = $player->getName();
        $reason = $prize["reason"] ?? null;

        if ($isDaily) {
            $this->addDailyKeys($playerName, 1);
        } else {
            $this->addKeys($playerName, 1);
        }

        $player->sendTitle("§l§bПерекрут!", "§l§7Вам вернулся ключ", 20, 60, 20);

        $player->sendMessage("§l§bПерекрут!");
        
        if ($reason === "duplicate") {
            $player->sendMessage("§l§7У вас уже есть эта или более высокая привилегия");
            $player->sendMessage("§l§7Вам возвращен ключ");
        } elseif ($reason === "max_rank") {
            $player->sendMessage("§l§7У вас максимальная привилегия");
            $player->sendMessage("§l§7Вам возвращен ключ");
        } else {
            $player->sendMessage("§l§7Вам выпал бонусный ключ");
            $player->sendMessage("§l§7Крутите снова, удача на вашей стороне");
        }

        $player->getWorld()->addSound($player->getPosition(), new EndermanTeleportSound());

        for ($i = 0; $i < 20; $i++) {
            $player->getWorld()->addParticle($player->getPosition()->add(
                mt_rand(-25, 25) / 10,
                mt_rand(5, 30) / 10,
                mt_rand(-25, 25) / 10
            ), new DustParticle(new Color(0, 191, 255)));
        }
    }

    private function giveGiftOption(Player $player, array $prize): void {
        $playerName = $player->getName();

        $this->addPendingGift($playerName, $prize["name"], $prize["group"], $prize["color"]);

        $player->sendTitle("§l§5Подарок!", $prize["label"], 20, 60, 20);

        $player->sendMessage("§l§5Вы получили привилегию для подарка!");
        $player->sendMessage("§l§7У вас уже есть такая или выше, но вы можете подарить её другу");
        $player->sendMessage("§l§eИспользуйте §6/rcwandcase §eчтобы подарить");

        $player->getWorld()->addSound($player->getPosition(), new EndermanTeleportSound());
    }
}
