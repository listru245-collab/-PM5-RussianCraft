<?php
declare(strict_types=1);

namespace InzeOwr\RcDar;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\entity\effect\EffectInstance;
use pocketmine\entity\effect\VanillaEffects;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\player\GameMode;
use pocketmine\player\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\scheduler\ClosureTask;
use pocketmine\scheduler\TaskHandler;
use pocketmine\utils\Config;
use pocketmine\utils\TextFormat as C;

class Main extends PluginBase implements Listener {

    private Config $cfg;
    private Config $dataCfg;

    /** @var array<string, bool> */
    private array $flyActive = [];

    /** @var array<string, int> */
    private array $flyTimeLeft = [];

    /** @var array<string, bool> */
    private array $speedActive = [];

    /** @var array<string, int> */
    private array $speedTimeLeft = [];

    /** @var array<string, bool> */
    private array $vanishActive = [];

    /** @var TaskHandler|null */
    private ?TaskHandler $tickTask = null;

    public function onEnable(): void {
        @mkdir($this->getDataFolder());

        $this->saveResource("config.yml");

        $this->cfg = new Config($this->getDataFolder() . "config.yml", Config::YAML);
        $this->dataCfg = new Config($this->getDataFolder() . "data.yml", Config::YAML);

        $this->getServer()->getPluginManager()->registerEvents($this, $this);

        $this->tickTask = $this->getScheduler()->scheduleRepeatingTask(
            new ClosureTask(function(): void {
                $this->onTick();
            }),
            20 // каждую секунду
        );
    }

    public function onDisable(): void {
        if (isset($this->dataCfg)) {
            $this->dataCfg->save();
        }

        foreach ($this->getServer()->getOnlinePlayers() as $player) {
            $this->disableFly($player, false);
            $this->disableSpeed($player, false);
            $this->disableVanish($player, false);
        }
    }

    /**
     * Получить плагин RcGroup
     */
    private function getRcGroup(): ?\InzeOwr\RcGroup\Main {
        $plugin = $this->getServer()->getPluginManager()->getPlugin("RcGroup");
        if ($plugin !== null && $plugin->isEnabled() && $plugin instanceof \InzeOwr\RcGroup\Main) {
            return $plugin;
        }
        return null;
    }

    /**
     * Получить группу игрока через RcGroup
     */
    private function getPlayerGroup(string $nickname): string {
        $rcGroup = $this->getRcGroup();
        if ($rcGroup !== null) {
            return $rcGroup->getGroup($nickname);
        }
        return "Игрок";
    }

    /**
     * Получить настройки привилегии из конфига
     */
    private function getGroupConfig(string $group): ?array {
        $groups = $this->cfg->get("groups", []);
        return $groups[$group] ?? null;
    }

    /**
     * Получить сообщение из конфига
     */
    private function getMessage(string $key, array $replace = []): string {
        $messages = $this->cfg->get("messages", []);
        $msg = $messages[$key] ?? "§cСообщение '$key' не найдено.";
        foreach ($replace as $k => $v) {
            $msg = str_replace($k, (string)$v, $msg);
        }
        return $msg;
    }

    /**
     * Форматировать время
     */
    private function formatTime(int $seconds): string {
        if ($seconds < 0) {
            return "∞";
        }
        $h = intdiv($seconds, 3600);
        $m = intdiv($seconds % 3600, 60);
        $s = $seconds % 60;

        if ($h > 0) {
            return sprintf("%dч %dм %dс", $h, $m, $s);
        } elseif ($m > 0) {
            return sprintf("%dм %dс", $m, $s);
        }
        return sprintf("%dс", $s);
    }

    // ========================
    // СОБЫТИЯ
    // ========================

    public function onJoin(PlayerJoinEvent $event): void {
        $player = $event->getPlayer();
        $name = strtolower($player->getName());

        // Восстановить состояния если были активны (сохранены в data)
        $savedFly = $this->dataCfg->getNested("active_fly.$name");
        if ($savedFly !== null && $savedFly > 0) {
            $this->flyActive[$name] = true;
            $this->flyTimeLeft[$name] = (int)$savedFly;
            $player->setAllowFlight(true);
            $player->setFlying(true);
            $player->sendMessage($this->getMessage("fly_enabled", [
                "{time}" => $this->formatTime((int)$savedFly)
            ]));
        }

        $savedSpeed = $this->dataCfg->getNested("active_speed.$name");
        if ($savedSpeed !== null && $savedSpeed > 0) {
            $this->speedActive[$name] = true;
            $this->speedTimeLeft[$name] = (int)$savedSpeed;
            $this->applySpeedEffect($player);
            $player->sendMessage($this->getMessage("speed_enabled", [
                "{time}" => $this->formatTime((int)$savedSpeed)
            ]));
        }
    }

    public function onQuit(PlayerQuitEvent $event): void {
        $player = $event->getPlayer();
        $name = strtolower($player->getName());

        // Сохранить оставшееся время
        if (isset($this->flyActive[$name]) && $this->flyActive[$name]) {
            $timeLeft = $this->flyTimeLeft[$name] ?? 0;
            if ($timeLeft > 0) {
                $this->dataCfg->setNested("active_fly.$name", $timeLeft);
            } else if ($timeLeft < 0) {
                // бесконечный - не сохраняем, просто выключаем
                $this->dataCfg->removeNested("active_fly.$name");
            }
            $this->disableFly($player, false);
        } else {
            $this->dataCfg->removeNested("active_fly.$name");
        }

        if (isset($this->speedActive[$name]) && $this->speedActive[$name]) {
            $timeLeft = $this->speedTimeLeft[$name] ?? 0;
            if ($timeLeft > 0) {
                $this->dataCfg->setNested("active_speed.$name", $timeLeft);
            } else {
                $this->dataCfg->removeNested("active_speed.$name");
            }
            $this->disableSpeed($player, false);
        } else {
            $this->dataCfg->removeNested("active_speed.$name");
        }

        if (isset($this->vanishActive[$name])) {
            $this->disableVanish($player, false);
        }

        $this->dataCfg->save();
    }

    public function onDamage(EntityDamageEvent $event): void {
        $entity = $event->getEntity();
        if (!($entity instanceof Player)) return;

        $name = strtolower($entity->getName());

        // Если игрок в ванише - отменить урон
        if (isset($this->vanishActive[$name]) && $this->vanishActive[$name]) {
            $event->cancel();
        }
    }

    // ========================
    // ТАЙМЕР
    // ========================

    private function onTick(): void {
        // Обработка таймеров полёта
        foreach ($this->flyActive as $name => $active) {
            if (!$active) continue;

            $timeLeft = $this->flyTimeLeft[$name] ?? 0;
            if ($timeLeft < 0) continue; // бесконечный

            $timeLeft--;
            $this->flyTimeLeft[$name] = $timeLeft;

            if ($timeLeft <= 0) {
                $player = $this->getServer()->getPlayerExact($name);
                if ($player !== null) {
                    $this->disableFly($player, true);
                    $player->sendMessage($this->getMessage("fly_expired"));
                }
                unset($this->flyActive[$name], $this->flyTimeLeft[$name]);
                $this->dataCfg->removeNested("active_fly.$name");
            } elseif ($timeLeft % 60 === 0 || $timeLeft === 30 || $timeLeft === 10 || $timeLeft <= 5) {
                $player = $this->getServer()->getPlayerExact($name);
                if ($player !== null) {
                    $player->sendActionBarMessage(
                        C::YELLOW . "✈ Полёт: " . C::WHITE . $this->formatTime($timeLeft)
                    );
                }
            }
        }

        // Обработка таймеров ускорения
        foreach ($this->speedActive as $name => $active) {
            if (!$active) continue;

            $timeLeft = $this->speedTimeLeft[$name] ?? 0;
            if ($timeLeft < 0) continue; // бесконечный

            $timeLeft--;
            $this->speedTimeLeft[$name] = $timeLeft;

            if ($timeLeft <= 0) {
                $player = $this->getServer()->getPlayerExact($name);
                if ($player !== null) {
                    $this->disableSpeed($player, true);
                    $player->sendMessage($this->getMessage("speed_expired"));
                }
                unset($this->speedActive[$name], $this->speedTimeLeft[$name]);
                $this->dataCfg->removeNested("active_speed.$name");
            } elseif ($timeLeft % 60 === 0 || $timeLeft === 30 || $timeLeft === 10 || $timeLeft <= 5) {
                $player = $this->getServer()->getPlayerExact($name);
                if ($player !== null) {
                    $player->sendActionBarMessage(
                        C::AQUA . "⚡ Скорость: " . C::WHITE . $this->formatTime($timeLeft)
                    );
                }
            }
        }
    }

    // ========================
    // FLY
    // ========================

    private function enableFly(Player $player, int $time): void {
        $name = strtolower($player->getName());
        $this->flyActive[$name] = true;
        $this->flyTimeLeft[$name] = $time;

        $player->setAllowFlight(true);
        $player->setFlying(true);

        $player->sendMessage($this->getMessage("fly_enabled", [
            "{time}" => $this->formatTime($time)
        ]));
    }

    private function disableFly(Player $player, bool $notify): void {
        $name = strtolower($player->getName());

        $player->setAllowFlight(false);
        $player->setFlying(false);

        // Безопасное приземление
        if ($player->isOnline() && $player->getGamemode() === GameMode::SURVIVAL) {
            $player->setAllowFlight(false);
        }

        unset($this->flyActive[$name], $this->flyTimeLeft[$name]);

        if ($notify) {
            $player->sendMessage($this->getMessage("fly_disabled"));
        }
    }

    // ========================
    // SPEED
    // ========================

    private function applySpeedEffect(Player $player): void {
        $group = $this->getPlayerGroup($player->getName());
        $groupCfg = $this->getGroupConfig($group);

        $multiplier = $groupCfg["speed_multiplier"] ?? 2.0;
        $amplifier = max(0, (int)(($multiplier - 1) * 2));

        $player->getEffects()->add(new EffectInstance(
            VanillaEffects::SPEED(),
            20 * 99999, // очень долго
            $amplifier,
            false // без частиц
        ));
    }

    private function removeSpeedEffect(Player $player): void {
        $player->getEffects()->remove(VanillaEffects::SPEED());
    }

    private function enableSpeed(Player $player, int $time): void {
        $name = strtolower($player->getName());
        $this->speedActive[$name] = true;
        $this->speedTimeLeft[$name] = $time;

        $this->applySpeedEffect($player);

        $player->sendMessage($this->getMessage("speed_enabled", [
            "{time}" => $this->formatTime($time)
        ]));
    }

    private function disableSpeed(Player $player, bool $notify): void {
        $name = strtolower($player->getName());

        $this->removeSpeedEffect($player);

        unset($this->speedActive[$name], $this->speedTimeLeft[$name]);

        if ($notify) {
            $player->sendMessage($this->getMessage("speed_disabled"));
        }
    }

    // ========================
    // VANISH
    // ========================

    private function enableVanish(Player $player): void {
        $name = strtolower($player->getName());
        $this->vanishActive[$name] = true;

        // Скрыть от всех игроков
        foreach ($this->getServer()->getOnlinePlayers() as $online) {
            if ($online->getName() === $player->getName()) continue;
            $online->hidePlayer($player);
        }

        $player->getEffects()->add(new EffectInstance(
            VanillaEffects::INVISIBILITY(),
            20 * 99999,
            0,
            false
        ));

        $player->sendMessage($this->getMessage("vanish_enabled"));
    }

    private function disableVanish(Player $player, bool $notify): void {
        $name = strtolower($player->getName());

        // Показать всем игрокам
        if ($player->isOnline()) {
            foreach ($this->getServer()->getOnlinePlayers() as $online) {
                if ($online->getName() === $player->getName()) continue;
                $online->showPlayer($player);
            }

            $player->getEffects()->remove(VanillaEffects::INVISIBILITY());
        }

        unset($this->vanishActive[$name]);

        if ($notify) {
            $player->sendMessage($this->getMessage("vanish_disabled"));
        }
    }

    // ========================
    // BONUS
    // ========================

    /**
     * Получить кулдаун бонуса (время последнего получения)
     */
    private function getLastBonusTime(string $name): int {
        return (int)$this->dataCfg->getNested("bonus_cooldown." . strtolower($name), 0);
    }

    /**
     * Установить время получения бонуса
     */
    private function setLastBonusTime(string $name): void {
        $this->dataCfg->setNested("bonus_cooldown." . strtolower($name), time());
        $this->dataCfg->save();
    }

    /**
     * Проверить, использовал ли игрок freeflex
     */
    private function hasUsedFreeFlex(string $name): bool {
        return (bool)$this->dataCfg->getNested("freeflex_used." . strtolower($name), false);
    }

    /**
     * Отметить использование freeflex
     */
    private function setFreeFlexUsed(string $name): void {
        $this->dataCfg->setNested("freeflex_used." . strtolower($name), true);
        $this->dataCfg->save();
    }

    /**
     * Выдать деньги игроку (через EconomyAPI или аналог)
     */
    private function giveMoney(Player $player, int $amount): bool {
        // Попытка через EconomyAPI
        $economy = $this->getServer()->getPluginManager()->getPlugin("EconomyAPI");
        if ($economy !== null && $economy->isEnabled()) {
            $economy->addMoney($player, $amount);
            return true;
        }

        // Попытка через BedrockEconomy
        $bedrock = $this->getServer()->getPluginManager()->getPlugin("BedrockEconomy");
        if ($bedrock !== null && $bedrock->isEnabled()) {
            // BedrockEconomy API
            \cooldogedev\BedrockEconomy\api\BedrockEconomyAPI::legacy()->addToPlayerBalance(
                $player->getName(),
                $amount,
                \Closure::fromCallable(function() {}),
                \Closure::fromCallable(function() {})
            );
            return true;
        }

        // Если нет экономики - вывести предупреждение
        $this->getLogger()->warning("Экономический плагин не найден! Бонус не может быть выдан.");
        $player->sendMessage(C::RED . "Ошибка: экономический плагин не найден!");
        return false;
    }

    // ========================
    // КОМАНДЫ
    // ========================

    public function onCommand(CommandSender $sender, Command $cmd, string $label, array $args): bool {
        if (!($sender instanceof Player)) {
            $sender->sendMessage(C::RED . "Эта команда доступна только игрокам!");
            return true;
        }

        $player = $sender;
        $name = strtolower($player->getName());
        $group = $this->getPlayerGroup($player->getName());
        $groupCfg = $this->getGroupConfig($group);

        switch ($cmd->getName()) {

            // ============ /rcfly ============
            case "rcfly":
                if ($groupCfg === null) {
                    $player->sendMessage($this->getMessage("no_privilege"));
                    return true;
                }

                $flyTime = $groupCfg["fly_time"] ?? 0;
                if ($flyTime === 0) {
                    $player->sendMessage($this->getMessage("fly_no_access"));
                    return true;
                }

                // Если полёт уже активен - выключить
                if (isset($this->flyActive[$name]) && $this->flyActive[$name]) {
                    $this->disableFly($player, true);
                    return true;
                }

                $this->enableFly($player, $flyTime);
                return true;

            // ============ /rcspeed ============
            case "rcspeed":
                if ($groupCfg === null) {
                    $player->sendMessage($this->getMessage("no_privilege"));
                    return true;
                }

                $speedTime = $groupCfg["speed_time"] ?? 0;
                if ($speedTime === 0) {
                    $player->sendMessage($this->getMessage("speed_no_access"));
                    return true;
                }

                // Если ускорение уже активно - выключить
                if (isset($this->speedActive[$name]) && $this->speedActive[$name]) {
                    $this->disableSpeed($player, true);
                    return true;
                }

                $this->enableSpeed($player, $speedTime);
                return true;

            // ============ /rcvanish ============
            case "rcvanish":
                if ($groupCfg === null) {
                    $player->sendMessage($this->getMessage("no_privilege"));
                    return true;
                }

                $vanishAccess = $groupCfg["vanish"] ?? false;
                if (!$vanishAccess) {
                    $player->sendMessage($this->getMessage("vanish_no_access"));
                    return true;
                }

                // Если ваниш уже активен - выключить
                if (isset($this->vanishActive[$name]) && $this->vanishActive[$name]) {
                    $this->disableVanish($player, true);
                    return true;
                }

                $this->enableVanish($player);
                return true;

            // ============ /rcbonus ============
            case "rcbonus":
                if ($groupCfg === null) {
                    $player->sendMessage($this->getMessage("no_privilege"));
                    return true;
                }

                $bonusAmount = $groupCfg["bonus"] ?? 0;
                if ($bonusAmount <= 0) {
                    $player->sendMessage($this->getMessage("bonus_no_access"));
                    return true;
                }

                // Проверка кулдауна (24 часа)
                $lastBonus = $this->getLastBonusTime($name);
                $cooldown = 86400; // 24 часа
                $timePassed = time() - $lastBonus;

                if ($timePassed < $cooldown) {
                    $remaining = $cooldown - $timePassed;
                    $player->sendMessage($this->getMessage("bonus_cooldown", [
                        "{time}" => $this->formatTime($remaining)
                    ]));
                    return true;
                }

                // Выдать бонус
                if ($this->giveMoney($player, $bonusAmount)) {
                    $this->setLastBonusTime($name);
                    $player->sendMessage($this->getMessage("bonus_received", [
                        "{amount}" => number_format($bonusAmount, 0, '.', '.')
                    ]));
                }
                return true;

            // ============ /rcfreeflex ============
            case "rcfreeflex":
                // Проверить, имеет ли игрок доступ
                $freeFlexGroups = $this->cfg->get("freeflex_groups", ["SPARK", "YARIK", "ADMIN"]);
                if (!in_array($group, $freeFlexGroups)) {
                    $player->sendMessage($this->getMessage("freeflex_no_access"));
                    return true;
                }

                // Проверить, не использовал ли уже
                if ($this->hasUsedFreeFlex($name)) {
                    $player->sendMessage($this->getMessage("freeflex_used"));
                    return true;
                }

                // Проверить аргумент (ник целевого игрока)
                if (!isset($args[0])) {
                    $player->sendMessage($this->getMessage("freeflex_usage"));
                    return true;
                }

                $targetName = $args[0];
                $targetPlayer = $this->getServer()->getPlayerByPrefix($targetName);

                // Получить RcGroup для установки привилегии
                $rcGroup = $this->getRcGroup();
                if ($rcGroup === null) {
                    $player->sendMessage(C::RED . "Ошибка: плагин RcGroup не найден!");
                    return true;
                }

                // Проверить, существует ли группа FLEX
                if ($rcGroup->groupsCfg->getNested("groups.FLEX") === null) {
                    $player->sendMessage(C::RED . "Ошибка: группа FLEX не найдена в RcGroup!");
                    return true;
                }

                // Выдать FLEX целевому игроку
                $rcGroup->setGroup($targetName, "FLEX");
                $this->setFreeFlexUsed($name);

                $player->sendMessage($this->getMessage("freeflex_success", [
                    "{player}" => $targetName
                ]));

                // Уведомить целевого игрока если он онлайн
                if ($targetPlayer !== null) {
                    $targetPlayer->sendMessage($this->getMessage("freeflex_received", [
                        "{player}" => $player->getName()
                    ]));
                }
                return true;
        }

        return true;
    }

    // ========================
    // PUBLIC API
    // ========================

    /**
     * Проверить, активен ли ваниш у игрока
     */
    public function isVanished(string $name): bool {
        return $this->vanishActive[strtolower($name)] ?? false;
    }

    /**
     * Проверить, активен ли флай у игрока
     */
    public function isFlying(string $name): bool {
        return $this->flyActive[strtolower($name)] ?? false;
    }

    /**
     * Проверить, активен ли спид у игрока
     */
    public function isSpeeding(string $name): bool {
        return $this->speedActive[strtolower($name)] ?? false;
    }
}
