<?php

namespace InzeOwr\RcDoxc;

use pocketmine\utils\Config;
use pocketmine\player\Player;

class DataManager {

    private Main $plugin;
    private array $medCertCache = []; // Справки можно не сохранять в файл, они временные

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
        $dataFolder = $this->plugin->getDataFolder();
        if(!is_dir($dataFolder)) @mkdir($dataFolder, 0777, true);
        if(!is_dir($dataFolder . "players/")) @mkdir($dataFolder . "players/", 0777, true);
    }

    public function getPlayerConfig(string $name): Config {
        return new Config($this->plugin->getDataFolder() . "players/" . strtolower($name) . ".json", Config::JSON);
    }

    public function saveData(string $name, string $key, array $data): void {
        $cfg = $this->getPlayerConfig($name);
        $cfg->set($key, $data);
        $cfg->save();
    }

    public function getData(string $name, string $key): ?array {
        $val = $this->getPlayerConfig($name)->get($key);
        return is_array($val) ? $val : null;
    }

    public function removeData(string $name, string $key): void {
        $cfg = $this->getPlayerConfig($name);
        $cfg->remove($key);
        $cfg->save();
    }

    // --- Кэш справок (Временный) ---
    public function setMedCert(string $name, array $data): void {
        $this->medCertCache[strtolower($name)] = $data;
    }

    public function getMedCert(string $name): ?array {
        return $this->medCertCache[strtolower($name)] ?? null;
    }

    public function removeMedCert(string $name): void {
        unset($this->medCertCache[strtolower($name)]);
    }

    // --- Тесты (Сохраняем в файл, чтобы не проходить заново) ---
    
    public function setTestPassed(string $name, string $test, string $scoreStr): void {
        // Сохраняем результат в конфиг игрока под ключом 'tests'
        $cfg = $this->getPlayerConfig($name);
        $tests = $cfg->get("tests", []);
        $tests[$test] = $scoreStr;
        $cfg->set("tests", $tests);
        $cfg->save();
    }

    public function hasPassed(string $name, string $test): bool {
        $cfg = $this->getPlayerConfig($name);
        $tests = $cfg->get("tests", []);
        return isset($tests[$test]);
    }

    public function getTestScore(string $name, string $test): string {
        $cfg = $this->getPlayerConfig($name);
        $tests = $cfg->get("tests", []);
        return $tests[$test] ?? "Нет данных";
    }
}