<?php

namespace InzeOwr\RcDoxc;

use jojoe77777\FormAPI\CustomForm;
use jojoe77777\FormAPI\SimpleForm;
use jojoe77777\FormAPI\ModalForm;
use pocketmine\player\Player;
use pocketmine\utils\TextFormat as C;

class Forms {

    // --- АДМИН: РЕДАКТИРОВАНИЕ ДАННЫХ ---
    public static function openEditForm(Player $admin, Main $plugin, string $targetName): void {
        $dm = $plugin->getDataManager();
        $pass = $dm->getData($targetName, 'passport');

        // Определяем индекс для выпадающего списка (чтобы показать текущий пол)
        $genderIdx = ($pass['gender'] === 'Женский') ? 1 : 0;

        $form = new CustomForm(function(Player $admin, ?array $data) use ($plugin, $targetName, $dm, $pass) {
            if ($data === null) return;

            $newFio = $data[0];
            $newDob = $data[1];
            $newPob = $data[2];
            $newGender = ["Мужской", "Женский"][$data[3]];

            // 1. Обновляем Паспорт
            $pass['fio'] = $newFio;
            $pass['dob'] = $newDob;
            $pass['pob'] = $newPob;
            $pass['gender'] = $newGender;
            $dm->saveData($targetName, 'passport', $pass);

            // 2. Обновляем Медкарту (если есть)
            $med = $dm->getData($targetName, 'medcard');
            if($med) {
                $med['fio'] = $newFio;
                $med['dob'] = $newDob;
                $med['gender'] = $newGender;
                $dm->saveData($targetName, 'medcard', $med);
            }

            // 3. Обновляем Лицензию на оружие (если есть)
            $licW = $dm->getData($targetName, 'lic_weapon');
            if($licW) {
                $licW['fio'] = $newFio;
                $licW['dob'] = $newDob;
                $licW['gender'] = $newGender;
                $dm->saveData($targetName, 'lic_weapon', $licW);
            }

            // 4. Обновляем Водительское удостоверение (если есть)
            $licA = $dm->getData($targetName, 'lic_auto');
            if($licA) {
                $licA['fio'] = $newFio;
                $licA['dob'] = $newDob;
                $licA['gender'] = $newGender;
                $dm->saveData($targetName, 'lic_auto', $licA);
            }

            $admin->sendMessage("§a[RcDoxc] Данные игрока $targetName успешно изменены во всех документах!");
        });

        $form->setTitle("§lРедактирование: $targetName");
        $form->addLabel("§7Измените данные. Они обновятся во всех документах игрока.");
        $form->addInput("§eФИО", "", $pass['fio']);
        $form->addInput("§eДата рождения", "", $pass['dob']);
        $form->addInput("§eМесто рождения", "", $pass['pob']);
        $form->addDropdown("§eПол", ["Мужской", "Женский"], $genderIdx);
        $admin->sendForm($form);
    }

    // --- ПОЛУЧЕНИЕ ПАСПОРТА ---
    public static function openPassportForm(Player $player, Main $plugin): void {
        if($plugin->getDataManager()->getData($player->getName(), 'passport')) {
             $player->sendMessage("§cУ вас уже есть паспорт! Используйте его из инвентаря.");
             return;
        }

        $form = new CustomForm(function(Player $player, ?array $data) use ($plugin) {
            if ($data === null) return;
            
            if(empty($data[1]) || empty($data[2]) || empty($data[3])) {
                $player->sendMessage("§cОшибка: Вы должны заполнить все поля!");
                return;
            }

            $eco = $plugin->getEconomy();
            if($eco->myMoney($player) < 1000) {
                $player->sendMessage("§cНедостаточно средств. Стоимость паспорта: 1000$.");
                return;
            }
            $eco->reduceMoney($player, 1000);
            
            $passportData = [
                'fio' => $data[1],
                'dob' => $data[2],
                'pob' => $data[3],
                'gender' => ["Мужской", "Женский"][$data[4]],
                'series' => mt_rand(1000, 9999) . " " . mt_rand(100000, 999999)
            ];

            $plugin->getDataManager()->saveData($player->getName(), 'passport', $passportData);
            $plugin->givePassport($player, $passportData);
            
            // Обновляем тег (если стоит RcGroup)
            if(method_exists($plugin, 'updateTag')) {
                $plugin->updateTag($player);
            }

            $player->sendMessage("§aПоздравляем! Вы успешно получили паспорт гражданина.");
        });

        $form->setTitle("§l§eПаспортный стол");
        $form->addLabel("§7Стоимость оформления: §61000$");
        $form->addInput("§l§eФИО (Фамилия Имя Отчество)", "Иванов Иван Иванович");
        $form->addInput("§l§eДата рождения", "01.01.2000");
        $form->addInput("§l§eМесто рождения", "г. Берегкс");
        $form->addDropdown("§l§eПол", ["Мужской", "Женский"]);
        $player->sendForm($form);
    }

    // --- ТЕРАПЕВТ (ОСМОТР) ---
    public static function openMedCertForm(Player $player, Main $plugin): void {
        $dm = $plugin->getDataManager();
        
        // Проверка: Если есть действующая медкарта, запрещаем проходить осмотр
        $existingMed = $dm->getData($player->getName(), 'medcard');
        if ($existingMed && time() < $existingMed['expiry']) {
            $player->sendMessage("§cУ вас уже есть действующая медицинская карта. Пройти осмотр заново можно только после истечения её срока.");
            return;
        }

        $form = new CustomForm(function(Player $player, ?array $data) use ($plugin) {
            if ($data === null) return;
            
            if(empty($data[1]) || empty($data[2]) || empty($data[5])) {
                $player->sendMessage("§cЗаполните все обязательные поля!");
                return;
            }

            $certData = [
                'height' => $data[1],
                'weight' => $data[2],
                'blood' => ["I", "II", "III", "IV"][$data[3]],
                'rh' => ["+", "-"][$data[4]],
                'allergies' => $data[5]
            ];

            $plugin->getDataManager()->setMedCert($player->getName(), $certData);
            $player->sendMessage("§aОсмотр пройден! Ваши данные переданы в регистратуру.");
            $player->sendMessage("§eТеперь обратитесь за получением медкарты (/rcmed).");
        });

        $form->setTitle("§l§cКабинет Терапевта");
        $form->addLabel("§7Заполните медицинские данные для справки");
        $form->addInput("§l§eРост (см)", "180");
        $form->addInput("§l§eВес (кг)", "75");
        $form->addDropdown("§l§eГруппа крови", ["I", "II", "III", "IV"]);
        $form->addDropdown("§l§eРезус-фактор", ["+", "-"]);
        $form->addInput("§l§eАллергии (или 'Нет')", "Нет");
        $player->sendForm($form);
    }

    // --- РЕГИСТРАТУРА (ВЫДАЧА МЕДКАРТЫ) ---
    public static function openMedCardForm(Player $player, Main $plugin): void {
        $dm = $plugin->getDataManager();
        $cert = $dm->getMedCert($player->getName());
        $pass = $dm->getData($player->getName(), 'passport');

        if(!$pass) {
            $player->sendMessage("§cОшибка: У вас нет паспорта! Сначала получите паспорт.");
            return;
        }
        if(!$cert) {
            $player->sendMessage("§cОшибка: Нет данных осмотра! Пройдите терапевта (/rcmade1).");
            return;
        }
        // Вторичная проверка на всякий случай
        if($dm->getData($player->getName(), 'medcard')) {
             $player->sendMessage("§cУ вас уже есть действующая медкарта!");
             return;
        }

        $form = new ModalForm(function(Player $player, ?bool $data) use ($plugin, $cert, $pass, $dm) {
            if(!$data) return;

            $eco = $plugin->getEconomy();
            if($eco->myMoney($player) < 2500) {
                $player->sendMessage("§cНедостаточно средств (2500$).");
                return;
            }
            $eco->reduceMoney($player, 2500);

            $expiry = time() + (30 * 24 * 3600); // 30 дней
            
            $info = [
                "Рост: " . $cert['height'] . "см",
                "Вес: " . $cert['weight'] . "кг",
                "Кровь: " . $cert['blood'] . "(" . $cert['rh'] . ")",
                "Аллергии: " . $cert['allergies']
            ];

            $medData = [
                'fio' => $pass['fio'],
                'dob' => $pass['dob'],
                'gender' => $pass['gender'],
                'info' => $info,
                'policy' => mt_rand(1000, 9999) . " " . mt_rand(100000, 999999),
                'expiry' => $expiry
            ];

            $dm->saveData($player->getName(), 'medcard', $medData);
            $dm->removeMedCert($player->getName());
            $plugin->giveMedCard($player, $medData);
            $player->sendMessage("§aМедицинская карта успешно выдана!");
        });

        $form->setTitle("§l§cРегистратура");
        $form->setContent("§7Стоимость выдачи карты: §62500$\n§fДанные справки получены. Вы готовы оформить карту?");
        $form->setButton1("§l§aОформить");
        $form->setButton2("§l§cУйти");
        $player->sendForm($form);
    }

    // --- ТЕСТЫ (НАРКОЛОГ, ПСИХИАТР, АВТОШКОЛА) ---
    public static function openTestForm(Player $player, Main $plugin, string $type): void {
        $dm = $plugin->getDataManager();
        $blockTest = false;
        $blockReason = "";

        // Логика блокировки теста, если лицензия действительна
        if($type === 'auto') {
            $lic = $dm->getData($player->getName(), 'lic_auto');
            if($lic && time() < $lic['expiry']) {
                $blockTest = true;
                $blockReason = "У вас уже есть действующее водительское удостоверение.";
            }
        } elseif ($type === 'narc' || $type === 'psy') {
            // Нарколога и Психиатра проходим для оружия.
            // Если есть лицензия на оружие, тесты не нужны.
            $lic = $dm->getData($player->getName(), 'lic_weapon');
            if($lic && time() < $lic['expiry']) {
                $blockTest = true;
                $blockReason = "У вас уже есть действующая лицензия на оружие.";
            }
        }

        if($blockTest) {
            $player->sendMessage("§c$blockReason Пересдача теста запрещена до истечения срока действия документа.");
            return;
        }

        // Данные тестов
        $tests = [
            'narc' => [
                'title' => 'Нарколог',
                'qs' => [
                    ["Вы употребляете наркотические вещества?", ["Да", "Нет", "Иногда"], 1],
                    ["Как часто вы употребляете алкоголь?", ["Каждый день", "По праздникам", "Не пью"], 2],
                    ["Есть ли у вас зависимость?", ["Да", "Нет", "Не знаю"], 1],
                    ["Чувствуете ли вы ломку?", ["Да", "Нет", "Иногда"], 1],
                    ["Видите ли вы галлюцинации?", ["Да", "Нет", "Редко"], 1],
                    ["Согласны ли вы на принудительное лечение?", ["Не требуется", "Да", "Нет"], 0],
                    ["Меняется ли цвет вашей кожи?", ["Да", "Нет", "Иногда"], 1],
                    ["Дрожат ли у вас руки?", ["Да", "Нет", "С похмелья"], 1],
                    ["Нормальный ли у вас сон?", ["Нет", "Да", "С таблетками"], 1],
                    ["Считаете ли вы себя здоровым?", ["Да", "Нет", "Не знаю"], 0]
                ]
            ],
            'psy' => [
                'title' => 'Психиатр',
                'qs' => [
                    ["Слышите ли вы голоса в голове?", ["Да", "Нет", "Иногда"], 1],
                    ["Есть ли желание навредить людям?", ["Да", "Нет", "Зависит от них"], 1],
                    ["Считаете ли вы себя адекватным?", ["Я Наполеон", "Да", "Нет"], 1],
                    ["Контролируете ли вы вспышки гнева?", ["Да", "Нет", "С трудом"], 0],
                    ["Любите ли вы смотреть на огонь?", ["Да, сжигать всё", "Нет", "У костра"], 2],
                    ["Как часто меняется настроение?", ["Скачет", "Стабильное", "Депрессия"], 1],
                    ["Кажется ли вам, что вас преследуют?", ["Да, ФСБ", "Нет", "Инопланетяне"], 1],
                    ["Посещают ли вас мысли о суициде?", ["Часто", "Нет", "Бывает"], 1],
                    ["Понимаете ли вы, где находитесь?", ["В матрице", "В больнице", "В космосе"], 1],
                    ["Готовы ли вы владеть оружием?", ["Да", "Нет", "Боюсь его"], 0]
                ]
            ],
            'auto' => [
                'title' => 'Автошкола',
                'qs' => [
                    ["Красный сигнал светофора означает:", ["Ехать", "Стоять", "Газовать"], 1],
                    ["Знак 'Въезд запрещен' (Кирпич):", ["Въезд запрещен", "Проезд разрешен", "Парковка"], 0],
                    ["Максимальная скорость в городе:", ["60 км/ч", "90 км/ч", "120 км/ч"], 0],
                    ["При приближении к пешеходному переходу:", ["Давить", "Уступить дорогу", "Сигналить"], 1],
                    ["Двойная сплошная линия разметки:", ["Можно пересекать", "Пересекать запрещено", "Иногда"], 1],
                    ["При помехе справа вы должны:", ["Уступить", "Проехать", "Бибикнуть"], 0],
                    ["Знак 'Главная дорога' означает:", ["Уступаю всем", "Имею преимущество", "Стою"], 1],
                    ["Когда нужно включать поворотник?", ["Зачем?", "Заблаговременно до маневра", "После маневра"], 1],
                    ["Ремень безопасности:", ["Жмет", "Обязателен для всех", "Не нужен"], 1],
                    ["Обгон на регулируемом перекрестке:", ["Разрешен", "Запрещен", "По обочине"], 1],
                    ["Допустимо ли вождение в нетрезвом виде?", ["Можно чуть-чуть", "Категорически запрещено", "Если праздник"], 1],
                    ["Движение задним ходом запрещено:", ["На автомагистралях", "Где разрешено", "Везде"], 0],
                    ["Звуковой сигнал в городе применяется:", ["Для приветствия", "Для предотвращения ДТП", "Для музыки"], 1],
                    ["Аптечка в автомобиле:", ["Обязательна", "Нет", "Только бинт"], 0],
                    ["При ДТП водитель обязан:", ["Уехать", "Остановиться и выставить знак", "Драться"], 1]
                ]
            ]
        ];

        $currentTest = $tests[$type];
        
        $form = new CustomForm(function(Player $player, ?array $data) use ($plugin, $type, $currentTest) {
            if($data === null) return;
            
            $score = 0;
            $total = count($currentTest['qs']);
            
            foreach($currentTest['qs'] as $index => $qData) {
                // $qData[2] - индекс правильного ответа
                if(isset($data[$index]) && $data[$index] === $qData[2]) {
                    $score++;
                }
            }

            // Требуется 80% правильных ответов
            if($score >= ($total * 0.8)) {
                // Сохраняем результат
                $scoreStr = "Сдано: $score из $total";
                $plugin->getDataManager()->setTestPassed($player->getName(), $type, $scoreStr);
                $player->sendMessage("§aПоздравляем! Вы успешно сдали тест ($score из $total).");
            } else {
                $player->sendMessage("§cВы провалили тест ($score из $total). Попробуйте снова.");
            }
        });

        $form->setTitle("§l§9Тест: " . $currentTest['title']);
        foreach($currentTest['qs'] as $q) {
            $form->addDropdown("§e" . $q[0], $q[1]);
        }
        $player->sendForm($form);
    }

    // --- МАГАЗИН ЛИЦЕНЗИЙ ---
    public static function openLicenseShop(Player $player, Main $plugin): void {
        $form = new SimpleForm(function(Player $player, ?int $data) use ($plugin) {
            if($data === null) return;

            $dm = $plugin->getDataManager();
            $eco = $plugin->getEconomy();
            $pass = $dm->getData($player->getName(), 'passport');
            $med = $dm->getData($player->getName(), 'medcard');

            if(!$pass) {
                $player->sendMessage("§cОшибка: Нет паспорта!");
                return;
            }
            if(!$med) {
                $player->sendMessage("§cОшибка: Нет медкарты!");
                return;
            }
            if(time() > $med['expiry']) {
                 $player->sendMessage("§cОшибка: Ваша медкарта просрочена! Обновите её.");
                 return;
            }

            $expiry = time() + (60 * 24 * 3600); // 60 дней

            if($data === 0) { // Оружие
                if(!$dm->hasPassed($player->getName(), 'narc')) {
                    $player->sendMessage("§cВы не прошли проверку у нарколога!"); return;
                }
                if(!$dm->hasPassed($player->getName(), 'psy')) {
                    $player->sendMessage("§cВы не прошли проверку у психиатра!"); return;
                }
                
                if($eco->myMoney($player) < 30000) {
                    $player->sendMessage("§cНе хватает денег (30000$)");
                    return;
                }
                
                // Если уже есть действующая лицензия
                $oldLic = $dm->getData($player->getName(), 'lic_weapon');
                if($oldLic && time() < $oldLic['expiry']) {
                    $player->sendMessage("§cУ вас уже есть действующая лицензия!"); return;
                }

                $infoList = [
                    "Психиатр: " . $dm->getTestScore($player->getName(), 'psy'),
                    "Нарколог: " . $dm->getTestScore($player->getName(), 'narc'),
                    "Допуск: Разрешен"
                ];

                $licData = [
                    'fio' => $pass['fio'],
                    'dob' => $pass['dob'],
                    'gender' => $pass['gender'],
                    'info' => $infoList,
                    'series' => mt_rand(100000, 999999),
                    'expiry' => $expiry
                ];

                $eco->reduceMoney($player, 30000);
                $dm->saveData($player->getName(), 'lic_weapon', $licData);
                $plugin->giveLicense($player, 'weapon', $licData);
                $player->sendMessage("§aЛицензия на оружие успешно приобретена!");

            } elseif ($data === 1) { // Авто
                if(!$dm->hasPassed($player->getName(), 'auto')) {
                    $player->sendMessage("§cВы не сдали экзамен ПДД!"); return;
                }

                if($eco->myMoney($player) < 15000) {
                    $player->sendMessage("§cНе хватает денег (15000$)");
                    return;
                }

                // Если уже есть права
                $oldLic = $dm->getData($player->getName(), 'lic_auto');
                if($oldLic && time() < $oldLic['expiry']) {
                    $player->sendMessage("§cУ вас уже есть водительское удостоверение!"); return;
                }

                $infoList = [
                    "Теория: " . $dm->getTestScore($player->getName(), 'auto'),
                    "Категория: B",
                    "Стаж: 0 лет"
                ];

                $licData = [
                    'fio' => $pass['fio'],
                    'dob' => $pass['dob'],
                    'gender' => $pass['gender'],
                    'info' => $infoList,
                    'series' => mt_rand(100000, 999999),
                    'expiry' => $expiry
                ];

                $eco->reduceMoney($player, 15000);
                $dm->saveData($player->getName(), 'lic_auto', $licData);
                $plugin->giveLicense($player, 'auto', $licData);
                $player->sendMessage("§aВодительское удостоверение получено!");
            }
        });

        $form->setTitle("§l§bЛицензионный центр");
        $form->setContent("§7Выберите категорию для получения лицензии:");
        $form->addButton("§l§cОружие\n§r§730,000$ | Треб: Медкарта, Тесты");
        $form->addButton("§l§eВождение\n§r§715,000$ | Треб: Медкарта, Экзамен");
        $player->sendForm($form);
    }

    // --- ПРОСМОТР ДОКУМЕНТОВ ---
    public static function openInfoForm(Player $player, string $text): void {
        $form = new SimpleForm(function(Player $p, $d){});
        $form->setTitle("§l§8Просмотр документа");
        $form->setContent($text);
        $form->addButton("§lЗакрыть");
        $player->sendForm($form);
    }
}