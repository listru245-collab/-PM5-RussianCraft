<?php

namespace InzeOwr\RcDoxc;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\entity\EntityDataHelper;
use pocketmine\entity\EntityFactory;
use pocketmine\entity\Human;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\item\Item;
use pocketmine\item\VanillaItems;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerItemUseEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\inventory\InventoryTransactionEvent;
use pocketmine\event\player\PlayerDropItemEvent;
use pocketmine\event\server\DataPacketReceiveEvent;
use pocketmine\network\mcpe\protocol\InventoryTransactionPacket;
use pocketmine\network\mcpe\protocol\types\inventory\UseItemOnEntityTransactionData;
use pocketmine\world\World;
use pocketmine\utils\Config;
use pocketmine\utils\TextFormat;
use onebone\economyapi\EconomyAPI;

use InzeOwr\RcOrg\Main as RcOrgMain;

class Main extends PluginBase implements Listener {

    private DataManager $dataManager;
    private $economy;

    /** @var array<string, bool> Игроки в режиме удаления NPC: ник => true */
    private array $deleteNpcMode = [];

    /** @var array<string, string> Тип NPC для удаления: ник => тип */
    private array $deleteNpcType = [];

    public function onEnable(): void {
        $this->saveDefaultConfig();
        $this->dataManager = new DataManager($this);
        $this->economy = EconomyAPI::getInstance();
        
        EntityFactory::getInstance()->register(NpcEntity::class, function(World $world, CompoundTag $nbt): NpcEntity {
            $skin = Human::parseSkinNbt($nbt);
            return new NpcEntity(EntityDataHelper::parseLocation($nbt, $world), $skin, $nbt);
        }, ['RcDoxcNpcEntity']);

        $this->getServer()->getPluginManager()->registerEvents($this, $this);
    }

    public function getDataManager(): DataManager {
        return $this->dataManager;
    }

    public function getEconomy() {
        return $this->economy;
    }

    public function updateTag(Player $player): void {
        $rcGroup = $this->getServer()->getPluginManager()->getPlugin("RcGroup");
        if ($rcGroup !== null && $rcGroup->isEnabled()) {
            $hasPassport = $this->dataManager->getData($player->getName(), 'passport');
            $tag = $hasPassport ? "§l(Гражданин)" : "§l(Эмигрант)";
            if(method_exists($rcGroup, "setOrgTag")){
                $rcGroup->setOrgTag($player->getName(), $tag);
            }
        }
    }

    public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool {
        
        if($command->getName() === "rcdoxcs") {
            if(!$sender instanceof Player) return false;
            if(!$sender->hasPermission("rcdoxc.admin")) {
                $sender->sendMessage("§cУ вас нет прав.");
                return true;
            }
            if(!isset($args[0])) {
                $sender->sendMessage("§cИспользование: /rcdoxcs <Ник>");
                return true;
            }
            $targetName = $args[0];
            
            if(!$this->dataManager->getData($targetName, 'passport')) {
                $sender->sendMessage("§cУ этого игрока нет паспорта.");
                return true;
            }

            Forms::openEditForm($sender, $this, $targetName);
            return true;
        }

        if($command->getName() === "rcdeldoxc") {
            if(!$sender instanceof Player) return false;
            if(!$sender->hasPermission("rcdoxc.admin")) {
                $sender->sendMessage("§cУ вас нет прав.");
                return true;
            }
            if(!isset($args[0])) {
                $sender->sendMessage("§cИспользование: /rcdeldoxc <тип>");
                $sender->sendMessage("§eДоступные типы:");
                $sender->sendMessage("§6  pass §7- Паспортный Стол");
                $sender->sendMessage("§6  med §7- Регистратура (медкарты)");
                $sender->sendMessage("§6  med1 §7- Терапевт (справки)");
                $sender->sendMessage("§6  lic §7- Лицензер");
                $sender->sendMessage("§6  narc §7- Нарколог");
                $sender->sendMessage("§6  psy §7- Психиатр");
                $sender->sendMessage("§6  auto §7- Инструктор");
                $sender->sendMessage("§6  all §7- Любой NPC документов");
                return true;
            }

            $type = strtolower($args[0]);
            $validTypes = ["pass", "med", "med1", "lic", "narc", "psy", "auto", "all"];

            if(!in_array($type, $validTypes)) {
                $sender->sendMessage("§cНеизвестный тип NPC: §e{$type}");
                $sender->sendMessage("§eДоступные типы: §6" . implode(", ", $validTypes));
                return true;
            }

            $this->deleteNpcMode[$sender->getName()] = true;
            $this->deleteNpcType[$sender->getName()] = $type;
            $sender->sendMessage("§aРежим удаления NPC активирован! Нажмите на NPC, чтобы удалить его.");
            $sender->sendMessage("§eТип для удаления: §6{$type}");
            $sender->sendMessage("§7Напишите §c/rcdeldoxc cancel §7чтобы отменить.");

            return true;
        }

        if($command->getName() === "rcdeldoxccancel") {
            if(!$sender instanceof Player) return false;
            if(isset($this->deleteNpcMode[$sender->getName()])) {
                unset($this->deleteNpcMode[$sender->getName()]);
                unset($this->deleteNpcType[$sender->getName()]);
                $sender->sendMessage("§cРежим удаления NPC отменён.");
            } else {
                $sender->sendMessage("§cВы не находитесь в режиме удаления NPC.");
            }
            return true;
        }

        if (!$sender instanceof Player) return false;
        
        $type = match($command->getName()) {
            "rcpass" => ["rc_passport_npc", "§l§eПаспортный Стол\n§r§7Нажмите"],
            "rcmade1" => ["rc_medcert_npc", "§l§cТерапевт\n§r§7Справки"],
            "rcmed" => ["rc_medcard_npc", "§l§cРегистратура\n§r§7Выдача медкарт"],
            "rclic" => ["rc_shop_npc", "§l§bЛицензер\n§r§7Покупка"],
            "rclic1" => ["rc_narc_npc", "§l§aНарколог\n§r§7Тестирование"],
            "rclic2" => ["rc_psy_npc", "§l§5Психиатр\n§r§7Тестирование"],
            "rclic3" => ["rc_auto_npc", "§l§6Инструктор\n§r§7Экзамен"],
            default => null
        };

        if ($type) {
            $this->spawnNpc($sender, $type[0], $type[1]);
            $sender->sendMessage("§aNPC успешно установлен!");
            return true;
        }
        return false;
    }

    private function spawnNpc(Player $p, string $tagKey, string $nameTag): void {
        $location = $p->getLocation();
        $nbt = CompoundTag::create()->setString("RcDoxcNpcType", $tagKey);
        
        $entity = new NpcEntity($location, $p->getSkin(), $nbt);
        $entity->setNameTag($nameTag);
        $entity->spawnToAll();
    }

    /**
     * Получить тип NPC по его nameTag для сопоставления с типом удаления
     */
    private function getNpcTypeByName(string $npcName): ?string {
        $cleanName = TextFormat::clean($npcName);

        if(str_contains($cleanName, "Паспортный Стол")) {
            return "pass";
        } elseif(str_contains($cleanName, "Терапевт")) {
            return "med1";
        } elseif(str_contains($cleanName, "Регистратура")) {
            return "med";
        } elseif(str_contains($cleanName, "Нарколог")) {
            return "narc";
        } elseif(str_contains($cleanName, "Психиатр")) {
            return "psy";
        } elseif(str_contains($cleanName, "Инструктор")) {
            return "auto";
        } elseif(str_contains($cleanName, "Лицензер")) {
            return "lic";
        }
        return null;
    }

    /**
     * Проверить, совпадает ли тип NPC с запрашиваемым типом удаления
     */
    private function doesNpcMatchDeleteType(string $npcType, string $deleteType): bool {
        if($deleteType === "all") {
            return true;
        }
        return $npcType === $deleteType;
    }

    public function onDataPacketReceive(DataPacketReceiveEvent $event): void {
        $packet = $event->getPacket();
        $player = $event->getOrigin()->getPlayer();
        if ($player === null) return;

        if ($packet instanceof InventoryTransactionPacket) {
            $trData = $packet->trData;
            if ($trData instanceof UseItemOnEntityTransactionData) {
                if ($trData->getActionType() === UseItemOnEntityTransactionData::ACTION_INTERACT) {
                    $entityId = $trData->getActorRuntimeId();
                    $entity = $player->getWorld()->getEntity($entityId);
                    if ($entity instanceof NpcEntity) {
                        // Проверяем режим удаления NPC
                        if(isset($this->deleteNpcMode[$player->getName()])) {
                            $this->handleNpcDelete($player, $entity);
                            return;
                        }
                        $this->handleNpcAction($player, $entity->getNameTag());
                    }
                }
            }
        }
    }

    /** @handleCancelled true */
    public function onNpcLeftClick(EntityDamageByEntityEvent $event): void {
        $entity = $event->getEntity();
        $player = $event->getDamager();
        if(!$player instanceof Player) return;

        if($entity instanceof NpcEntity) {
            // Проверяем режим удаления NPC
            if(isset($this->deleteNpcMode[$player->getName()])) {
                $event->cancel();
                $this->handleNpcDelete($player, $entity);
                return;
            }

            $item = $player->getInventory()->getItemInHand();
            if(!Utils::isRcItem($item)) {
                $this->handleNpcAction($player, $entity->getNameTag());
            }
        }
    }

    /**
     * Обработка удаления NPC
     */
    private function handleNpcDelete(Player $player, NpcEntity $entity): void {
        $playerName = $player->getName();
        $deleteType = $this->deleteNpcType[$playerName] ?? "all";

        $npcType = $this->getNpcTypeByName($entity->getNameTag());

        if($npcType === null) {
            $player->sendMessage("§cЭтот NPC не относится к системе документов.");
            return;
        }

        if(!$this->doesNpcMatchDeleteType($npcType, $deleteType)) {
            $typeNames = [
                "pass" => "Паспортный Стол",
                "med" => "Регистратура",
                "med1" => "Терапевт",
                "lic" => "Лицензер",
                "narc" => "Нарколог",
                "psy" => "Психиатр",
                "auto" => "Инструктор",
            ];
            $expectedName = $typeNames[$deleteType] ?? $deleteType;
            $player->sendMessage("§cЭтот NPC не соответствует типу §e{$expectedName}§c. Нажмите на правильного NPC.");
            return;
        }

        $entity->flagForDespawn();
        $entity->close();

        $typeNames = [
            "pass" => "Паспортный Стол",
            "med" => "Регистратура",
            "med1" => "Терапевт",
            "lic" => "Лицензер",
            "narc" => "Нарколог",
            "psy" => "Психиатр",
            "auto" => "Инструктор",
        ];
        $deletedTypeName = $typeNames[$npcType] ?? $npcType;
        $player->sendMessage("§aNPC §e{$deletedTypeName} §aуспешно удалён!");

        // Снимаем режим удаления
        unset($this->deleteNpcMode[$playerName]);
        unset($this->deleteNpcType[$playerName]);
    }

    private function handleNpcAction(Player $player, string $npcName): void {
        $cleanName = TextFormat::clean($npcName);

        if(str_contains($cleanName, "Паспортный Стол")) {
            Forms::openPassportForm($player, $this);
        } elseif(str_contains($cleanName, "Терапевт")) {
            Forms::openMedCertForm($player, $this);
        } elseif(str_contains($cleanName, "Регистратура")) {
            Forms::openMedCardForm($player, $this);
        } elseif(str_contains($cleanName, "Нарколог")) {
            Forms::openTestForm($player, $this, 'narc');
        } elseif(str_contains($cleanName, "Психиатр")) {
            Forms::openTestForm($player, $this, 'psy');
        } elseif(str_contains($cleanName, "Инструктор")) {
            Forms::openTestForm($player, $this, 'auto');
        } elseif(str_contains($cleanName, "Лицензер")) {
            Forms::openLicenseShop($player, $this);
        }
    }

    // --- ПОЛУЧЕНИЕ ИНФОРМАЦИИ ДЛЯ ФОРМЫ (Паспорт + Организации) ---
    // Этот метод генерирует текст ТОЛЬКО для формы, не трогая предмет
    public function getPassportInfoForForm(string $playerName): string {
        $data = $this->dataManager->getData($playerName, 'passport');
        if (!$data) return "";

        $orgLines = [];
        /** @var RcOrgMain|null $rcOrg */
        $rcOrg = $this->getServer()->getPluginManager()->getPlugin("RcOrg");
        
        if ($rcOrg !== null && $rcOrg->isEnabled()) {
            $rcOrgData = new Config($rcOrg->getDataFolder() . "players.json", Config::JSON);
            $pData = $rcOrgData->get(strtolower($playerName), []);

            $currentOrg = $pData['org'] ?? null;
            $currentRank = $pData['rank'] ?? 0;
            $history = $pData['history'] ?? [];

            $allJobs = $history;
            if ($currentOrg && $currentRank > 0) {
                $allJobs[$currentOrg] = $currentRank;
            }

            foreach ($allJobs as $orgKey => $rank) {
                if ($rank > 0) {
                    $prettyName = $rcOrg->getOrgName($orgKey);
                    $rankName = $rcOrg->getRankName($orgKey, $rank);
                    $orgLines[] = "§r§l§e{$prettyName}:";
                    $orgLines[] = " §r§l§5» §6{$rankName}";
                }
            }
        }

        // Генерируем массив строк
        $lore = Utils::generatePassportLore($data, $orgLines);
        // Превращаем в одну строку для формы
        return implode("\n", $lore);
    }

    // --- ВЫДАЧА ДОКУМЕНТОВ ---

    public function givePassport(Player $player, array $data): void {
        $item = VanillaItems::PAPER();
        $item->setCustomName("§r§l§eПАСПОРТ РФ");
        // Лора нет (или минимальный), вся инфа в форме
        $item->getNamedTag()->setString(Utils::TAG_PASSPORT, $player->getName());
        $player->getInventory()->addItem($item);
    }

    public function giveMedCard(Player $player, array $data): void {
        $item = VanillaItems::POPPED_CHORUS_FRUIT();
        $item->setCustomName("§r§l§cМЕДИЦИНСКАЯ КАРТА");
        $item->getNamedTag()->setString(Utils::TAG_MEDCARD, $player->getName());
        $player->getInventory()->addItem($item);
    }

    public function giveLicense(Player $player, string $type, array $data): void {
        if($type === 'weapon') {
            $item = VanillaItems::BRICK(); 
            $item->setCustomName("§r§l§cЛИЦЕНЗИЯ НА ОРУЖИЕ");
            $tagName = Utils::TAG_LIC_WEAPON;
        } else {
            $item = VanillaItems::NETHER_QUARTZ();
            $item->setCustomName("§r§l§bВОДИТЕЛЬСКОЕ УДОСТОВЕРЕНИЕ");
            $tagName = Utils::TAG_LIC_AUTO;
        }
        $item->getNamedTag()->setString($tagName, $player->getName());
        $player->getInventory()->addItem($item);
    }

    public function onJoin(PlayerJoinEvent $event): void {
        $p = $event->getPlayer();
        $name = $p->getName();
        $this->updateTag($p);
        
        if($data = $this->dataManager->getData($name, 'passport')) {
            if(!$this->hasItem($p, Utils::TAG_PASSPORT)) {
                $this->givePassport($p, $data);
            }
        }

        if($data = $this->dataManager->getData($name, 'medcard')) {
            if(time() > $data['expiry']) {
                $this->dataManager->removeData($name, 'medcard');
                $p->sendMessage("§cСрок действия вашей медкарты истек.");
            } elseif(!$this->hasItem($p, Utils::TAG_MEDCARD)) {
                $this->giveMedCard($p, $data);
            }
        }

        foreach(['lic_weapon' => 'weapon', 'lic_auto' => 'auto'] as $key => $type) {
            if($data = $this->dataManager->getData($name, $key)) {
                if(time() > $data['expiry']) {
                    $this->dataManager->removeData($name, $key);
                    $p->sendMessage("§cСрок лицензии ($type) истек.");
                } else {
                     $tag = $type === 'weapon' ? Utils::TAG_LIC_WEAPON : Utils::TAG_LIC_AUTO;
                     if(!$this->hasItem($p, $tag)) {
                         $this->giveLicense($p, $type, $data);
                     }
                }
            }
        }
    }

    private function hasItem(Player $p, string $tagKey): bool {
        foreach($p->getInventory()->getContents() as $item) {
            if($item->getNamedTag()->getString($tagKey, "") !== "") return true;
        }
        return false;
    }

    public function onItemUse(PlayerItemUseEvent $event): void {
        $item = $event->getItem();
        $player = $event->getPlayer();

        if(Utils::isRcItem($item)) {
            $event->cancel();
            
            // Если это паспорт -> генерируем инфо на лету
            if ($item->getNamedTag()->getTag(Utils::TAG_PASSPORT)) {
                $ownerName = $item->getNamedTag()->getString(Utils::TAG_PASSPORT);
                $info = $this->getPassportInfoForForm($ownerName);
                Forms::openInfoForm($player, $info);
            } else {
              
                $tag = $item->getNamedTag();
                $owner = "";
                $type = "";
                
                if($tag->getTag(Utils::TAG_MEDCARD)) { $owner = $tag->getString(Utils::TAG_MEDCARD); $type = "medcard"; }
                elseif($tag->getTag(Utils::TAG_LIC_WEAPON)) { $owner = $tag->getString(Utils::TAG_LIC_WEAPON); $type = "lic_weapon"; }
                elseif($tag->getTag(Utils::TAG_LIC_AUTO)) { $owner = $tag->getString(Utils::TAG_LIC_AUTO); $type = "lic_auto"; }
                
                if($owner) {
                    $data = $this->dataManager->getData($owner, $type);
                    if($data) {
                        // Генерируем текст для формы
                        if($type == "medcard") $lines = Utils::generateMedLore($data, $data['expiry']);
                        else $lines = Utils::generateLicLore($type == "lic_weapon" ? "weapon" : "auto", $data, $data['expiry']);
                        
                        Forms::openInfoForm($player, implode("\n", $lines));
                    }
                }
            }
        }
    }

    public function onPlayerClickPlayer(EntityDamageByEntityEvent $event): void {
        $damager = $event->getDamager();
        $victim = $event->getEntity();

        if($damager instanceof Player && $victim instanceof Player) {
            $item = $damager->getInventory()->getItemInHand();
            
            if(Utils::isRcItem($item)) {
                $event->cancel();
                
                // ТА ЖЕ ЛОГИКА, ЧТО И В onItemUse
                
                if ($item->getNamedTag()->getTag(Utils::TAG_PASSPORT)) {
                    $ownerName = $item->getNamedTag()->getString(Utils::TAG_PASSPORT);
                    $info = $this->getPassportInfoForForm($ownerName);
                    Forms::openInfoForm($victim, "§eДокумент игрока {$ownerName}:\n\n" . $info);
                    $damager->sendMessage("§aВы показали паспорт игроку " . $victim->getName());
                } else {
                    $tag = $item->getNamedTag();
                    $owner = "";
                    $type = "";
                    if($tag->getTag(Utils::TAG_MEDCARD)) { $owner = $tag->getString(Utils::TAG_MEDCARD); $type = "medcard"; }
                    elseif($tag->getTag(Utils::TAG_LIC_WEAPON)) { $owner = $tag->getString(Utils::TAG_LIC_WEAPON); $type = "lic_weapon"; }
                    elseif($tag->getTag(Utils::TAG_LIC_AUTO)) { $owner = $tag->getString(Utils::TAG_LIC_AUTO); $type = "lic_auto"; }
                    
                    if($owner) {
                        $data = $this->dataManager->getData($owner, $type);
                        if($data) {
                            if($type == "medcard") $lines = Utils::generateMedLore($data, $data['expiry']);
                            else $lines = Utils::generateLicLore($type == "lic_weapon" ? "weapon" : "auto", $data, $data['expiry']);
                            
                            Forms::openInfoForm($victim, "§eДокумент игрока {$owner}:\n\n" . implode("\n", $lines));
                            $damager->sendMessage("§aВы показали документ игроку " . $victim->getName());
                        }
                    }
                }
            }
        }
    }

    public function onDrop(PlayerDropItemEvent $event): void {
        if(Utils::isRcItem($event->getItem())) {
            $event->cancel();
            $event->getPlayer()->sendMessage("§cНельзя выбросить документы!");
        }
    }

    public function onTransaction(InventoryTransactionEvent $event): void {
        foreach($event->getTransaction()->getActions() as $action) {
            if(Utils::isRcItem($action->getSourceItem()) || Utils::isRcItem($action->getTargetItem())) {
            }
        }
    }
}