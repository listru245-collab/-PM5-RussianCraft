<?php

namespace InzeOwr\RcDoxc;

use pocketmine\item\Item;
use pocketmine\nbt\tag\CompoundTag;

class Utils {

    public const TAG_PASSPORT = "rc_passport";
    public const TAG_MEDCARD = "rc_medcard";
    public const TAG_LIC_WEAPON = "rc_lic_weapon";
    public const TAG_LIC_AUTO = "rc_lic_auto";

    // $orgLines - массив строк с должностями
    public static function generatePassportLore(array $data, array $orgLines = []): array {
        $lore = [
            "§r§l§eФИО:",
            " §r§l§5» §6" . $data['fio'],
            "§r§l§eДата рождения:",
            " §r§l§5» §6" . $data['dob'],
            "§r§l§eМесто рождения:",
            " §r§l§5» §6" . $data['pob'],
            "§r§l§eПол:",
            " §r§l§5» §6" . $data['gender'],
            "§r§l§eСерия паспорта:",
            " §r§l§5» §6" . $data['series']
        ];

        // Добавляем организации или "Нет"
        if (!empty($orgLines)) {
            foreach ($orgLines as $line) {
                $lore[] = $line;
            }
        } else {
            $lore[] = "§r§l§eМесто работы:";
            $lore[] = " §r§l§5» §6Нет";
        }

        $lore[] = "§r§l§eПартнер:";
        $lore[] = " §r§l§5» §6Нет";
        $lore[] = "§r§l§eДата выдачи:";
        $lore[] = " §r§l§5» §6" . date("d.m.Y");
        $lore[] = "§r§l§eКем выдано:";
        $lore[] = " §r§l§5» §6ГУ МВД по России г. Берегкс";

        return $lore;
    }

    public static function generateMedLore(array $data, int $expiryTimestamp): array {
        $info = implode("\n §r§l§5» §6", $data['info']);
        return [
            "§r§l§eФИО:",
            " §r§l§5» §6" . $data['fio'],
            "§r§l§eДата рождения:",
            " §r§l§5» §6" . $data['dob'],
            "§r§l§eИнформация:",
            " §r§l§5» §6" . $info,
            "§r§l§eПол:",
            " §r§l§5» §6" . $data['gender'],
            "§r§l§eПолис:",
            " §r§l§5» §6" . $data['policy'],
            "§r§l§eДата выдачи:",
            " §r§l§5» §6" . date("d.m.Y"),
            "§r§l§eДата истечения:",
            " §r§l§5» §6" . date("d.m.Y", $expiryTimestamp),
            "§r§l§eКем выдано:",
            " §r§l§5» §6Городская больница №9 г. Берегкс"
        ];
    }

    public static function generateLicLore(string $type, array $data, int $expiryTimestamp): array {
        $org = $type === 'weapon' ? "Россгвардия" : "ГИБДД";
        $info = implode("\n §r§l§5» §6", $data['info']);
        
        return [
            "§r§l§eФИО:",
            " §r§l§5» §6" . $data['fio'],
            "§r§l§eДата рождения:",
            " §r§l§5» §6" . $data['dob'],
            "§r§l§eПол:",
            " §r§l§5» §6" . $data['gender'],
            "§r§l§eИнформация:",
            " §r§l§5» §6" . $info,
            "§r§l§eСерия лицензии:",
            " §r§l§5» §6" . $data['series'],
            "§r§l§eДата выдачи:",
            " §r§l§5» §6" . date("d.m.Y"),
            "§r§l§eДата истечения:",
            " §r§l§5» §6" . date("d.m.Y", $expiryTimestamp),
            "§r§l§eКем выдано:",
            " §r§l§5» §6$org по России г. Берегкс"
        ];
    }

    public static function isRcItem(Item $item): bool {
        $tag = $item->getNamedTag();
        return $tag->getTag(self::TAG_PASSPORT) !== null || 
               $tag->getTag(self::TAG_MEDCARD) !== null ||
               $tag->getTag(self::TAG_LIC_WEAPON) !== null ||
               $tag->getTag(self::TAG_LIC_AUTO) !== null;
    }
}