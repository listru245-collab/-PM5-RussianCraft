<?php

declare(strict_types=1);

namespace InzeOwr\RcEdit;

use pocketmine\block\Block;
use pocketmine\block\BlockTypeIds;
use pocketmine\block\Fence;
use pocketmine\block\FenceGate;
use pocketmine\block\GlassPane;
use pocketmine\block\IronBars;
use pocketmine\block\Slab;
use pocketmine\block\Stair;
use pocketmine\block\Thin;
use pocketmine\block\Wall;
use pocketmine\block\VanillaBlocks;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\event\Listener;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\item\VanillaItems;
use pocketmine\math\Facing;
use pocketmine\math\Vector3;
use pocketmine\network\mcpe\protocol\UpdateBlockPacket;
use pocketmine\network\mcpe\protocol\types\BlockPosition;
use pocketmine\player\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\utils\TextFormat as TF;
use pocketmine\world\World;

class Main extends PluginBase implements Listener {

    private array $sessions = [];

    /** @var array<string, int> */
    private array $disconnectedBlocks = [];

    private const PREFIX = TF::BOLD . TF::AQUA . "RcEdit" . TF::DARK_GRAY . " » " . TF::RESET . TF::GRAY;
    private const SUCCESS = TF::BOLD . TF::GREEN . "RcEdit" . TF::DARK_GRAY . " » " . TF::RESET . TF::GREEN;
    private const ERR = TF::BOLD . TF::RED . "RcEdit" . TF::DARK_GRAY . " » " . TF::RESET . TF::RED;

    public function onEnable(): void {
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
        // Создаём папку для сохранений
        @mkdir($this->getDataFolder() . "schematics", 0777, true);
        $this->getLogger()->info(TF::GREEN . "RcEdit by InzeOwr загружен!");
    }

    public function onDisable(): void {
        $this->sessions = [];
        $this->disconnectedBlocks = [];
        $this->getLogger()->info(TF::RED . "RcEdit выгружен.");
    }

    public function getSession(Player $player): Session {
        $name = $player->getName();
        if (!isset($this->sessions[$name])) {
            $this->sessions[$name] = new Session($player, $this);
        }
        return $this->sessions[$name];
    }

    public function onQuit(PlayerQuitEvent $event): void {
        $name = $event->getPlayer()->getName();
        if (isset($this->sessions[$name])) {
            unset($this->sessions[$name]);
        }
    }

    public function getSchematicsPath(): string {
        return $this->getDataFolder() . "schematics/";
    }

    // --- Ключ позиции ---

    private function posKey(World $world, Vector3 $pos): string {
        return $world->getFolderName() . ":" . (int)$pos->x . ":" . (int)$pos->y . ":" . (int)$pos->z;
    }

    // --- Обработка событий ---

    public function onInteract(PlayerInteractEvent $event): void {
        $player = $event->getPlayer();
        $item = $event->getItem();
        $block = $event->getBlock();
        $action = $event->getAction();

        if (!$player->hasPermission("rcedit.use")) {
            return;
        }

        $session = $this->getSession($player);

        // 1. Режим ID инспектора
        if ($session->isIdMode()) {
            if ($action === PlayerInteractEvent::RIGHT_CLICK_BLOCK || $action === PlayerInteractEvent::LEFT_CLICK_BLOCK) {
                $event->cancel();
                $blockName = $block->getName();
                $stateId = $block->getStateId();
                $typeId = $block->getTypeId();
                $pos = $block->getPosition();
                $player->sendMessage(self::PREFIX . "Блок: " . TF::YELLOW . $blockName);
                $player->sendMessage(self::PREFIX . "TypeID: " . TF::WHITE . $typeId . TF::GRAY . " | StateID: " . TF::WHITE . $stateId);
                $player->sendMessage(self::PREFIX . "Позиция: " . TF::WHITE . $this->vecStr($pos));
            }
            return;
        }

        // 2. Палка поворота/отсоединения (RcPalke)
        if ($item->getNamedTag()->getTag("RcPalke") !== null) {
            if ($action === PlayerInteractEvent::LEFT_CLICK_BLOCK) {
                $event->cancel();
                $session->setPalkePos1($block->getPosition());
                $player->sendMessage(self::SUCCESS . "Палка Точка 1: " . TF::WHITE . $this->vecStr($block->getPosition()));
                $this->sendPalkeSelectionInfo($player, $session);
                return;
            } elseif ($action === PlayerInteractEvent::RIGHT_CLICK_BLOCK) {
                $event->cancel();

                if (!$session->hasPalkePos1()) {
                    $result = $this->processOneBlock($block, $player);
                    if ($result === "rotated") {
                        $player->sendMessage(self::SUCCESS . "Блок повёрнут: " . TF::WHITE . $block->getName());
                    } elseif ($result === "disconnected") {
                        $player->sendMessage(self::SUCCESS . "Блок отсоединён: " . TF::WHITE . $block->getName());
                    } else {
                        $player->sendMessage(self::ERR . "Этот блок нельзя повернуть/отсоединить.");
                    }
                    return;
                }

                $session->setPalkePos2($block->getPosition());
                $player->sendMessage(self::SUCCESS . "Палка Точка 2: " . TF::WHITE . $this->vecStr($block->getPosition()));
                $this->sendPalkeSelectionInfo($player, $session);
                return;
            }
            return;
        }

        // 3. Выделение топориком
        if ($item->getTypeId() === VanillaItems::GOLDEN_AXE()->getTypeId()) {
            if ($action === PlayerInteractEvent::LEFT_CLICK_BLOCK) {
                $event->cancel();
                $session->setPos1($block->getPosition());
                $player->sendMessage(self::SUCCESS . "Точка 1: " . TF::WHITE . $this->vecStr($block->getPosition()));
                $this->sendSelectionInfo($player, $session);
            } elseif ($action === PlayerInteractEvent::RIGHT_CLICK_BLOCK) {
                $event->cancel();
                $session->setPos2($block->getPosition());
                $player->sendMessage(self::SUCCESS . "Точка 2: " . TF::WHITE . $this->vecStr($block->getPosition()));
                $this->sendSelectionInfo($player, $session);
            }
        }
    }

    public function onBreak(BlockBreakEvent $event): void {
        $player = $event->getPlayer();
        $item = $event->getItem();

        if (!$player->hasPermission("rcedit.use")) {
            return;
        }

        $session = $this->getSession($player);

        if ($session->isIdMode()) {
            $event->cancel();
            return;
        }

        if ($item->getNamedTag()->getTag("RcPalke") !== null) {
            $event->cancel();
            return;
        }

        if ($item->getTypeId() === VanillaItems::GOLDEN_AXE()->getTypeId()) {
            $event->cancel();
        }
    }

    // --- Информация ---

    private function sendSelectionInfo(Player $player, Session $session): void {
        if ($session->hasSelection()) {
            $bounds = $session->getSelectionBounds();
            $min = $bounds['min'];
            $max = $bounds['max'];
            $sizeX = (int)($max->x - $min->x + 1);
            $sizeY = (int)($max->y - $min->y + 1);
            $sizeZ = (int)($max->z - $min->z + 1);
            $total = $sizeX * $sizeY * $sizeZ;
            $player->sendMessage(self::PREFIX . "Размер: " . TF::WHITE . "{$sizeX}x{$sizeY}x{$sizeZ}" . TF::GRAY . " ({$total} блоков)");
        }
    }

    private function sendPalkeSelectionInfo(Player $player, Session $session): void {
        if ($session->hasPalkeSelection()) {
            $bounds = $session->getPalkeSelectionBounds();
            $min = $bounds['min'];
            $max = $bounds['max'];
            $sizeX = (int)($max->x - $min->x + 1);
            $sizeY = (int)($max->y - $min->y + 1);
            $sizeZ = (int)($max->z - $min->z + 1);
            $total = $sizeX * $sizeY * $sizeZ;
            $player->sendMessage(self::PREFIX . "Палка выделение: " . TF::WHITE . "{$sizeX}x{$sizeY}x{$sizeZ}" . TF::GRAY . " ({$total} блоков)");
            $player->sendMessage(self::PREFIX . "Используйте /rcsetp для обработки.");
        }
    }

    // --- Обработка одного блока ---

    private function processOneBlock(Block $block, Player $player): string {
        $world = $player->getWorld();
        $pos = $block->getPosition();
        $session = $this->getSession($player);
        $oldBlock = clone $world->getBlock($pos);

        if ($this->isConnectableBlock($block)) {
            $this->forceDisconnectBlock($world, $pos, $player);
            $session->addSingleUndo($pos, $oldBlock);
            return "disconnected";
        }

        if ($this->isRotatableBlock($block)) {
            $this->forceRotateBlock($world, $pos, $block);
            $session->addSingleUndo($pos, $oldBlock);
            return "rotated";
        }

        return "none";
    }

    // --- Проверки типов ---

    private function isConnectableBlock(Block $block): bool {
        if ($block instanceof Fence) return true;
        if ($block instanceof Wall) return true;
        if ($block instanceof Thin) return true;
        return false;
    }

    private function isRotatableBlock(Block $block): bool {
        if ($block instanceof Stair) return true;
        if ($block instanceof FenceGate) return true;
        if (method_exists($block, 'setFacing') && method_exists($block, 'getFacing')) {
            return true;
        }
        return false;
    }

    // --- ОТСОЕДИНЕНИЕ ---

    private function getCleanBlock(Block $block): Block {
        $cleanBlock = clone $block;

        if ($cleanBlock instanceof Thin) {
            try {
                $ref = new \ReflectionClass($cleanBlock);
                $prop = $ref->getProperty('connections');
                $prop->setAccessible(true);
                $prop->setValue($cleanBlock, []);
            } catch (\Throwable $e) {}
        }

        if ($cleanBlock instanceof Fence) {
            try {
                $ref = new \ReflectionClass($cleanBlock);
                $prop = $ref->getProperty('connections');
                $prop->setAccessible(true);
                $prop->setValue($cleanBlock, []);
            } catch (\Throwable $e) {}
        }

        if ($cleanBlock instanceof Wall) {
            try {
                $ref = new \ReflectionClass($cleanBlock);
                $prop = $ref->getProperty('connections');
                $prop->setAccessible(true);
                $prop->setValue($cleanBlock, []);
                if ($ref->hasProperty('post')) {
                    $postProp = $ref->getProperty('post');
                    $postProp->setAccessible(true);
                    $postProp->setValue($cleanBlock, true);
                }
            } catch (\Throwable $e) {}
        }

        return $cleanBlock;
    }

    private function forceDisconnectBlock(World $world, Vector3 $pos, Player $player): void {
        $block = $world->getBlock($pos);
        $cleanBlock = $this->getCleanBlock($block);
        $cleanStateId = $cleanBlock->getStateId();

        $x = (int)$pos->x;
        $y = (int)$pos->y;
        $z = (int)$pos->z;

        $chunkX = $x >> 4;
        $chunkZ = $z >> 4;
        $chunk = $world->getChunk($chunkX, $chunkZ);

        if ($chunk === null) return;

        $subChunkY = $y >> 4;
        $subChunk = $chunk->getSubChunk($subChunkY);

        $localX = $x & 0x0f;
        $localY = $y & 0x0f;
        $localZ = $z & 0x0f;

        $subChunk->setBlockStateId($localX, $localY, $localZ, $cleanStateId);

        $world->setChunk($chunkX, $chunkZ, $chunk);

        $this->sendBlockPacketToAll($world, $pos, $cleanStateId);

        $this->disconnectedBlocks[$this->posKey($world, $pos)] = $cleanStateId;

        $this->resendNeighbors($world, $pos);
    }

    private function resendNeighbors(World $world, Vector3 $pos): void {
        $sides = [
            $pos->north(),
            $pos->south(),
            $pos->east(),
            $pos->west(),
        ];

        foreach ($sides as $nPos) {
            $nBlock = $world->getBlock($nPos);

            if ($nBlock->getTypeId() === BlockTypeIds::AIR) continue;

            if ($this->isConnectableBlock($nBlock)) {
                $key = $this->posKey($world, $nPos);

                if (isset($this->disconnectedBlocks[$key])) {
                    $this->sendBlockPacketToAll($world, $nPos, $this->disconnectedBlocks[$key]);
                } else {
                    $nX = (int)$nPos->x;
                    $nY = (int)$nPos->y;
                    $nZ = (int)$nPos->z;

                    $ourX = (int)$pos->x;
                    $ourY = (int)$pos->y;
                    $ourZ = (int)$pos->z;

                    $ourChunkX = $ourX >> 4;
                    $ourChunkZ = $ourZ >> 4;
                    $ourChunk = $world->getChunk($ourChunkX, $ourChunkZ);
                    if ($ourChunk === null) continue;

                    $ourSubChunk = $ourChunk->getSubChunk($ourY >> 4);
                    $ourLocalX = $ourX & 0x0f;
                    $ourLocalY = $ourY & 0x0f;
                    $ourLocalZ = $ourZ & 0x0f;

                    $savedState = $ourSubChunk->getBlockStateId($ourLocalX, $ourLocalY, $ourLocalZ);

                    $airStateId = VanillaBlocks::AIR()->getStateId();
                    $ourSubChunk->setBlockStateId($ourLocalX, $ourLocalY, $ourLocalZ, $airStateId);

                    $world->setBlockAt($nX, $nY, $nZ, VanillaBlocks::AIR(), false);
                    $world->setBlockAt($nX, $nY, $nZ, $nBlock, false);

                    $updatedNeighborStateId = $world->getBlock($nPos)->getStateId();

                    $ourSubChunk->setBlockStateId($ourLocalX, $ourLocalY, $ourLocalZ, $savedState);

                    $this->sendBlockPacketToAll($world, $nPos, $updatedNeighborStateId);
                }
            }
        }
    }

    private function sendBlockPacketToAll(World $world, Vector3 $pos, int $stateId): void {
        $blockPos = BlockPosition::fromVector3($pos);

        foreach ($world->getPlayers() as $p) {
            $networkId = $p->getNetworkSession()->getTypeConverter()->getBlockTranslator()->internalIdToNetworkId($stateId);
            $p->getNetworkSession()->sendDataPacket(UpdateBlockPacket::create(
                $blockPos,
                $networkId,
                UpdateBlockPacket::FLAG_NETWORK,
                UpdateBlockPacket::DATA_LAYER_NORMAL
            ));
        }
    }

    // --- Поворот блока ---

    private function forceRotateBlock(World $world, Vector3 $pos, Block $block): void {
        if (!method_exists($block, 'setFacing') || !method_exists($block, 'getFacing')) {
            return;
        }

        try {
            $currentFacing = $block->getFacing();

            $order = [Facing::NORTH, Facing::EAST, Facing::SOUTH, Facing::WEST];
            $verticalOrder = [Facing::UP, Facing::DOWN];

            $idx = array_search($currentFacing, $order, true);
            if ($idx !== false) {
                $nextIdx = ($idx + 1) % count($order);
                $block->setFacing($order[$nextIdx]);
                $world->setBlockAt((int)$pos->x, (int)$pos->y, (int)$pos->z, $block, false);
                $this->sendBlockPacketToAll($world, $pos, $block->getStateId());
                return;
            }

            $idx = array_search($currentFacing, $verticalOrder, true);
            if ($idx !== false) {
                $nextIdx = ($idx + 1) % count($verticalOrder);
                $block->setFacing($verticalOrder[$nextIdx]);
                $world->setBlockAt((int)$pos->x, (int)$pos->y, (int)$pos->z, $block, false);
                $this->sendBlockPacketToAll($world, $pos, $block->getStateId());
                return;
            }
        } catch (\Throwable $e) {}
    }

    // --- Обработка палкой всего выделения ---

    private function processPalkeSelection(Player $player, Session $session): array {
        $bounds = $session->getPalkeSelectionBounds();
        if ($bounds === null) return ['rotated' => 0, 'disconnected' => 0];

        $min = $bounds['min'];
        $max = $bounds['max'];
        $world = $player->getWorld();

        $rotated = 0;
        $disconnected = 0;
        $undoData = [];

        for ($x = (int)$min->x; $x <= (int)$max->x; $x++) {
            for ($y = (int)$min->y; $y <= (int)$max->y; $y++) {
                for ($z = (int)$min->z; $z <= (int)$max->z; $z++) {
                    $pos = new Vector3($x, $y, $z);
                    $block = $world->getBlock($pos);

                    if ($block->getTypeId() === BlockTypeIds::AIR) continue;

                    $isConnectable = $this->isConnectableBlock($block);
                    $isRotatable = $this->isRotatableBlock($block);

                    if (!$isConnectable && !$isRotatable) continue;

                    $oldBlock = clone $world->getBlock($pos);
                    $undoData[] = ['vec' => $pos, 'block' => $oldBlock];

                    if ($isConnectable) {
                        $this->forceDisconnectBlock($world, $pos, $player);
                        $disconnected++;
                    } elseif ($isRotatable) {
                        $this->forceRotateBlock($world, $pos, $block);
                        $rotated++;
                    }
                }
            }
        }

        if (!empty($undoData)) {
            $session->saveUndoPublic($undoData);
        }

        return ['rotated' => $rotated, 'disconnected' => $disconnected];
    }

    // --- Команды ---

    public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool {
        if (!$sender instanceof Player) {
            $sender->sendMessage(self::ERR . "Только для игроков.");
            return true;
        }
        if (!$sender->hasPermission("rcedit.use")) {
            $sender->sendMessage(self::ERR . "Нет прав.");
            return true;
        }

        $session = $this->getSession($sender);

        switch ($command->getName()) {

            case "rcwand":
                $wand = VanillaItems::GOLDEN_AXE();
                $wand->setCustomName(TF::RESET . TF::GOLD . TF::BOLD . "✦ " . TF::RESET . TF::GOLD . "RcEdit Wand");
                $wand->setLore([
                    TF::GRAY . "ЛКМ по блоку: " . TF::WHITE . "Точка 1",
                    TF::GRAY . "ПКМ по блоку: " . TF::WHITE . "Точка 2",
                ]);
                $sender->getInventory()->addItem($wand);
                $sender->sendMessage(self::SUCCESS . "Топорик выделения выдан.");
                return true;

            case "rcpalke":
                $session->clearPalkeSelection();

                $stick = VanillaItems::STICK();
                $stick->setCustomName(TF::RESET . TF::LIGHT_PURPLE . TF::BOLD . "⚙ " . TF::RESET . TF::LIGHT_PURPLE . "RcEdit Палка");
                $stick->setLore([
                    TF::GRAY . "ПКМ по блоку: " . TF::WHITE . "Повернуть/Отсоединить",
                    TF::GRAY . "ЛКМ по блоку: " . TF::WHITE . "Палка Точка 1",
                    TF::GRAY . "ПКМ (с P1): " . TF::WHITE . "Палка Точка 2",
                    TF::GRAY . "Затем: " . TF::YELLOW . "/rcsetp",
                ]);
                $stick->getNamedTag()->setString("RcPalke", "true");
                $sender->getInventory()->addItem($stick);
                $sender->sendMessage(self::SUCCESS . "Палка поворота/отсоединения выдана.");
                $sender->sendMessage(self::PREFIX . "ПКМ по блоку — повернуть/отсоединить один блок.");
                $sender->sendMessage(self::PREFIX . "ЛКМ=P1, ПКМ=P2, затем /rcsetp.");
                return true;

            case "rcsetp":
                if (!$session->hasPalkeSelection()) {
                    $sender->sendMessage(self::ERR . "Нет выделения палкой.");
                    $sender->sendMessage(self::PREFIX . "Возьмите палку (/rcpalke), ЛКМ=P1, ПКМ=P2.");
                    return true;
                }

                $result = $this->processPalkeSelection($sender, $session);
                $sender->sendMessage(self::SUCCESS . "Повёрнуто: " . TF::WHITE . $result['rotated'] . TF::GREEN . ", отсоединено: " . TF::WHITE . $result['disconnected'] . TF::GREEN . ".");
                $sender->sendMessage(self::PREFIX . "Введите /rcsetp ещё раз для повторного поворота.");
                return true;

            case "rcid":
                $state = $session->toggleIdMode();
                if ($state) {
                    $sender->sendMessage(self::SUCCESS . "Режим ID " . TF::GREEN . "ВКЛЮЧЕН" . TF::GRAY . ". Тапните по блоку.");
                } else {
                    $sender->sendMessage(self::PREFIX . "Режим ID " . TF::RED . "ВЫКЛЮЧЕН.");
                }
                return true;

            case "rce":
                if (!isset($args[0]) || !in_array($args[0], ["1", "2"])) {
                    $sender->sendMessage(self::ERR . "Использование: /rce <1|2>");
                    return true;
                }
                $pos = $sender->getPosition()->floor();
                if ($args[0] === "1") {
                    $session->setPos1($pos);
                    $sender->sendMessage(self::SUCCESS . "Точка 1 (ноги): " . TF::WHITE . $this->vecStr($pos));
                } else {
                    $session->setPos2($pos);
                    $sender->sendMessage(self::SUCCESS . "Точка 2 (ноги): " . TF::WHITE . $this->vecStr($pos));
                }
                $this->sendSelectionInfo($sender, $session);
                return true;

            case "rcset":
                if (!$session->hasSelection()) {
                    $sender->sendMessage(self::ERR . "Сначала выделите область (/rcwand).");
                    return true;
                }
                if (!isset($args[0])) {
                    $sender->sendMessage(self::ERR . "Использование: /rcset <название_блока>");
                    return true;
                }

                $block = $this->parseBlock($args[0]);
                if ($block === null) {
                    $sender->sendMessage(self::ERR . "Блок \"" . $args[0] . "\" не найден.");
                    return true;
                }

                $count = $session->fillSelection($block);
                $sender->sendMessage(self::SUCCESS . "Установлено " . TF::WHITE . $count . TF::GREEN . " блоков.");
                return true;

            case "rccopy":
                if (!$session->hasSelection()) {
                    $sender->sendMessage(self::ERR . "Сначала выделите область.");
                    return true;
                }

                $count = $session->copy();
                if ($count === 0) {
                    $sender->sendMessage(self::ERR . "Область пуста.");
                    return true;
                }
                $sender->sendMessage(self::SUCCESS . "Скопировано " . TF::WHITE . $count . TF::GREEN . " блоков.");
                $sender->sendMessage(self::PREFIX . "Выделите новую область и /rcpaste");
                $sender->sendMessage(self::PREFIX . "Или /rcrotate <1|2|3> для поворота.");
                return true;

            case "rcpaste":
                if (!$session->hasClipboard()) {
                    $sender->sendMessage(self::ERR . "Буфер пуст. Сначала /rccopy.");
                    return true;
                }
                if (!$session->hasSelection()) {
                    $sender->sendMessage(self::ERR . "Выделите область для вставки (точка 1 = начало).");
                    return true;
                }

                $count = $session->pasteToSelection();
                if ($count === 0) {
                    $sender->sendMessage(self::ERR . "Нечего вставлять.");
                    return true;
                }
                $sender->sendMessage(self::SUCCESS . "Вставлено " . TF::WHITE . $count . TF::GREEN . " блоков.");
                return true;

            // --- RCCOPYX — Сохранить в файл ---
            case "rccopyx":
                if (!$session->hasSelection()) {
                    $sender->sendMessage(self::ERR . "Сначала выделите область.");
                    return true;
                }
                if (!isset($args[0])) {
                    $sender->sendMessage(self::ERR . "Использование: /rccopyx <название>");
                    return true;
                }

                $name = strtolower(trim($args[0]));

                // Проверка имени
                if (!preg_match('/^[a-zA-Z0-9_\-]+$/', $name)) {
                    $sender->sendMessage(self::ERR . "Название может содержать только буквы, цифры, _ и -");
                    return true;
                }

                $result = $session->saveSchematic($name);
                if ($result === false) {
                    $sender->sendMessage(self::ERR . "Ошибка сохранения.");
                    return true;
                }

                $sender->sendMessage(self::SUCCESS . "Постройка сохранена как: " . TF::WHITE . $name);
                $sender->sendMessage(self::PREFIX . "Вставить: /rcpastex " . $name);
                $sender->sendMessage(self::PREFIX . "Удалить: /rccopyu " . $name);
                return true;

            // --- RCCOPYU — Удалить сохранённую ---
            case "rccopyu":
                if (!isset($args[0])) {
                    $sender->sendMessage(self::ERR . "Использование: /rccopyu <название>");

                    // Показываем список сохранённых
                    $files = glob($this->getSchematicsPath() . "*.json");
                    if (!empty($files)) {
                        $sender->sendMessage(self::PREFIX . "Сохранённые постройки:");
                        foreach ($files as $file) {
                            $fname = basename($file, ".json");
                            $sender->sendMessage(self::PREFIX . " - " . TF::YELLOW . $fname);
                        }
                    } else {
                        $sender->sendMessage(self::PREFIX . "Нет сохранённых построек.");
                    }
                    return true;
                }

                $name = strtolower(trim($args[0]));
                $path = $this->getSchematicsPath() . $name . ".json";

                if (!file_exists($path)) {
                    $sender->sendMessage(self::ERR . "Постройка \"" . $name . "\" не найдена.");

                    // Показываем список
                    $files = glob($this->getSchematicsPath() . "*.json");
                    if (!empty($files)) {
                        $sender->sendMessage(self::PREFIX . "Доступные постройки:");
                        foreach ($files as $file) {
                            $fname = basename($file, ".json");
                            $sender->sendMessage(self::PREFIX . " - " . TF::YELLOW . $fname);
                        }
                    }
                    return true;
                }

                unlink($path);
                $sender->sendMessage(self::SUCCESS . "Постройка \"" . TF::WHITE . $name . TF::GREEN . "\" удалена.");
                return true;

            // --- RCPASTEX — Вставить из файла на позиции игрока ---
            case "rcpastex":
                if (!isset($args[0])) {
                    $sender->sendMessage(self::ERR . "Использование: /rcpastex <название>");

                    // Показываем список
                    $files = glob($this->getSchematicsPath() . "*.json");
                    if (!empty($files)) {
                        $sender->sendMessage(self::PREFIX . "Сохранённые постройки:");
                        foreach ($files as $file) {
                            $fname = basename($file, ".json");
                            $sender->sendMessage(self::PREFIX . " - " . TF::YELLOW . $fname);
                        }
                    } else {
                        $sender->sendMessage(self::PREFIX . "Нет сохранённых построек.");
                    }
                    return true;
                }

                $name = strtolower(trim($args[0]));

                $loaded = $session->loadSchematic($name);
                if (!$loaded) {
                    $sender->sendMessage(self::ERR . "Постройка \"" . $name . "\" не найдена.");

                    $files = glob($this->getSchematicsPath() . "*.json");
                    if (!empty($files)) {
                        $sender->sendMessage(self::PREFIX . "Доступные постройки:");
                        foreach ($files as $file) {
                            $fname = basename($file, ".json");
                            $sender->sendMessage(self::PREFIX . " - " . TF::YELLOW . $fname);
                        }
                    }
                    return true;
                }

                // Вставляем на позиции игрока
                $count = $session->pasteAtPlayer();
                if ($count === 0) {
                    $sender->sendMessage(self::ERR . "Нечего вставлять.");
                    return true;
                }
                $sender->sendMessage(self::SUCCESS . "Вставлено \"" . TF::WHITE . $name . TF::GREEN . "\": " . TF::WHITE . $count . TF::GREEN . " блоков.");
                return true;

            case "rcrotate":
                if (!$session->hasClipboard()) {
                    $sender->sendMessage(self::ERR . "Буфер пуст. Сначала /rccopy.");
                    return true;
                }
                if (!isset($args[0]) || !in_array($args[0], ["1", "2", "3"])) {
                    $sender->sendMessage(self::ERR . "Использование: /rcrotate <1|2|3>");
                    $sender->sendMessage(self::PREFIX . "1 = 90° вправо");
                    $sender->sendMessage(self::PREFIX . "2 = 90° влево");
                    $sender->sendMessage(self::PREFIX . "3 = 180° разворот");
                    return true;
                }
                $dir = (int)$args[0];
                $session->rotateClipboard($dir);
                $msg = match($dir) {
                    1 => "90° вправо",
                    2 => "90° влево",
                    3 => "180° (разворот)",
                    default => "?"
                };
                $sender->sendMessage(self::SUCCESS . "Буфер повернут на " . TF::WHITE . $msg . TF::GREEN . ".");
                return true;

            case "rcundo":
                if ($session->undo()) {
                    $sender->sendMessage(self::SUCCESS . "Действие отменено.");
                } else {
                    $sender->sendMessage(self::ERR . "Нечего отменять.");
                }
                return true;

            case "rcreturn":
                if ($session->redo()) {
                    $sender->sendMessage(self::SUCCESS . "Действие возвращено.");
                } else {
                    $sender->sendMessage(self::ERR . "Нечего возвращать.");
                }
                return true;

            case "rcconnect":
                if (count($args) < 2) {
                    $sender->sendMessage(self::ERR . "Использование: /rcconnect <блоки> <режим>");
                    $sender->sendMessage(self::PREFIX . "Блоки: stone%50,dirt%50");
                    $sender->sendMessage(self::PREFIX . "Режим: 1=стены, 2=пол/потолок, 3=все");
                    return true;
                }
                if (!$session->hasSelection()) {
                    $sender->sendMessage(self::ERR . "Нет выделения.");
                    return true;
                }

                $patternString = $args[0];
                $mode = (int)$args[1];

                if ($mode < 1 || $mode > 3) {
                    $sender->sendMessage(self::ERR . "Режим должен быть 1, 2 или 3.");
                    return true;
                }

                $pattern = [];
                $parts = explode(",", $patternString);
                foreach ($parts as $part) {
                    $d = explode("%", $part);
                    $bName = $d[0];
                    $chance = isset($d[1]) ? (float)$d[1] : 100.0;
                    if ($chance <= 0) continue;
                    $blk = $this->parseBlock($bName);
                    if ($blk !== null) {
                        $pattern[] = ['block' => $blk, 'chance' => $chance];
                    } else {
                        $sender->sendMessage(self::ERR . "Блок \"" . $bName . "\" не найден, пропущен.");
                    }
                }

                if (empty($pattern)) {
                    $sender->sendMessage(self::ERR . "Ни один блок не распознан.");
                    return true;
                }

                $count = $session->connectPattern($pattern, $mode);
                $sender->sendMessage(self::SUCCESS . "Установлено " . TF::WHITE . $count . TF::GREEN . " блоков.");
                return true;
        }
        return true;
    }

    // --- Утилиты ---

    private function vecStr(Vector3 $v): string {
        return (int)$v->x . ", " . (int)$v->y . ", " . (int)$v->z;
    }

    private function parseBlock(string $input): ?Block {
        $input = strtolower(trim($input));
        if ($input === "0" || $input === "air") {
            return VanillaBlocks::AIR();
        }
        if (is_numeric($input)) {
            return null;
        }
        try {
            $item = \pocketmine\item\StringToItemParser::getInstance()->parse($input);
            if ($item !== null) {
                $block = $item->getBlock();
                if ($block->getTypeId() !== BlockTypeIds::AIR || $input === "air") {
                    return $block;
                }
            }
        } catch (\Throwable $e) {}
        return null;
    }
}

// ========================================================
// Класс Сессии
// ========================================================

class Session {
    private Player $player;
    private Main $plugin;

    private ?Vector3 $pos1 = null;
    private ?Vector3 $pos2 = null;

    private ?Vector3 $palkePos1 = null;
    private ?Vector3 $palkePos2 = null;

    /** @var array{vec: Vector3, block: Block}[] */
    private array $clipboard = [];

    /** @var array{sizeX: int, sizeY: int, sizeZ: int}|null */
    private ?array $clipboardSize = null;

    /** @var array[] */
    private array $undoStack = [];
    /** @var array[] */
    private array $redoStack = [];

    private bool $idMode = false;

    private const MAX_UNDO = 50;

    public function __construct(Player $player, Main $plugin) {
        $this->player = $player;
        $this->plugin = $plugin;
    }

    // --- Основные позиции ---

    public function setPos1(Vector3 $pos): void {
        $this->pos1 = $pos->floor();
    }

    public function setPos2(Vector3 $pos): void {
        $this->pos2 = $pos->floor();
    }

    public function getPos1(): ?Vector3 {
        return $this->pos1;
    }

    public function getPos2(): ?Vector3 {
        return $this->pos2;
    }

    public function hasSelection(): bool {
        return $this->pos1 !== null && $this->pos2 !== null;
    }

    public function getSelectionBounds(): ?array {
        if (!$this->hasSelection()) return null;
        return [
            'min' => new Vector3(
                min($this->pos1->x, $this->pos2->x),
                min($this->pos1->y, $this->pos2->y),
                min($this->pos1->z, $this->pos2->z)
            ),
            'max' => new Vector3(
                max($this->pos1->x, $this->pos2->x),
                max($this->pos1->y, $this->pos2->y),
                max($this->pos1->z, $this->pos2->z)
            )
        ];
    }

    // --- Позиции палки ---

    public function setPalkePos1(Vector3 $pos): void {
        $this->palkePos1 = $pos->floor();
    }

    public function setPalkePos2(Vector3 $pos): void {
        $this->palkePos2 = $pos->floor();
    }

    public function hasPalkePos1(): bool {
        return $this->palkePos1 !== null;
    }

    public function hasPalkeSelection(): bool {
        return $this->palkePos1 !== null && $this->palkePos2 !== null;
    }

    public function getPalkeSelectionBounds(): ?array {
        if (!$this->hasPalkeSelection()) return null;
        return [
            'min' => new Vector3(
                min($this->palkePos1->x, $this->palkePos2->x),
                min($this->palkePos1->y, $this->palkePos2->y),
                min($this->palkePos1->z, $this->palkePos2->z)
            ),
            'max' => new Vector3(
                max($this->palkePos1->x, $this->palkePos2->x),
                max($this->palkePos1->y, $this->palkePos2->y),
                max($this->palkePos1->z, $this->palkePos2->z)
            )
        ];
    }

    public function clearPalkeSelection(): void {
        $this->palkePos1 = null;
        $this->palkePos2 = null;
    }

    // --- Clipboard ---

    public function getClipboard(): array {
        return $this->clipboard;
    }

    public function hasClipboard(): bool {
        return !empty($this->clipboard);
    }

    // --- ID Mode ---

    public function isIdMode(): bool {
        return $this->idMode;
    }

    public function toggleIdMode(): bool {
        $this->idMode = !$this->idMode;
        return $this->idMode;
    }

    // --- Undo ---

    private function saveUndo(array $blocks): void {
        if (empty($blocks)) return;
        $this->undoStack[] = $blocks;
        $this->redoStack = [];
        while (count($this->undoStack) > self::MAX_UNDO) {
            array_shift($this->undoStack);
        }
    }

    public function saveUndoPublic(array $blocks): void {
        $this->saveUndo($blocks);
    }

    public function addSingleUndo(Vector3 $pos, Block $oldBlock): void {
        $this->saveUndo([['vec' => $pos, 'block' => $oldBlock]]);
    }

    public function undo(): bool {
        if (empty($this->undoStack)) return false;
        $lastAction = array_pop($this->undoStack);

        $redoAction = [];
        $world = $this->player->getWorld();

        foreach ($lastAction as $data) {
            $pos = $data['vec'];
            $prevBlock = $data['block'];

            $redoAction[] = ['vec' => $pos, 'block' => $world->getBlock($pos)];
            $world->setBlock($pos, $prevBlock, false);
        }

        $this->redoStack[] = $redoAction;
        return true;
    }

    public function redo(): bool {
        if (empty($this->redoStack)) return false;
        $lastUndo = array_pop($this->redoStack);

        $undoAction = [];
        $world = $this->player->getWorld();

        foreach ($lastUndo as $data) {
            $pos = $data['vec'];
            $block = $data['block'];

            $undoAction[] = ['vec' => $pos, 'block' => $world->getBlock($pos)];
            $world->setBlock($pos, $block, false);
        }

        $this->undoStack[] = $undoAction;
        return true;
    }

    // --- Fill ---

    public function fillSelection(Block $block): int {
        $bounds = $this->getSelectionBounds();
        if ($bounds === null) return 0;

        $min = $bounds['min'];
        $max = $bounds['max'];
        $world = $this->player->getWorld();

        $undoData = [];
        $count = 0;

        for ($x = (int)$min->x; $x <= (int)$max->x; $x++) {
            for ($y = (int)$min->y; $y <= (int)$max->y; $y++) {
                for ($z = (int)$min->z; $z <= (int)$max->z; $z++) {
                    $pos = new Vector3($x, $y, $z);
                    $oldBlock = $world->getBlock($pos);

                    if ($oldBlock->isSameState($block)) continue;

                    $undoData[] = ['vec' => $pos, 'block' => $oldBlock];
                    $world->setBlock($pos, $block, false);
                    $count++;
                }
            }
        }
        $this->saveUndo($undoData);
        return $count;
    }

    // --- Copy ---

    public function copy(): int {
        $bounds = $this->getSelectionBounds();
        if ($bounds === null) return 0;

        $min = $bounds['min'];
        $max = $bounds['max'];
        $world = $this->player->getWorld();

        $this->clipboard = [];

        $sizeX = (int)($max->x - $min->x + 1);
        $sizeY = (int)($max->y - $min->y + 1);
        $sizeZ = (int)($max->z - $min->z + 1);

        $this->clipboardSize = [
            'sizeX' => $sizeX,
            'sizeY' => $sizeY,
            'sizeZ' => $sizeZ
        ];

        for ($x = (int)$min->x; $x <= (int)$max->x; $x++) {
            for ($y = (int)$min->y; $y <= (int)$max->y; $y++) {
                for ($z = (int)$min->z; $z <= (int)$max->z; $z++) {
                    $pos = new Vector3($x, $y, $z);
                    $block = $world->getBlock($pos);

                    $relative = new Vector3(
                        $x - (int)$min->x,
                        $y - (int)$min->y,
                        $z - (int)$min->z
                    );
                    $this->clipboard[] = ['vec' => $relative, 'block' => $block];
                }
            }
        }

        return count($this->clipboard);
    }

    // --- Paste (по выделению) ---

    public function pasteToSelection(): int {
        if (empty($this->clipboard)) return 0;

        $bounds = $this->getSelectionBounds();
        if ($bounds === null) return 0;

        $pasteMin = $bounds['min'];
        $world = $this->player->getWorld();

        $undoData = [];
        $count = 0;

        foreach ($this->clipboard as $entry) {
            $rel = $entry['vec'];
            $block = $entry['block'];

            $pastePos = new Vector3(
                (int)$pasteMin->x + (int)$rel->x,
                (int)$pasteMin->y + (int)$rel->y,
                (int)$pasteMin->z + (int)$rel->z
            );

            $oldBlock = $world->getBlock($pastePos);

            if ($oldBlock->isSameState($block)) continue;

            $undoData[] = ['vec' => $pastePos, 'block' => $oldBlock];
            $world->setBlock($pastePos, $block, false);
            $count++;
        }

        $this->saveUndo($undoData);
        return $count;
    }

    // --- Paste на позиции игрока (для rcpastex) ---

    public function pasteAtPlayer(): int {
        if (empty($this->clipboard)) return 0;

        $playerPos = $this->player->getPosition()->floor();
        $world = $this->player->getWorld();

        $undoData = [];
        $count = 0;

        foreach ($this->clipboard as $entry) {
            $rel = $entry['vec'];
            $block = $entry['block'];

            $pastePos = new Vector3(
                (int)$playerPos->x + (int)$rel->x,
                (int)$playerPos->y + (int)$rel->y,
                (int)$playerPos->z + (int)$rel->z
            );

            $oldBlock = $world->getBlock($pastePos);

            if ($oldBlock->isSameState($block)) continue;

            $undoData[] = ['vec' => $pastePos, 'block' => $oldBlock];
            $world->setBlock($pastePos, $block, false);
            $count++;
        }

        $this->saveUndo($undoData);
        return $count;
    }

    // --- Сохранение/Загрузка схематик ---

    /**
     * Сохраняет текущее выделение в файл
     */
    public function saveSchematic(string $name): bool {
        $bounds = $this->getSelectionBounds();
        if ($bounds === null) return false;

        $min = $bounds['min'];
        $max = $bounds['max'];
        $world = $this->player->getWorld();

        $data = [];
        $data['sizeX'] = (int)($max->x - $min->x + 1);
        $data['sizeY'] = (int)($max->y - $min->y + 1);
        $data['sizeZ'] = (int)($max->z - $min->z + 1);
        $data['blocks'] = [];

        for ($x = (int)$min->x; $x <= (int)$max->x; $x++) {
            for ($y = (int)$min->y; $y <= (int)$max->y; $y++) {
                for ($z = (int)$min->z; $z <= (int)$max->z; $z++) {
                    $pos = new Vector3($x, $y, $z);
                    $block = $world->getBlock($pos);

                    $data['blocks'][] = [
                        'rx' => $x - (int)$min->x,
                        'ry' => $y - (int)$min->y,
                        'rz' => $z - (int)$min->z,
                        'sid' => $block->getStateId()
                    ];
                }
            }
        }

        $path = $this->plugin->getSchematicsPath() . $name . ".json";
        $json = json_encode($data, JSON_UNESCAPED_UNICODE);

        if ($json === false) return false;

        return file_put_contents($path, $json) !== false;
    }

    /**
     * Загружает схематик из файла в буфер обмена
     */
    public function loadSchematic(string $name): bool {
        $path = $this->plugin->getSchematicsPath() . $name . ".json";

        if (!file_exists($path)) return false;

        $content = file_get_contents($path);
        if ($content === false) return false;

        $data = json_decode($content, true);
        if ($data === null) return false;

        if (!isset($data['blocks']) || !isset($data['sizeX'])) return false;

        $this->clipboard = [];
        $this->clipboardSize = [
            'sizeX' => (int)$data['sizeX'],
            'sizeY' => (int)$data['sizeY'],
            'sizeZ' => (int)$data['sizeZ']
        ];

        $blockStateRegistry = \pocketmine\block\RuntimeBlockStateRegistry::getInstance();

        foreach ($data['blocks'] as $entry) {
            $rx = (int)$entry['rx'];
            $ry = (int)$entry['ry'];
            $rz = (int)$entry['rz'];
            $stateId = (int)$entry['sid'];

            try {
                $block = $blockStateRegistry->fromStateId($stateId);
            } catch (\Throwable $e) {
                $block = VanillaBlocks::AIR();
            }

            $this->clipboard[] = [
                'vec' => new Vector3($rx, $ry, $rz),
                'block' => $block
            ];
        }

        return !empty($this->clipboard);
    }

    // --- Rotate ---

    public function rotateClipboard(int $direction): void {
        if (empty($this->clipboard)) return;
        if ($this->clipboardSize === null) return;

        $maxX = $this->clipboardSize['sizeX'] - 1;
        $maxZ = $this->clipboardSize['sizeZ'] - 1;

        $newClipboard = [];
        foreach ($this->clipboard as $entry) {
            $vec = $entry['vec'];
            $block = clone $entry['block'];

            $x = (int)$vec->x;
            $y = (int)$vec->y;
            $z = (int)$vec->z;

            $newX = $x;
            $newZ = $z;

            if ($direction === 1) {
                $newX = $maxZ - $z;
                $newZ = $x;
            } elseif ($direction === 2) {
                $newX = $z;
                $newZ = $maxX - $x;
            } elseif ($direction === 3) {
                $newX = $maxX - $x;
                $newZ = $maxZ - $z;
            }

            $newVec = new Vector3($newX, $y, $newZ);

            $this->rotateBlockFacing($block, $direction);

            $newClipboard[] = ['vec' => $newVec, 'block' => $block];
        }
        $this->clipboard = $newClipboard;

        if ($direction === 1 || $direction === 2) {
            $oldSizeX = $this->clipboardSize['sizeX'];
            $oldSizeZ = $this->clipboardSize['sizeZ'];
            $this->clipboardSize['sizeX'] = $oldSizeZ;
            $this->clipboardSize['sizeZ'] = $oldSizeX;
        }
    }

    private function rotateBlockFacing(Block $block, int $direction): void {
        if (!method_exists($block, 'setFacing') || !method_exists($block, 'getFacing')) {
            return;
        }

        try {
            $currentFacing = $block->getFacing();

            if (!in_array($currentFacing, [Facing::NORTH, Facing::EAST, Facing::SOUTH, Facing::WEST], true)) {
                return;
            }

            $clockwise = [
                Facing::NORTH => Facing::EAST,
                Facing::EAST  => Facing::SOUTH,
                Facing::SOUTH => Facing::WEST,
                Facing::WEST  => Facing::NORTH,
            ];

            $counterClockwise = [
                Facing::NORTH => Facing::WEST,
                Facing::WEST  => Facing::SOUTH,
                Facing::SOUTH => Facing::EAST,
                Facing::EAST  => Facing::NORTH,
            ];

            $flip = [
                Facing::NORTH => Facing::SOUTH,
                Facing::SOUTH => Facing::NORTH,
                Facing::EAST  => Facing::WEST,
                Facing::WEST  => Facing::EAST,
            ];

            if ($direction === 1 && isset($clockwise[$currentFacing])) {
                $block->setFacing($clockwise[$currentFacing]);
            } elseif ($direction === 2 && isset($counterClockwise[$currentFacing])) {
                $block->setFacing($counterClockwise[$currentFacing]);
            } elseif ($direction === 3 && isset($flip[$currentFacing])) {
                $block->setFacing($flip[$currentFacing]);
            }
        } catch (\Throwable $e) {}
    }

    // --- Connect Pattern ---

    public function connectPattern(array $pattern, int $mode): int {
        $bounds = $this->getSelectionBounds();
        if ($bounds === null) return 0;

        $min = $bounds['min'];
        $max = $bounds['max'];
        $world = $this->player->getWorld();
        $undoData = [];
        $count = 0;

        for ($x = (int)$min->x; $x <= (int)$max->x; $x++) {
            for ($y = (int)$min->y; $y <= (int)$max->y; $y++) {
                for ($z = (int)$min->z; $z <= (int)$max->z; $z++) {

                    $isWall = ($x == (int)$min->x || $x == (int)$max->x || $z == (int)$min->z || $z == (int)$max->z);
                    $isFloorCeil = ($y == (int)$min->y || $y == (int)$max->y);

                    $place = false;
                    if ($mode === 3) $place = true;
                    if ($mode === 2 && $isFloorCeil) $place = true;
                    if ($mode === 1 && $isWall) $place = true;

                    if (!$place) continue;

                    $selectedBlock = $this->pickRandomBlock($pattern);
                    $this->randomizeFacing($selectedBlock);

                    $pos = new Vector3($x, $y, $z);
                    $oldBlock = $world->getBlock($pos);
                    $undoData[] = ['vec' => $pos, 'block' => $oldBlock];
                    $world->setBlock($pos, $selectedBlock, false);
                    $count++;
                }
            }
        }
        $this->saveUndo($undoData);
        return $count;
    }

    private function pickRandomBlock(array $pattern): Block {
        $totalChance = 0;
        foreach ($pattern as $item) {
            $totalChance += $item['chance'];
        }

        $rand = mt_rand(1, max(1, (int)$totalChance));
        $current = 0;
        foreach ($pattern as $item) {
            $current += $item['chance'];
            if ($rand <= $current) {
                return clone $item['block'];
            }
        }
        return clone $pattern[0]['block'];
    }

    private function randomizeFacing(Block $block): void {
        $facings = [Facing::NORTH, Facing::EAST, Facing::SOUTH, Facing::WEST];
        if (method_exists($block, 'setFacing')) {
            try {
                $block->setFacing($facings[array_rand($facings)]);
            } catch (\Throwable $e) {}
        }
    }
}