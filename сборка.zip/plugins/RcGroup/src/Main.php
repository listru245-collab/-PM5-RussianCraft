<?php
declare(strict_types=1);

namespace InzeOwr\RcGroup;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\permission\PermissionAttachment;
use pocketmine\player\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\utils\Config;
use pocketmine\utils\TextFormat as C;

class Main extends PluginBase implements Listener {

    private Config $cfg;
    public Config $groupsCfg;
    private Config $playersCfg;
    public Config $prefixCfg;

    /** @var array<string, PermissionAttachment> */
    private array $attachments = [];

    /** @var array<string, string> */
    private array $orgTags = [];

    public function onEnable(): void {
        if(!is_dir($this->getDataFolder())) {
            @mkdir($this->getDataFolder());
        }

        $this->saveResource("config.yml");
        $this->saveResource("groups.yml");

        $this->cfg = new Config($this->getDataFolder() . "config.yml", Config::YAML);
        $this->groupsCfg = new Config($this->getDataFolder() . "groups.yml", Config::YAML);
        $this->playersCfg = new Config($this->getDataFolder() . "players.yml", Config::YAML);
        $this->prefixCfg = new Config($this->getDataFolder() . "prefixes.yml", Config::YAML);

        $this->getServer()->getPluginManager()->registerEvents($this, $this);
    }

    public function onDisable(): void {
        if(isset($this->playersCfg)) {
            $this->playersCfg->save();
        }
        if(isset($this->prefixCfg)) {
            $this->prefixCfg->save();
        }
    }

    public function setOrgTag(string $nickname, string $tag): void {
        $this->orgTags[strtolower($nickname)] = $tag;
        $player = $this->getServer()->getPlayerExact($nickname);
        if ($player !== null) {
            $this->updateNametag($player);
        }
    }

    public function getOrgTag(string $nickname): string {
        $lower = strtolower($nickname);
        
        if (isset($this->orgTags[$lower])) {
            return $this->orgTags[$lower];
        }

        $doxc = $this->getServer()->getPluginManager()->getPlugin("RcDoxc");
        if ($doxc !== null && $doxc->isEnabled()) {
            $hasPassport = $doxc->getDataManager()->getData($nickname, 'passport');
            
            if ($hasPassport !== null) {
                return "(Гражданин)";
            }
        }

        return "(Эмигрант)";
    }

    public function getGroup(string $nickname): string {
        $nickname = strtolower($nickname);
        return $this->playersCfg->get($nickname, $this->cfg->get("default-group", "Игрок"));
    }

    public function setGroup(string $nickname, string $groupName): void {
        $nickname = strtolower($nickname);
        $defaultGroup = $this->cfg->get("default-group", "Игрок");

        if ($groupName === $defaultGroup) {
            $this->playersCfg->remove($nickname);
        } else {
            $this->playersCfg->set($nickname, $groupName);
        }
        $this->playersCfg->save();

        $player = $this->getServer()->getPlayerExact($nickname);
        if ($player !== null) {
            $this->updatePermissions($player);
            $this->updateNametag($player);
            $player->sendMessage(C::GREEN . "Ваша группа была изменена на: " . C::YELLOW . $groupName);
        }
    }

    public function getReputation(string $groupName): int {
        return (int)$this->groupsCfg->getNested("groups.$groupName.reputation", 0);
    }

    public function getPrefix(string $nickname): string {
        return (string)$this->prefixCfg->get(strtolower($nickname), "");
    }

    public function setPrefix(string $nickname, ?string $prefix): void {
        $nickname = strtolower($nickname);
        if ($prefix === null) {
            $this->prefixCfg->remove($nickname);
        } else {
            $this->prefixCfg->set($nickname, $prefix);
        }
        $this->prefixCfg->save();

        $player = $this->getServer()->getPlayerExact($nickname);
        if ($player !== null) {
            $this->updateNametag($player);
            $player->sendMessage(C::GREEN . "Ваш префикс обновлен.");
        }
    }

    private function updatePermissions(Player $player): void {
        $uuid = $player->getUniqueId()->toString();
        $group = $this->getGroup($player->getName());
        
        if (isset($this->attachments[$uuid])) {
            $player->removeAttachment($this->attachments[$uuid]);
            unset($this->attachments[$uuid]);
        }

        $perms = $this->groupsCfg->getNested("groups.$group.permissions", []);
        if (empty($perms)) return;

        $attachment = $player->addAttachment($this);
        $this->attachments[$uuid] = $attachment;

        foreach ($perms as $perm) {
            $attachment->setPermission(trim((string)$perm), true);
        }
        $player->recalculatePermissions();
    }

    private function getDisplayName(Player $player): string {
        $rcRazv = $this->getServer()->getPluginManager()->getPlugin("RcRazv");
        if ($rcRazv !== null && $rcRazv->isEnabled()) {
            $fakeName = $rcRazv->getFakeName($player->getName());
            if ($fakeName !== null) {
                return $fakeName;
            }
        }
        return $player->getName();
    }

    private function getDisplayGroup(Player $player): string {
        $rcRazv = $this->getServer()->getPluginManager()->getPlugin("RcRazv");
        if ($rcRazv !== null && $rcRazv->isEnabled()) {
            $fakeGroup = $rcRazv->getFakeGroup($player->getName());
            if ($fakeGroup !== null) {
                return $fakeGroup;
            }
        }
        return $this->getGroup($player->getName());
    }

    public function updateNametag(Player $player): void {
        $displayName = $this->getDisplayName($player);
        $displayGroup = $this->getDisplayGroup($player);
        
        $format = $this->groupsCfg->getNested("groups.$displayGroup.nametag", "$displayGroup\n{rctagorg} {rcprefix} {rcnick}");
        
        $prefix = $this->getPrefix($player->getName());
        $orgTag = $this->getOrgTag($player->getName());

        $tag = str_replace(
            ["{rcprefix}", "{rcnick}", "{rctagorg}"], 
            [$prefix, $displayName, $orgTag],
            $format
        );
        
        $tag = str_replace('\n', "\n", $tag);
        $tag = str_replace("  ", " ", $tag);
        
        $player->setNameTag($tag);
        $player->setDisplayName($displayName);
    }

    public function onJoin(PlayerJoinEvent $event): void {
        $player = $event->getPlayer();
        $this->updatePermissions($player);
        $this->updateNametag($player);
    }

    public function onQuit(PlayerQuitEvent $event): void {
        $uuid = $event->getPlayer()->getUniqueId()->toString();
        if (isset($this->attachments[$uuid])) {
            unset($this->attachments[$uuid]);
        }
        unset($this->orgTags[strtolower($event->getPlayer()->getName())]);
    }

    public function onChat(PlayerChatEvent $event): void {
        $player = $event->getPlayer();
        
        $displayName = $this->getDisplayName($player);
        $displayGroup = $this->getDisplayGroup($player);
        
        $format = $this->groupsCfg->getNested("groups.$displayGroup.chat", "{rctagorg} {rcnick} > {rcmsg}");
        
        $prefix = $this->getPrefix($player->getName());
        $orgTag = $this->getOrgTag($player->getName());
        
        $msg = $event->getMessage();
        if ($player->hasPermission("rcgroup.chat.color")) {
            $msg = C::colorize($msg);
        }

        $finalMsg = str_replace(
            ["{rcprefix}", "{rcnick}", "{rcmsg}", "{rctagorg}"], 
            [$prefix, $displayName, $msg, $orgTag],
            $format
        );
        $finalMsg = str_replace("  ", " ", $finalMsg);

        $event->setFormatter(new \pocketmine\player\chat\LegacyRawChatFormatter($finalMsg));
    }

    private function canInteract(CommandSender $sender, string $targetNick, ?string $newGroup = null): bool {
        if (!($sender instanceof Player)) return true;
        
        $sRep = $this->getReputation($this->getGroup($sender->getName()));
        $tRep = $this->getReputation($this->getGroup($targetNick));

        if ($tRep >= $sRep) {
            $sender->sendMessage(C::RED . "Вы не можете управлять игроком с рангом выше или равным вашему.");
            return false;
        }
        if ($newGroup !== null && $this->getReputation($newGroup) >= $sRep) {
            $sender->sendMessage(C::RED . "Вы не можете выдать ранг, который выше или равен вашему.");
            return false;
        }
        return true;
    }

    public function onCommand(CommandSender $sender, Command $cmd, string $label, array $args): bool {
        
        if ($cmd->getName() === "rcdefg") {
            if (!isset($args[0])) {
                $sender->sendMessage(C::RED . "Использование: /rcdefg <группа>");
                return true;
            }
            $this->groupsCfg->reload();
            if ($this->groupsCfg->getNested("groups." . $args[0]) === null) {
                $sender->sendMessage(C::RED . "Группа '{$args[0]}' не найдена в конфиге.");
                return true;
            }
            $this->cfg->reload();
            $this->cfg->set("default-group", $args[0]);
            $this->cfg->save();
            $sender->sendMessage(C::GREEN . "Группа по умолчанию установлена: " . C::YELLOW . $args[0]);
            return true;
        }

        if ($cmd->getName() === "rcnewg") {
            if (count($args) < 1) {
                $sender->sendMessage(C::YELLOW . "Использование: /rcnewg <Название1> <Название2>...");
                return true;
            }
            
            $this->groupsCfg->reload(); 
            $added = [];
            foreach ($args as $name) {
                if ($this->groupsCfg->getNested("groups.$name") !== null) continue;
                
                $this->groupsCfg->setNested("groups.$name", [
                    "reputation" => 1,
                    "permissions" => [],
                    "chat" => "{rctagorg} [$name] {rcnick} > {rcmsg}",
                    "nametag" => "$name\n{rctagorg} {rcprefix} {rcnick}"
                ]);
                $added[] = $name;
            }
            $this->groupsCfg->save();
            
            if (count($added) > 0) {
                $sender->sendMessage(C::GREEN . "Успешно созданы группы: " . C::RESET . implode(", ", $added));
            } else {
                $sender->sendMessage(C::RED . "Указанные группы уже существуют.");
            }
            return true;
        }

        if ($cmd->getName() === "rcremg") {
            if (count($args) < 1) {
                $sender->sendMessage(C::YELLOW . "Использование: /rcremg <Название1>...");
                return true;
            }
            $this->groupsCfg->reload();
            $removed = [];
            $allGroups = $this->groupsCfg->get("groups", []);
            foreach ($args as $name) {
                if (isset($allGroups[$name])) {
                    unset($allGroups[$name]);
                    $removed[] = $name;
                }
            }
            $this->groupsCfg->set("groups", $allGroups);
            $this->groupsCfg->save();
            if (count($removed) > 0) {
                $sender->sendMessage(C::RED . "Удалены группы: " . C::RESET . implode(", ", $removed));
            } else {
                $sender->sendMessage(C::YELLOW . "Ничего не удалено (группы не найдены).");
            }
            return true;
        }

        if ($cmd->getName() === "rcsetg") {
            if (count($args) < 1) {
                $sender->sendMessage(C::YELLOW . "Использование: /rcsetg <ник> <группа>");
                return false;
            }
            $target = (count($args) === 1 && $sender instanceof Player) ? $sender->getName() : $args[0];
            $group = (count($args) === 1) ? $args[0] : $args[1];

            if ($this->groupsCfg->getNested("groups.$group") === null) {
                $sender->sendMessage(C::RED . "Группа '$group' не найдена.");
                return true;
            }
            if (!$this->canInteract($sender, $target, $group)) return true;

            if ($this->getGroup($target) === $group) {
                $def = $this->cfg->get("default-group", "Игрок");
                $this->setGroup($target, $def);
                $sender->sendMessage(C::YELLOW . "Группа игрока сброшена на стандартную.");
            } else {
                $this->setGroup($target, $group);
                $sender->sendMessage(C::GREEN . "Игроку $target выдана группа: " . C::YELLOW . $group);
            }
            return true;
        }

        if ($cmd->getName() === "rclistg") {
            $groups = $this->groupsCfg->get("groups", []);
            $list = array_keys($groups);
            $sender->sendMessage(C::AQUA . "Список доступных групп: " . C::RESET . implode(", ", $list));
            return true;
        }

        if ($cmd->getName() === "rcprefix") {
            if (count($args) < 1) {
                $sender->sendMessage(C::YELLOW . "Использование: /rcprefix add <текст> | /rcprefix remove");
                return true;
            }
            $action = strtolower(array_shift($args));
            
            if ($action === "remove") {
                $this->setPrefix($sender->getName(), null);
                $sender->sendMessage(C::RED . "Ваш личный префикс удален.");
            } elseif ($action === "add") {
                $text = implode(" ", $args);
                $this->setPrefix($sender->getName(), $text);
            }
            return true;
        }

        if ($cmd->getName() === "rcclearg") {
            $target = $args[0] ?? $sender->getName();
            if (!$this->canInteract($sender, $target)) return true;
            
            $def = $this->cfg->get("default-group", "Игрок");
            $this->setGroup($target, $def);
            $sender->sendMessage(C::GREEN . "Привилегии игрока $target сброшены.");
            return true;
        }

        if ($cmd->getName() === "rcpovisg" || $cmd->getName() === "rcponijg") {
            if (!isset($args[0])) {
                $sender->sendMessage(C::RED . "Укажите ник игрока.");
                return true;
            }
            $target = $args[0];
            
            $all = $this->groupsCfg->get("groups", []);
            uasort($all, fn($a, $b) => ($a['reputation'] ?? 0) <=> ($b['reputation'] ?? 0));
            $keys = array_keys($all);
            
            $current = $this->getGroup($target);
            $idx = array_search($current, $keys);
            if ($idx === false) $idx = 0;

            $newIdx = ($cmd->getName() === "rcpovisg") ? $idx + 1 : $idx - 1;

            if (!isset($keys[$newIdx])) {
                $sender->sendMessage(C::RED . "Достигнут предел рангов (некуда повышать/понижать).");
                return true;
            }
            
            $newGroup = $keys[$newIdx];
            if (!$this->canInteract($sender, $target, $newGroup)) return true;

            $this->setGroup($target, $newGroup);
            $act = ($cmd->getName() === "rcpovisg") ? "повышен" : "понижен";
            $sender->sendMessage(C::GREEN . "Игрок $target успешно $act до группы: $newGroup");
            return true;
        }

        return true;
    }
}
