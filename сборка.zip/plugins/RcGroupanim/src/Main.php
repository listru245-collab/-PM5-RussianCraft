<?php

declare(strict_types=1);

namespace InzeOwr\RcGroupanim;

use pocketmine\plugin\PluginBase;
use pocketmine\scheduler\Task;
use pocketmine\utils\Config;
use InzeOwr\RcGroup\Main as RcGroupMain;

class Main extends PluginBase {

    public Config $cfg;
    public int $animTick = 0;
    private ?RcGroupMain $rcGroup = null;

    public function onEnable(): void {
        $this->saveResource("config.yml");
        $this->cfg = new Config($this->getDataFolder() . "config.yml", Config::YAML);

        $plugin = $this->getServer()->getPluginManager()->getPlugin("RcGroup");
        
        if($plugin instanceof RcGroupMain && $plugin->isEnabled()){
            $this->rcGroup = $plugin;
        } else {
            $this->getLogger()->error("Плагин RcGroup не найден или выключен!");
            $this->getServer()->getPluginManager()->disablePlugin($this);
            return;
        }

        $period = (int)$this->cfg->get("period", 10);
        
        $this->getScheduler()->scheduleRepeatingTask(new AnimTask($this, $this->rcGroup), $period);
    }
}

class AnimTask extends Task {

    private Main $plugin;
    private RcGroupMain $rcGroup;
    private Config $groupsCfg;

    public function __construct(Main $plugin, RcGroupMain $rcGroup){
        $this->plugin = $plugin;
        $this->rcGroup = $rcGroup;
        $this->groupsCfg = $rcGroup->groupsCfg;
    }

    public function onRun(): void {
        $this->plugin->animTick++;

        $rcRazv = $this->plugin->getServer()->getPluginManager()->getPlugin("RcRazv");
        $razvEnabled = ($rcRazv !== null && $rcRazv->isEnabled());

        foreach($this->plugin->getServer()->getOnlinePlayers() as $player){
            if(!$player->spawned) continue;

            $nick = $player->getName();

            // Проверяем скрыт ли ник
            if ($razvEnabled && $rcRazv->isNameHidden($nick)) {
                // Если ник скрыт - ставим пустой тег и пропускаем
                if ($player->getNameTag() !== "") {
                    $player->setNameTag("");
                    $player->setNameTagVisible(false);
                    $player->setNameTagAlwaysVisible(false);
                }
                continue;
            }

            // Проверяем фейковые данные
            $displayNick = $nick;
            $group = $this->rcGroup->getGroup($nick);
            $displayGroup = $group;

            if ($razvEnabled) {
                $fakeName = $rcRazv->getFakeName($nick);
                if ($fakeName !== null) {
                    $displayNick = $fakeName;
                }

                $fakeGroup = $rcRazv->getFakeGroup($nick);
                if ($fakeGroup !== null) {
                    $displayGroup = $fakeGroup;
                }
            }

            $format = $this->groupsCfg->getNested("groups.$displayGroup.nametag", "$displayGroup\n{rctagorg} {rcprefix} {rcnick}");

            if(strpos($format, "{rcgroupanim}") === false) continue;

            $frames = $this->plugin->cfg->getNested("animations.$displayGroup", []);
            
            if(empty($frames)){
                $animText = $displayGroup; 
            } else {
                $count = count($frames);
                $animText = $frames[$this->plugin->animTick % $count];
            }

            $prefix = $this->rcGroup->getPrefix($nick);
            $orgTag = $this->rcGroup->getOrgTag($nick);

            $tag = str_replace(
                ["{rcprefix}", "{rcnick}", "{rctagorg}", "{rcgroupanim}"],
                [$prefix, $displayNick, $orgTag, $animText],
                $format
            );

            $tag = str_replace(['\n', "  "], ["\n", " "], $tag);

            if($player->getNameTag() !== $tag){
                $player->setNameTag($tag);
            }
        }
    }
}