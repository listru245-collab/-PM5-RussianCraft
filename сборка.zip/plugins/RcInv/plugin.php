name: RcInv
main: InzeOwr\RcInv\Main
version: 1.0.0
api: 5.0.0
src-namespace-prefix: InzeOwr\RcInv
author: InzeOwr
description: Система управления инвентарём для PocketMine-MP
depend:
  - RcGroup
commands:
  rcinvsee:
    description: "Просмотреть инвентарь игрока"
    usage: "/rcinvsee <ник>"
    permission: rcinv.see
  rccrinv:
    description: "Очистить инвентарь игрока"
    usage: "/rccrinv <ник> <причина>"
    permission: rcinv.clear
permissions:
  rcinv.see:
    default: op
  rcinv.clear:
    default: op
  rcinv.bypass:
    description: "Защита от очистки инвентаря"
    default: false
