<?php

declare(strict_types=1);

namespace InzeOwr\RcJob;

use pocketmine\player\Player;
use jojoe77777\FormAPI\SimpleForm;
use jojoe77777\FormAPI\ModalForm;
use jojoe77777\FormAPI\CustomForm;

class FormManager {

    private Main $plugin;

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
    }

    private function createXpBar(int $current, int $max, int $length = 20): string {
        if($max <= 0) return "§a" . str_repeat("|", $length);
        $filled = (int)(($current / $max) * $length);
        $filled = min($filled, $length);
        $empty = $length - $filled;
        $percent = round(($current / $max) * 100);
        return "§a" . str_repeat("|", $filled) . "§7" . str_repeat("|", $empty) . " §e{$percent}%";
    }

    public function openJobMenu(Player $player, int $jobId): void {
        $name = $player->getName();
        $jobName = Main::JOB_NAMES[$jobId] ?? "Подработка";

        $skillLevel = $this->plugin->getSkillLevel($name, $jobId);
        $skillXp = $this->plugin->getSkillXp($name, $jobId);
        $totalEarned = $this->plugin->getTotalEarned($name, $jobId);
        $cooldownRemaining = $this->plugin->getCooldownRemaining($name, $jobId);
        $blocksToday = $this->plugin->getBlocksToday($name, $jobId);
        $isWorking = $this->plugin->isWorking($name);
        $workerData = $this->plugin->getWorkerData($name);

        $xpForNext = $this->plugin->getXpForNextLevel($skillLevel);
        $payRange = $this->plugin->getPayRange($jobId, $skillLevel);

        $content = "";
        $content .= "§e§l───────────────\n";
        $content .= "§bИнформация\n";
        $content .= "§e§l───────────────\n\n";

        $content .= "§eОплата: §a{$payRange[0]} - {$payRange[1]} руб.\n";

        if($this->plugin->isBoostActive() && $skillLevel < 5) {
            $content .= "§cБуст: x" . $this->plugin->getBoostMultiplier() . "\n";
        }

        $content .= "§eУровень: §b{$skillLevel}§7/§b5\n";

        if($skillLevel < 5) {
            $content .= "§eОпыт: §a{$skillXp}§7/§a{$xpForNext}\n";
            $content .= $this->createXpBar($skillXp, $xpForNext) . "\n";
        } else {
            $content .= "§6Максимальный уровень!\n";
        }

        $content .= "\n§eСегодня: §b{$blocksToday}§7/§b1000\n";
        $content .= "§eВсего заработано: §a" . round($totalEarned, 2) . " руб.\n";

        if($cooldownRemaining > 0) {
            $hours = intdiv($cooldownRemaining, 3600);
            $minutes = intdiv($cooldownRemaining % 3600, 60);
            $content .= "\n§cЛимит исчерпан!\n";
            $content .= "§eЧерез: §b{$hours}ч {$minutes}мин\n";
        }

        if($isWorking && $workerData !== null && $workerData["job"] === $jobId) {
            $workTime = time() - $workerData["startTime"];
            $wMin = intdiv($workTime, 60);
            $wSec = $workTime % 60;
            $content .= "\n§e§l───────────────\n";
            $content .= "§aТекущая смена\n";
            $content .= "§e§l───────────────\n\n";
            $content .= "§eВремя: §b{$wMin} мин. {$wSec} сек.\n";
            $content .= "§eЗа смену: §a" . round($workerData["earned"], 2) . " руб.\n";
            $content .= "§eДействий: §b" . $workerData["blocksBroken"] . "\n";
        }

        $content .= "\n§7Нажмите кнопку ниже\n";

        $form = new SimpleForm(function(Player $player, ?int $data) use ($jobId, $isWorking, $workerData, $cooldownRemaining): void {
            if($data === null) return;
            $name = $player->getName();

            if($isWorking && $workerData !== null && $workerData["job"] === $jobId) {
                if($data === 0) {
                    $this->plugin->endWork($name);
                }
            } else {
                if($data === 0) {
                    if($cooldownRemaining > 0) {
                        $player->sendMessage("§c§l[RcJob] §eЛимит исчерпан!");
                        return;
                    }
                    if($this->plugin->isWorking($name)) {
                        $player->sendMessage("§c§l[RcJob] §eВы уже работаете!");
                        return;
                    }
                    $this->plugin->startWork($player, $jobId);
                }
            }
        });

        $form->setTitle("§l§b$jobName");
        $form->setContent($content);

        if($isWorking && $workerData !== null && $workerData["job"] === $jobId) {
            $form->addButton("§l§cУволиться");
        } else {
            if($cooldownRemaining > 0) {
                $form->addButton("§l§8Лимит исчерпан");
            } else {
                $form->addButton("§l§aУстроиться");
            }
        }

        $player->sendForm($form);
    }

    public function openComputerDiagnoseForm(Player $player, int $npcId, array $problem): void {
        $form = new SimpleForm(function(Player $player, ?int $data) use ($npcId, $problem): void {
            if($data === null) return;

            if($data === 0) {
                $this->plugin->setComputerNpcState($player->getName(), $npcId, [
                    "problem" => $problem,
                    "stage" => "tool_check"
                ]);
                $toolName = Main::TOOL_NAMES[$problem["tool"]] ?? "инструмент";
                $player->sendMessage("§a§l[RcJob] §eВозьмите $toolName §eв руку и нажмите на клиента.");
            }
        });

        $form->setTitle("§l§bКомпьютерный Мастер");

        $content = "";
        $content .= "§e§l───────────────\n";
        $content .= "§cЖалоба клиента\n";
        $content .= "§e§l───────────────\n\n";
        $content .= $problem["text"] . "\n\n";
        $content .= "§e§l───────────────\n";
        $content .= "§bИнструменты\n";
        $content .= "§e§l───────────────\n\n";
        $content .= "§eОтвёртка §7- разборка корпуса\n";
        $content .= "§eФонарик §7- осмотр в темноте\n";
        $content .= "§eПаяльник §7- пайка контактов\n";
        $content .= "§eКабель §7- проверка соединений\n\n";
        $content .= "§7Прочитайте жалобу и выберите инструмент.\n";

        $form->setContent($content);
        $form->addButton("§l§aПринять заказ");

        $player->sendForm($form);
    }

    public function openComputerRepairForm(Player $player, int $npcId, array $problem): void {
        $parts = Main::COMPUTER_PARTS;
        shuffle($parts);

        $correctPart = $problem["part"];
        $correctIndex = -1;

        $buttons = [];
        foreach($parts as $i => $part) {
            if($part === $correctPart) $correctIndex = $i;
            $buttons[] = $part;
        }

        $form = new SimpleForm(function(Player $player, ?int $data) use ($npcId, $correctIndex): void {
            if($data === null) {
                $this->plugin->clearComputerNpcState($player->getName(), $npcId);
                return;
            }

            $name = $player->getName();

            if($data === $correctIndex) {
                $skillLevel = $this->plugin->getSkillLevel($name, 2);
                $pay = $this->plugin->calculatePay(2, $skillLevel);
                $this->plugin->addEarnings($name, 2, $pay);
                $this->plugin->clearComputerNpcState($name, $npcId);

                $player->sendMessage("§a§l[RcJob] §eКомпьютер починен! §a+{$pay} руб.");
                $this->plugin->sendJobTip($player);
            } else {
                $this->plugin->clearComputerNpcState($name, $npcId);
                $player->sendMessage("§c§l[RcJob] §eНе та деталь! Клиент недоволен.");
            }
        });

        $form->setTitle("§l§bПочинка компьютера");

        $content = "";
        $content .= "§e§l───────────────\n";
        $content .= "§bВыбор детали\n";
        $content .= "§e§l───────────────\n\n";
        $content .= "§eВыберите сломанную деталь.\n\n";
        $content .= "§7Вспомните жалобу клиента.\n";

        $form->setContent($content);

        foreach($buttons as $btn) {
            $form->addButton("§e$btn");
        }

        $player->sendForm($form);
    }

    public function openLumberjackSellForm(Player $player): void {
        $name = $player->getName();
        $logs = $this->plugin->countLogsInInventory($player);
        $skillLevel = $this->plugin->getSkillLevel($name, 3);
        $payRange = $this->plugin->getPayRange(3, $skillLevel);

        $avgPay = round(($payRange[0] + $payRange[1]) / 2, 2);
        $totalPay = round($avgPay * $logs, 2);

        $content = "";
        $content .= "§e§l───────────────\n";
        $content .= "§bСкупка древесины\n";
        $content .= "§e§l───────────────\n\n";
        $content .= "§eБрёвен: §b{$logs} шт.\n";
        $content .= "§eЦена: §a{$payRange[0]} - {$payRange[1]} руб.\n";
        $content .= "§eУровень: §b{$skillLevel}§7/§b5\n\n";

        if($logs > 0) {
            $content .= "§eПримерно: §a~{$totalPay} руб.\n\n";
            $content .= "§7Сумма зависит от случайной цены.\n";
        } else {
            $content .= "§cНет брёвен для продажи.\n\n";
            $content .= "§7Нарубите деревья в зоне.\n";
        }

        $form = new SimpleForm(function(Player $player, ?int $data) use ($logs): void {
            if($data === null) return;

            if($data === 0 && $logs > 0) {
                $name = $player->getName();

                if(!$this->plugin->isWorking($name) || $this->plugin->getWorkerJob($name) !== 3) return;

                $actualLogs = $this->plugin->removeAllLogs($player);
                if($actualLogs <= 0) return;

                $skillLevel = $this->plugin->getSkillLevel($name, 3);
                $totalPay = 0.0;

                for($i = 0; $i < $actualLogs; $i++) {
                    $pay = $this->plugin->calculatePay(3, $skillLevel);
                    $totalPay += $pay;
                }

                $totalPay = round($totalPay, 2);
                $this->plugin->addLogEarnings($name, $actualLogs, $totalPay);

                $player->sendMessage("§a§l[RcJob] §eПродано §b{$actualLogs} брёвен §eза §a{$totalPay} руб.");
                $this->plugin->sendJobTip($player);
            }
        });

        $form->setTitle("§l§bДровосек");
        $form->setContent($content);

        if($logs > 0) {
            $form->addButton("§l§aПродать ({$logs} шт.)");
        } else {
            $form->addButton("§l§8Нет брёвен");
        }

        $player->sendForm($form);
    }

    public function openLevelUpForm(Player $player, int $jobId, int $newLevel): void {
        $jobName = Main::JOB_NAMES[$jobId] ?? "Подработка";
        $payRange = $this->plugin->getPayRange($jobId, $newLevel);

        $form = new ModalForm(function(Player $player, ?bool $data): void {});

        $form->setTitle("§l§aПовышение!");

        $content = "";
        $content .= "§e§l───────────────\n";
        $content .= "§aПоздравляем!\n";
        $content .= "§e§l───────────────\n\n";
        $content .= "§eПодработка: §b{$jobName}\n";
        $content .= "§eНовый уровень: §a{$newLevel}§7/§a5\n";
        $content .= "§eОплата: §a{$payRange[0]} - {$payRange[1]} руб.\n\n";
        $content .= "§7Продолжайте работать!\n";

        $form->setContent($content);
        $form->setButton1("§l§aОтлично!");
        $form->setButton2("§l§7Закрыть");

        $player->sendForm($form);
    }

    public function openCaptchaForm(Player $player, string $question, int $answer): void {
        $form = new CustomForm(function(Player $player, ?array $data) use ($answer): void {
            $name = $player->getName();
            $this->plugin->removePendingCaptcha($name);

            if($data === null) {
                $player->kick("§c§l[RcJob] §eПроверка не пройдена!");
                return;
            }

            $playerAnswer = trim((string)($data[1] ?? ""));

            if($playerAnswer === "" || (int)$playerAnswer !== $answer) {
                $player->kick("§c§l[RcJob] §eНеправильный ответ!");
                return;
            }

            $player->sendMessage("§a§l[RcJob] §eПроверка пройдена!");
        });

        $form->setTitle("§l§cПроверка");
        $form->addLabel("§eРешите пример:\n\n§b§l{$question} = ?\n\n§7У вас 60 секунд.");
        $form->addInput("§eВаш ответ:", "Введите число");

        $player->sendForm($form);
    }

    public function openStatsForm(Player $viewer, string $targetName): void {
        $content = "";
        $content .= "§e§l───────────────\n";
        $content .= "§bСтатистика: §e{$targetName}\n";
        $content .= "§e§l───────────────\n\n";

        $totalAllEarned = 0.0;
        $totalAllBlocks = 0;

        for($jId = 1; $jId <= 4; $jId++) {
            $jName = Main::JOB_NAMES[$jId] ?? "Подработка";
            $jLevel = $this->plugin->getSkillLevel($targetName, $jId);
            $jXp = $this->plugin->getSkillXp($targetName, $jId);
            $jEarned = $this->plugin->getTotalEarned($targetName, $jId);
            $pData = $this->plugin->getPlayerData($targetName);
            $jBlocks = $pData["job_{$jId}_total_blocks"] ?? 0;

            $totalAllEarned += $jEarned;
            $totalAllBlocks += $jBlocks;

            $content .= "§b{$jName}\n";
            $content .= "§eУровень: §a{$jLevel}§7/§a5 §e| XP: §a{$jXp}\n";
            $content .= "§eЗаработано: §a" . round($jEarned, 2) . " руб.\n";
            $content .= "§eДействий: §b{$jBlocks}\n\n";
        }

        $content .= "§e§l───────────────\n";
        $content .= "§6Итого\n";
        $content .= "§e§l───────────────\n\n";
        $content .= "§eОбщий заработок: §a" . round($totalAllEarned, 2) . " руб.\n";
        $content .= "§eВсего действий: §b{$totalAllBlocks}\n";

        $isOnline = $this->plugin->getServer()->getPlayerExact($targetName) !== null;
        $isWorking = $this->plugin->isWorking($targetName);

        $content .= "\n§eСтатус: ";
        if($isWorking) {
            $jobId = $this->plugin->getWorkerJob($targetName);
            $jobName = Main::JOB_NAMES[$jobId] ?? "Подработка";
            $content .= "§aРаботает (§b{$jobName}§a)\n";
        } elseif($isOnline) {
            $content .= "§eОнлайн\n";
        } else {
            $content .= "§7Оффлайн\n";
        }

        $form = new SimpleForm(function(Player $player, ?int $data): void {});

        $form->setTitle("§l§bСтатистика");
        $form->setContent($content);
        $form->addButton("§l§7Закрыть");

        $viewer->sendForm($form);
    }
}