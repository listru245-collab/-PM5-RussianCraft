<?php
declare(strict_types=1);

namespace InzeOwr\RcJob;

use pocketmine\entity\Human;
use pocketmine\entity\Skin;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\player\Player;
use pocketmine\math\Vector3;
use pocketmine\world\World;
use pocketmine\entity\EntityDataHelper;
use pocketmine\entity\EntityFactory;

class JobNPC extends Human {

    private int $jobId = 1;
    private static ?Main $plugin = null;

    public static function register(Main $plugin): void {
        self::$plugin = $plugin;
        EntityFactory::getInstance()->register(JobNPC::class, function(World $world, CompoundTag $nbt): JobNPC {
            return new JobNPC(
                EntityDataHelper::parseLocation($nbt, $world),
                self::createDefaultSkin(),
                $nbt
            );
        }, ["RcJobNPC", "rcjob:npc"]);
    }

    protected function initEntity(CompoundTag $nbt): void {
        parent::initEntity($nbt);
        $this->jobId = $nbt->getInt("JobId", 1);
        $jobNames = Main::JOB_NAMES;
        $name = $jobNames[$this->jobId] ?? "Работодатель";
        $this->setNameTag("§l§f$name\n§l§7Подработка");
        $this->setNameTagAlwaysVisible(true);
        $this->setNameTagVisible(true);
        $this->setNoClientPredictions(true);
    }

    public function saveNBT(): CompoundTag {
        $nbt = parent::saveNBT();
        $nbt->setInt("JobId", $this->jobId);
        return $nbt;
    }

    public function getJobId(): int {
        return $this->jobId;
    }

    public function attack(EntityDamageEvent $source): void {
        $source->cancel();
        if($source instanceof EntityDamageByEntityEvent) {
            $damager = $source->getDamager();
            if($damager instanceof Player && self::$plugin !== null) {
                self::$plugin->getFormManager()->openJobMenu($damager, $this->jobId);
            }
        }
    }

    public function onInteract(Player $player, Vector3 $clickPos): bool {
        if(self::$plugin !== null) {
            self::$plugin->getFormManager()->openJobMenu($player, $this->jobId);
        }
        return true;
    }

    public static function createDefaultSkin(): Skin {
        $skinData = str_repeat("\x00", 64 * 64 * 4);
        for($y = 0; $y < 64; $y++) {
            for($x = 0; $x < 64; $x++) {
                $offset = ($y * 64 + $x) * 4;
                $r = 80; $g = 80; $b = 80; $a = 255;
                if($y < 16 && $x < 16) {
                    $r = 210; $g = 170; $b = 130;
                }
                if($y >= 20 && $y < 32 && $x >= 20 && $x < 28) {
                    $r = 40; $g = 40; $b = 120;
                }
                $skinData[$offset] = chr($r);
                $skinData[$offset + 1] = chr($g);
                $skinData[$offset + 2] = chr($b);
                $skinData[$offset + 3] = chr($a);
            }
        }
        return new Skin("RcJobNPC", $skinData, "", "geometry.humanoid.custom", "");
    }

    public function knockBack(float $x, float $z, float $force = 0.4, ?float $verticalLimit = 0.4): void {}

    protected function entityBaseTick(int $tickDiff = 1): bool {
        $this->motion = Vector3::zero();
        return parent::entityBaseTick($tickDiff);
    }
}