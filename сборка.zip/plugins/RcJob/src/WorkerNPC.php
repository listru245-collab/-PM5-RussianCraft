<?php
declare(strict_types=1);

namespace InzeOwr\RcJob;

use pocketmine\entity\Human;
use pocketmine\entity\Skin;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\player\Player;
use pocketmine\math\Vector3;
use pocketmine\world\World;
use pocketmine\entity\EntityDataHelper;
use pocketmine\entity\EntityFactory;

class WorkerNPC extends Human {

    private int $jobId = 2;
    private int $workerNpcId = 0;
    private static ?Main $plugin = null;

    public static function register(Main $plugin): void {
        self::$plugin = $plugin;
        EntityFactory::getInstance()->register(WorkerNPC::class, function(World $world, CompoundTag $nbt): WorkerNPC {
            return new WorkerNPC(
                EntityDataHelper::parseLocation($nbt, $world),
                self::createDefaultSkin(),
                $nbt
            );
        }, ["RcWorkerNPC", "rcjob:worker_npc"]);
    }

    protected function initEntity(CompoundTag $nbt): void {
        parent::initEntity($nbt);
        $this->jobId = $nbt->getInt("JobId", 2);
        $this->workerNpcId = $nbt->getInt("WorkerNpcId", 0);

        $names = [
            2 => "§l§fКлиент\n§l§7Компьютерный сервис",
            3 => "§l§fСкупщик\n§l§7Покупка древесины",
            4 => "§l§fЗаказчик\n§l§7Склад посылок"
        ];
        $this->setNameTag($names[$this->jobId] ?? "§l§fРабочий");
        $this->setNameTagAlwaysVisible(true);
        $this->setNameTagVisible(true);
        $this->setNoClientPredictions(true);
    }

    public function saveNBT(): CompoundTag {
        $nbt = parent::saveNBT();
        $nbt->setInt("JobId", $this->jobId);
        $nbt->setInt("WorkerNpcId", $this->workerNpcId);
        return $nbt;
    }

    public function getJobId(): int {
        return $this->jobId;
    }

    public function getWorkerNpcId(): int {
        return $this->workerNpcId;
    }

    public function attack(EntityDamageEvent $source): void {
        $source->cancel();
        if($source instanceof EntityDamageByEntityEvent) {
            $damager = $source->getDamager();
            if($damager instanceof Player && self::$plugin !== null) {
                $this->handleInteraction($damager);
            }
        }
    }

    public function onInteract(Player $player, Vector3 $clickPos): bool {
        if(self::$plugin !== null) {
            $this->handleInteraction($player);
        }
        return true;
    }

    private function handleInteraction(Player $player): void {
        $plugin = self::$plugin;
        if($plugin === null) return;

        $name = $player->getName();
        if(!$plugin->isWorking($name)) {
            $player->sendMessage("§c§l[RcJob] Вы не работаете! Устройтесь у работодателя.");
            return;
        }

        $workerJob = $plugin->getWorkerJob($name);
        if($workerJob !== $this->jobId) {
            $player->sendMessage("§c§l[RcJob] Это не ваша подработка!");
            return;
        }

        if(!$plugin->canDoMore($name)) {
            $player->sendMessage("§c§l[RcJob] Лимит на сегодня!");
            $plugin->endWork($name);
            return;
        }

        switch($this->jobId) {
            case 2:
                $state = $plugin->getComputerNpcState($name, $this->workerNpcId);
                if($state === null) {
                    $problem = Main::COMPUTER_PROBLEMS[array_rand(Main::COMPUTER_PROBLEMS)];
                    $plugin->setComputerNpcState($name, $this->workerNpcId, [
                        "problem" => $problem,
                        "stage" => "diagnose"
                    ]);
                    $plugin->getFormManager()->openComputerDiagnoseForm($player, $this->workerNpcId, $problem);
                } elseif($state["stage"] === "tool_check") {
                    $heldTool = $plugin->getHeldToolKey($player);
                    if($heldTool === null) {
                        $player->sendMessage("§c§l[RcJob] Возьмите нужный инструмент в руку!");
                        return;
                    }
                    $requiredTool = $state["problem"]["tool"];
                    if($heldTool !== $requiredTool) {
                        $player->sendMessage("§c§l[RcJob] Неправильный инструмент!");
                        $plugin->clearComputerNpcState($name, $this->workerNpcId);
                        return;
                    }
                    $plugin->setComputerNpcState($name, $this->workerNpcId, [
                        "problem" => $state["problem"],
                        "stage" => "repair"
                    ]);
                    $plugin->getFormManager()->openComputerRepairForm($player, $this->workerNpcId, $state["problem"]);
                } elseif($state["stage"] === "diagnose") {
                    $plugin->getFormManager()->openComputerDiagnoseForm($player, $this->workerNpcId, $state["problem"]);
                }
                break;

            case 3:
                $plugin->getFormManager()->openLumberjackSellForm($player);
                break;

            case 4:
                if($plugin->hasParcel($player)) {
                    $player->sendMessage("§c§l[RcJob] У вас уже есть посылка! Доставьте на подсвеченную бочку.");
                    return;
                }
                $barrels = $plugin->getBarrelsInZone(4);
                if(empty($barrels)) {
                    $player->sendMessage("§c§l[RcJob] Нет бочек в рабочей зоне!");
                    return;
                }
                $target = $barrels[array_rand($barrels)];
                $plugin->setWarehouseTarget($name, $target);
                $plugin->giveParcel($player);
                $player->sendMessage("§a§l[RcJob] §f§lВы получили посылку! Отнесите на подсвеченную бочку.");
                break;
        }
    }

    public static function createDefaultSkin(): Skin {
        $skinData = str_repeat("\x00", 64 * 64 * 4);
        for($y = 0; $y < 64; $y++) {
            for($x = 0; $x < 64; $x++) {
                $offset = ($y * 64 + $x) * 4;
                $r = 100; $g = 70; $b = 50; $a = 255;
                if($y < 16 && $x < 16) {
                    $r = 220; $g = 185; $b = 145;
                }
                if($y >= 20 && $y < 32 && $x >= 20 && $x < 28) {
                    $r = 60; $g = 120; $b = 60;
                }
                $skinData[$offset] = chr($r);
                $skinData[$offset + 1] = chr($g);
                $skinData[$offset + 2] = chr($b);
                $skinData[$offset + 3] = chr($a);
            }
        }
        return new Skin("RcWorkerNPC", $skinData, "", "geometry.humanoid.custom", "");
    }

    public function knockBack(float $x, float $z, float $force = 0.4, ?float $verticalLimit = 0.4): void {}

    protected function entityBaseTick(int $tickDiff = 1): bool {
        $this->motion = Vector3::zero();
        return parent::entityBaseTick($tickDiff);
    }
}