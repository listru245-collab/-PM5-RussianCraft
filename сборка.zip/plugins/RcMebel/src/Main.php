<?php

declare(strict_types=1);

namespace InzeOwr\RcMebel;

use pocketmine\plugin\PluginBase;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\event\Listener;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityMotionEvent;
use pocketmine\event\server\DataPacketReceiveEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\entity\EntitySizeInfo;
use pocketmine\entity\EntityFactory;
use pocketmine\entity\Location;
use pocketmine\entity\Skin;
use pocketmine\entity\Human;
use pocketmine\entity\EntityDataHelper;
use pocketmine\math\Vector3;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\nbt\tag\DoubleTag;
use pocketmine\nbt\tag\FloatTag;
use pocketmine\nbt\tag\ListTag;
use pocketmine\world\World;
use pocketmine\network\mcpe\protocol\InteractPacket;
use pocketmine\network\mcpe\protocol\SetActorLinkPacket;
use pocketmine\network\mcpe\protocol\types\entity\EntityLink;
use pocketmine\scheduler\ClosureTask;

class BenchEntity extends Human {

    private string $benchId = "";

    public static function getNetworkTypeId(): string {
        return "rcmebel:bench";
    }

    protected function getInitialSizeInfo(): EntitySizeInfo {
        return new EntitySizeInfo(0.5, 1.5);
    }

    public function getName(): string {
        return "Лавка";
    }

    public function getBenchId(): string {
        return $this->benchId;
    }

    public function setBenchId(string $id): void {
        $this->benchId = $id;
    }

    protected function initEntity(CompoundTag $nbt): void {
        parent::initEntity($nbt);
        $this->setNameTagVisible(false);
        $this->setNameTagAlwaysVisible(false);
        $this->setNameTag("");
        $this->setHasGravity(false);
        $this->setNoClientPredictions(true);

        if ($nbt->getTag("BenchId") !== null) {
            $this->benchId = $nbt->getString("BenchId");
        }
    }

    public function saveNBT(): CompoundTag {
        $nbt = parent::saveNBT();
        $nbt->setString("BenchId", $this->benchId);
        return $nbt;
    }

    public function attack(EntityDamageEvent $source): void {
        $source->cancel();
    }

    protected function tryChangeMovement(): void {
    }

    public function entityBaseTick(int $tickDiff = 1): bool {
        if ($this->getMotion()->lengthSquared() > 0) {
            $this->setMotion(Vector3::zero());
        }
        return parent::entityBaseTick($tickDiff);
    }
}

class Main extends PluginBase implements Listener {

    /** @var array<int, array{entity: BenchEntity, riders: array<int, Player>}> */
    private array $benches = [];

    /** @var array<int, int> */
    private array $sittingPlayers = [];

    private ?Skin $benchSkin = null;

    public function onEnable(): void {
        $this->saveResource("geometry.json");
        $this->saveResource("texture.png");

        if (!$this->prepareBenchSkin()) {
            return;
        }

        $skin = $this->benchSkin;
        EntityFactory::getInstance()->register(BenchEntity::class, function (World $world, CompoundTag $nbt) use ($skin): BenchEntity {
            return new BenchEntity(EntityDataHelper::parseLocation($nbt, $world), $skin, $nbt);
        }, ["rcmebel:bench", "RcBench"]);

        $this->getServer()->getPluginManager()->registerEvents($this, $this);

        $this->getScheduler()->scheduleDelayedTask(new ClosureTask(function (): void {
            $this->loadExistingBenches();
        }), 20);

        $this->getScheduler()->scheduleRepeatingTask(new ClosureTask(function (): void {
            $this->tickSittingPlayers();
        }), 5);

        $this->getLogger()->info("§aRcMebel v1.0 | InzeOwr");
    }

    public function onDisable(): void {
        foreach ($this->sittingPlayers as $playerId => $benchEntityId) {
            foreach ($this->getServer()->getOnlinePlayers() as $player) {
                if ($player->getId() === $playerId && isset($this->benches[$benchEntityId])) {
                    $bench = $this->benches[$benchEntityId]["entity"];
                    if (!$bench->isClosed()) {
                        $this->unseatPlayer($player, $bench);
                    }
                    break;
                }
            }
        }
        $this->sittingPlayers = [];
    }

    private function prepareBenchSkin(): bool {
        $texturePath = $this->getDataFolder() . "texture.png";
        $geometryPath = $this->getDataFolder() . "geometry.json";

        if (!file_exists($texturePath) || !file_exists($geometryPath)) {
            $this->getLogger()->error("§cФайлы texture.png или geometry.json не найдены!");
            $this->getServer()->getPluginManager()->disablePlugin($this);
            return false;
        }

        $img = @imagecreatefrompng($texturePath);
        if ($img === false) {
            $this->getLogger()->error("§cНе удалось загрузить texture.png!");
            $this->getServer()->getPluginManager()->disablePlugin($this);
            return false;
        }

        $width = imagesx($img);
        $height = imagesy($img);

        $skinData = "";
        for ($y = 0; $y < $height; $y++) {
            for ($x = 0; $x < $width; $x++) {
                $rgba = imagecolorat($img, $x, $y);
                $colors = imagecolorsforindex($img, $rgba);
                $r = $colors["red"];
                $g = $colors["green"];
                $b = $colors["blue"];
                $a = (int) round((127 - $colors["alpha"]) * 255 / 127);
                $skinData .= chr($r) . chr($g) . chr($b) . chr($a);
            }
        }
        imagedestroy($img);

        $geometryData = file_get_contents($geometryPath);
        if ($geometryData === false) {
            $this->getLogger()->error("§cНе удалось прочитать geometry.json!");
            $this->getServer()->getPluginManager()->disablePlugin($this);
            return false;
        }

        $geometryName = "geometry.rc_bench";
        $geoJson = json_decode($geometryData, true);
        if (isset($geoJson["minecraft:geometry"][0]["description"]["identifier"])) {
            $geometryName = $geoJson["minecraft:geometry"][0]["description"]["identifier"];
        }

        $skinId = "RcMebel.Bench." . bin2hex(random_bytes(4));

        try {
            $this->benchSkin = new Skin($skinId, $skinData, "", $geometryName, $geometryData);
        } catch (\Exception $e) {
            $this->getLogger()->error("§cОшибка скина: " . $e->getMessage());
            $this->getServer()->getPluginManager()->disablePlugin($this);
            return false;
        }

        return true;
    }

    private function loadExistingBenches(): void {
        foreach ($this->getServer()->getWorldManager()->getWorlds() as $world) {
            foreach ($world->getEntities() as $entity) {
                if ($entity instanceof BenchEntity && !$entity->isClosed()) {
                    $this->benches[$entity->getId()] = [
                        "entity" => $entity,
                        "riders" => []
                    ];
                }
            }
        }
    }

    private function tickSittingPlayers(): void {
        foreach ($this->sittingPlayers as $playerId => $benchEntityId) {
            $playerFound = false;

            foreach ($this->getServer()->getOnlinePlayers() as $player) {
                if ($player->getId() === $playerId) {
                    $playerFound = true;

                    if ($player->isSneaking()) {
                        if (isset($this->benches[$benchEntityId])) {
                            $bench = $this->benches[$benchEntityId]["entity"];
                            if (!$bench->isClosed()) {
                                $this->unseatPlayer($player, $bench);
                            }
                        }
                        unset($this->sittingPlayers[$playerId]);
                    }
                    break;
                }
            }

            if (!$playerFound) {
                unset($this->sittingPlayers[$playerId]);
                if (isset($this->benches[$benchEntityId]["riders"][$playerId])) {
                    unset($this->benches[$benchEntityId]["riders"][$playerId]);
                }
            }
        }

        foreach ($this->benches as $entityId => $info) {
            if ($info["entity"]->isClosed()) {
                foreach ($info["riders"] as $riderId => $rider) {
                    unset($this->sittingPlayers[$riderId]);
                }
                unset($this->benches[$entityId]);
            }
        }
    }

    public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool {
        if (!$sender instanceof Player) {
            $sender->sendMessage("§cТолько для игроков!");
            return true;
        }

        switch ($command->getName()) {
            case "rcspb":
                $this->spawnBench($sender);
                return true;

            case "rcspbu":
                $this->removeBench($sender);
                return true;
        }

        return false;
    }

    private function spawnBench(Player $player): void {
        if ($this->benchSkin === null) {
            $player->sendMessage("§cСкин лавки не загружен!");
            return;
        }

        $loc = $player->getLocation();
        $benchLocation = Location::fromObject(
            new Vector3(
                floor($loc->getX()) + 0.5,
                $loc->getY(),
                floor($loc->getZ()) + 0.5
            ),
            $loc->getWorld(),
            $loc->getYaw(),
            0.0
        );

        $benchId = uniqid("bench_", true);

        $nbt = CompoundTag::create()
            ->setTag("Pos", new ListTag([
                new DoubleTag($benchLocation->getX()),
                new DoubleTag($benchLocation->getY()),
                new DoubleTag($benchLocation->getZ())
            ]))
            ->setTag("Rotation", new ListTag([
                new FloatTag($benchLocation->getYaw()),
                new FloatTag(0.0)
            ]))
            ->setString("BenchId", $benchId);

        $bench = new BenchEntity($benchLocation, $this->benchSkin, $nbt);
        $bench->setBenchId($benchId);
        $bench->spawnToAll();

        $this->benches[$bench->getId()] = [
            "entity" => $bench,
            "riders" => []
        ];

        $player->sendMessage("§aЛавка установлена!");
    }

    private function removeBench(Player $player): void {
        $playerPos = $player->getPosition();
        $closestBench = null;
        $closestDistance = PHP_FLOAT_MAX;
        $closestId = -1;

        foreach ($this->benches as $entityId => $benchInfo) {
            $entity = $benchInfo["entity"];

            if ($entity->isClosed()) {
                unset($this->benches[$entityId]);
                continue;
            }

            if ($entity->getWorld()->getFolderName() !== $playerPos->getWorld()->getFolderName()) {
                continue;
            }

            $dist = $playerPos->distance($entity->getPosition());
            if ($dist <= 2.0 && $dist < $closestDistance) {
                $closestDistance = $dist;
                $closestBench = $entity;
                $closestId = $entityId;
            }
        }

        if ($closestBench === null) {
            $player->sendMessage("§cПоблизости нет лавок!");
            return;
        }

        foreach ($this->benches[$closestId]["riders"] as $riderId => $rider) {
            if ($rider instanceof Player && $rider->isOnline()) {
                $this->unseatPlayer($rider, $closestBench);
            }
            unset($this->sittingPlayers[$riderId]);
        }

        $closestBench->flagForDespawn();
        unset($this->benches[$closestId]);

        $player->sendMessage("§aЛавка удалена!");
    }

    /**
     * @priority HIGHEST
     */
    public function onEntityDamage(EntityDamageEvent $event): void {
        if ($event->getEntity() instanceof BenchEntity) {
            $event->cancel();
        }
    }

    /**
     * @priority HIGHEST
     */
    public function onEntityDamageByEntity(EntityDamageByEntityEvent $event): void {
        $entity = $event->getEntity();
        if ($entity instanceof BenchEntity) {
            $event->cancel();
            $damager = $event->getDamager();
            if ($damager instanceof Player) {
                $this->handleSit($damager, $entity);
            }
        }
    }

    /**
     * @priority HIGHEST
     */
    public function onEntityMotion(EntityMotionEvent $event): void {
        if ($event->getEntity() instanceof BenchEntity) {
            $event->cancel();
        }
    }

    /**
     * @priority NORMAL
     */
    public function onDataPacketReceive(DataPacketReceiveEvent $event): void {
        $packet = $event->getPacket();
        $player = $event->getOrigin()->getPlayer();

        if ($player === null || !($packet instanceof InteractPacket)) {
            return;
        }

        if ($packet->action === InteractPacket::ACTION_LEAVE_VEHICLE) {
            $playerId = $player->getId();
            if (isset($this->sittingPlayers[$playerId])) {
                $benchEntityId = $this->sittingPlayers[$playerId];
                if (isset($this->benches[$benchEntityId])) {
                    $bench = $this->benches[$benchEntityId]["entity"];
                    if (!$bench->isClosed()) {
                        $this->unseatPlayer($player, $bench);
                    }
                }
                unset($this->sittingPlayers[$playerId]);
            }
        }
    }

    /**
     * @priority NORMAL
     */
    public function onPlayerQuit(PlayerQuitEvent $event): void {
        $player = $event->getPlayer();
        $playerId = $player->getId();

        if (isset($this->sittingPlayers[$playerId])) {
            $benchEntityId = $this->sittingPlayers[$playerId];
            if (isset($this->benches[$benchEntityId])) {
                $bench = $this->benches[$benchEntityId]["entity"];
                if (!$bench->isClosed()) {
                    $unlinkPacket = SetActorLinkPacket::create(new EntityLink(
                        $bench->getId(),
                        $player->getId(),
                        EntityLink::TYPE_REMOVE,
                        false,
                        true,
                        0.0
                    ));
                    foreach ($bench->getWorld()->getPlayers() as $wp) {
                        if ($wp->getId() !== $playerId) {
                            $wp->getNetworkSession()->sendDataPacket($unlinkPacket);
                        }
                    }
                    unset($this->benches[$benchEntityId]["riders"][$playerId]);
                }
            }
            unset($this->sittingPlayers[$playerId]);
        }
    }

    private function handleSit(Player $player, BenchEntity $bench): void {
        $playerId = $player->getId();
        $benchEntityId = $bench->getId();

        if (isset($this->sittingPlayers[$playerId])) {
            $player->sendMessage("§eВы уже сидите! Shift чтобы встать.");
            return;
        }

        if (!isset($this->benches[$benchEntityId])) {
            return;
        }

        if ($player->getPosition()->distance($bench->getPosition()) > 3.0) {
            return;
        }

        $riders = $this->benches[$benchEntityId]["riders"];
        if (count($riders) >= 2) {
            $player->sendMessage("§cЛавка занята!");
            return;
        }

        $seatIndex = count($riders);
        $this->seatPlayer($player, $bench, $seatIndex);

        $this->benches[$benchEntityId]["riders"][$playerId] = $player;
        $this->sittingPlayers[$playerId] = $benchEntityId;

        $player->sendMessage("§aВы сели! Shift чтобы встать.");
    }

    private function seatPlayer(Player $player, BenchEntity $bench, int $seatIndex): void {
        $benchPos = $bench->getPosition();
        $yaw = $bench->getLocation()->getYaw();

        $perpRad = deg2rad($yaw + 90);
        $offset = ($seatIndex === 0) ? -0.4 : 0.4;

        $seatPos = new Vector3(
            $benchPos->getX() + cos($perpRad) * $offset,
            $benchPos->getY() + 0.4,
            $benchPos->getZ() + sin($perpRad) * $offset
        );

        $player->teleport(Location::fromObject($seatPos, $bench->getWorld(), $yaw, 0.0));

        $linkPacket = SetActorLinkPacket::create(new EntityLink(
            $bench->getId(),
            $player->getId(),
            EntityLink::TYPE_RIDER,
            true,
            true,
            0.0
        ));

        foreach ($bench->getWorld()->getPlayers() as $worldPlayer) {
            $worldPlayer->getNetworkSession()->sendDataPacket($linkPacket);
        }

        $player->setNoClientPredictions(true);
    }

    private function unseatPlayer(Player $player, BenchEntity $bench): void {
        $playerId = $player->getId();
        $benchEntityId = $bench->getId();

        $unlinkPacket = SetActorLinkPacket::create(new EntityLink(
            $bench->getId(),
            $player->getId(),
            EntityLink::TYPE_REMOVE,
            false,
            true,
            0.0
        ));

        foreach ($bench->getWorld()->getPlayers() as $worldPlayer) {
            $worldPlayer->getNetworkSession()->sendDataPacket($unlinkPacket);
        }

        $player->setNoClientPredictions(false);

        $benchPos = $bench->getPosition();
        $yaw = $bench->getLocation()->getYaw();
        $rad = deg2rad($yaw + 180);

        $exitPos = new Vector3(
            $benchPos->getX() + cos($rad) * 1.2,
            $benchPos->getY() + 0.5,
            $benchPos->getZ() + sin($rad) * 1.2
        );

        $player->teleport(Location::fromObject($exitPos, $bench->getWorld(), $player->getLocation()->getYaw(), 0.0));

        if (isset($this->benches[$benchEntityId])) {
            unset($this->benches[$benchEntityId]["riders"][$playerId]);
        }
        unset($this->sittingPlayers[$playerId]);

        $player->sendMessage("§eВы встали.");
    }
}
