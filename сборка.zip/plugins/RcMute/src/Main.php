<?php

declare(strict_types=1);

namespace InzeOwr\RcMute;

use pocketmine\plugin\PluginBase;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\player\Player;
use pocketmine\utils\Config;
use pocketmine\utils\TextFormat as TF;

class Main extends PluginBase implements Listener
{
    private Config $mutesConfig;
    private Config $limitsConfig;
    private string $timezone;
    private string $datetimeFormat;

    /** @var array */
    private array $staffGroups = [];

    /** @var array */
    private array $limitedGroups = [];

    protected function onEnable(): void
    {
        $this->saveDefaultConfig();
        $this->validateConfig();

        @mkdir($this->getDataFolder() . "data/", 0777, true);

        $this->mutesConfig = new Config($this->getDataFolder() . "data/mutes.json", Config::JSON);
        $this->limitsConfig = new Config($this->getDataFolder() . "data/limits.json", Config::JSON);

        $this->timezone = $this->getConfig()->get("timezone", "Europe/Moscow");
        $this->datetimeFormat = $this->getConfig()->get("datetime_format", "H:i:s — d.m.Y");

        date_default_timezone_set($this->timezone);

        $this->staffGroups = $this->getConfig()->get("staff_groups", []);
        $this->limitedGroups = $this->getConfig()->get("limited_groups", []);

        $this->getServer()->getPluginManager()->registerEvents($this, $this);

        $rcGroup = $this->getServer()->getPluginManager()->getPlugin("RcGroup");
        if ($rcGroup === null || !$rcGroup->isEnabled()) {
            $this->getLogger()->warning("RcGroup не найден! Защита сотрудников и лимиты НЕ будут работать!");
        } else {
            $this->getLogger()->info(TF::GREEN . "RcGroup подключён успешно.");
        }

        $this->getLogger()->info(TF::GREEN . "RcMute v1.0 by InzeOwr загружен!");
        $this->getLogger()->info(TF::YELLOW . "Защищённые группы: " . implode(", ", $this->staffGroups));
        $this->getLogger()->info(TF::YELLOW . "Лимитированные группы: " . implode(", ", array_keys($this->limitedGroups)));

        $this->cleanExpiredMutes();
    }

    private function validateConfig(): void
    {
        $config = $this->getConfig();
        $changed = false;

        $defaults = [
            "timezone" => "Europe/Moscow",
            "datetime_format" => "H:i:s — d.m.Y",
            "max_mute_time" => 0,
            "log_actions" => true,
            "broadcast_mutes" => true,
            "broadcast_unmutes" => true,
            "self_mute_protection" => true,
            "staff_groups" => [
                "CREATOR", "OWNER", "GLADMIN", "CURATOR",
                "SADMIN", "ADMIN", "MANAGER", "SMODER", "MODER"
            ],
            "limited_groups" => [
                "MIRAGE" => [
                    "max_mutes" => 6,
                    "max_time_minutes" => 180,
                    "cooldown_hours" => 24,
                    "can_unmute_staff" => false
                ],
                "SPARK" => [
                    "max_mutes" => 12,
                    "max_time_minutes" => 360,
                    "cooldown_hours" => 24,
                    "can_unmute_staff" => false
                ]
            ]
        ];

        foreach ($defaults as $key => $value) {
            if (!$config->exists($key)) {
                $config->set($key, $value);
                $changed = true;
                $this->getLogger()->warning("Ключ '$key' отсутствовал в конфиге — добавлен со значением по умолчанию.");
            }
        }

        if ($changed) {
            $config->save();
            $this->getLogger()->info(TF::GREEN . "Конфиг обновлён с недостающими ключами.");
        }
    }

    protected function onDisable(): void
    {
        $this->mutesConfig->save();
        $this->limitsConfig->save();
    }

    // ==================== УТИЛИТЫ ====================

    private function formatTimestamp(int $timestamp): string
    {
        $dt = new \DateTime("@$timestamp");
        $dt->setTimezone(new \DateTimeZone($this->timezone));
        return $dt->format($this->datetimeFormat);
    }

    private function getTimeRemaining(int $expireTimestamp): string
    {
        $diff = $expireTimestamp - time();
        if ($diff <= 0) return "истёк";
        $days = floor($diff / 86400);
        $hours = floor(($diff % 86400) / 3600);
        $minutes = floor(($diff % 3600) / 60);
        $seconds = $diff % 60;
        $parts = [];
        if ($days > 0) $parts[] = $days . " дн.";
        if ($hours > 0) $parts[] = $hours . " ч.";
        if ($minutes > 0) $parts[] = $minutes . " мин.";
        if ($seconds > 0 && $days === 0) $parts[] = $seconds . " сек.";
        return implode(" ", $parts);
    }

    private function parseMinutes(string $input): ?int
    {
        if (!is_numeric($input)) return null;
        $val = (int)$input;
        if ($val <= 0) return null;
        $maxTime = $this->getConfig()->get("max_mute_time", 0);
        if ($maxTime > 0 && $val > $maxTime) return null;
        return $val;
    }

    private function findPlayer(string $name): ?Player
    {
        $name = strtolower($name);
        $found = null;
        $delta = PHP_INT_MAX;
        foreach ($this->getServer()->getOnlinePlayers() as $player) {
            $pName = strtolower($player->getName());
            if ($pName === $name) return $player;
            if (str_starts_with($pName, $name)) {
                $curDelta = strlen($pName) - strlen($name);
                if ($curDelta < $delta) {
                    $found = $player;
                    $delta = $curDelta;
                }
            }
        }
        return $found;
    }

    private function resolveTargetName(string $input): string
    {
        $player = $this->findPlayer($input);
        return $player !== null ? $player->getName() : $input;
    }

    private function getAdminName(CommandSender $sender): string
    {
        return $sender instanceof Player ? $sender->getName() : "Console";
    }

    private function broadcast(string $message): void
    {
        if ($this->getConfig()->get("broadcast_mutes", true)) {
            $this->getServer()->broadcastMessage($message);
        }
    }

    private function broadcastUnmute(string $message): void
    {
        if ($this->getConfig()->get("broadcast_unmutes", true)) {
            $this->getServer()->broadcastMessage($message);
        }
    }

    private function logAction(string $message): void
    {
        if ($this->getConfig()->get("log_actions", true)) {
            $this->getLogger()->info(TF::clean($message));
        }
    }

    private function cleanExpiredMutes(): void
    {
        $now = time();
        $cleaned = 0;
        foreach ($this->mutesConfig->getAll() as $name => $data) {
            if (isset($data["expire"]) && $data["expire"] <= $now) {
                $this->mutesConfig->remove($name);
                $cleaned++;
            }
        }
        if ($cleaned > 0) {
            $this->mutesConfig->save();
        }
    }

    // ==================== RcGroup ИНТЕГРАЦИЯ ====================

    private function getRcGroup(): ?\InzeOwr\RcGroup\Main
    {
        $plugin = $this->getServer()->getPluginManager()->getPlugin("RcGroup");
        if ($plugin !== null && $plugin->isEnabled() && $plugin instanceof \InzeOwr\RcGroup\Main) {
            return $plugin;
        }
        return null;
    }

    private function getPlayerGroup(string $nickname): string
    {
        $rcGroup = $this->getRcGroup();
        if ($rcGroup === null) return "";
        return $rcGroup->getGroup($nickname);
    }

    private function isStaff(string $nickname): bool
    {
        $group = $this->getPlayerGroup($nickname);
        if ($group === "") return false;
        return in_array($group, $this->staffGroups, true);
    }

    private function getLimitedConfig(string $nickname): ?array
    {
        $group = $this->getPlayerGroup($nickname);
        if ($group === "") return null;
        if (isset($this->limitedGroups[$group]) && is_array($this->limitedGroups[$group])) {
            return $this->limitedGroups[$group];
        }
        return null;
    }

    private function isLimited(string $nickname): bool
    {
        return $this->getLimitedConfig($nickname) !== null;
    }

    // ==================== ПРОВЕРКИ ====================

    private function checkStaffProtection(CommandSender $sender, string $targetName): bool
    {
        if (!($sender instanceof Player)) return true;

        if ($this->isStaff($targetName)) {
            $sender->sendMessage("§c[RcMute] Вы не можете выдать наказание сотруднику проекта!");
            return false;
        }

        return true;
    }

    private function checkSelfMute(CommandSender $sender, string $targetName): bool
    {
        if ($this->getConfig()->get("self_mute_protection", true)) {
            if ($sender instanceof Player && strtolower($sender->getName()) === strtolower($targetName)) {
                $sender->sendMessage("§c[RcMute] Вы не можете замутить самого себя!");
                return false;
            }
        }
        return true;
    }

    private function checkBypass(CommandSender $sender, string $targetName): bool
    {
        $targetPlayer = $this->getServer()->getPlayerExact($targetName);
        if ($targetPlayer !== null && $targetPlayer->hasPermission("rcmute.bypass")) {
            $sender->sendMessage("§c[RcMute] Этот игрок защищён от блокировок чата!");
            return false;
        }
        return true;
    }

    private function canMuteTarget(CommandSender $sender, string $targetName): bool
    {
        if (!$this->checkSelfMute($sender, $targetName)) return false;
        if (!$this->checkBypass($sender, $targetName)) return false;
        if (!$this->checkStaffProtection($sender, $targetName)) return false;
        return true;
    }

    private function checkLimitedTime(CommandSender $sender, int $minutes): bool
    {
        if (!($sender instanceof Player)) return true;

        $senderName = $sender->getName();
        $limitCfg = $this->getLimitedConfig($senderName);
        if ($limitCfg === null) return true;

        $maxTime = (int)($limitCfg["max_time_minutes"] ?? 0);
        if ($maxTime <= 0) return true;

        if ($minutes > $maxTime) {
            $hours = floor($maxTime / 60);
            $mins = $maxTime % 60;
            $timeStr = "";
            if ($hours > 0) $timeStr .= $hours . " ч. ";
            if ($mins > 0) $timeStr .= $mins . " мин.";
            $sender->sendMessage("§c[RcMute] Максимальное время мута для вашей привилегии: §e" . trim($timeStr) . " §c(вы указали " . $minutes . " мин.)");
            return false;
        }

        return true;
    }

    private function checkAndUseMuteLimit(CommandSender $sender): bool
    {
        if (!($sender instanceof Player)) return true;

        $senderName = $sender->getName();
        $limitCfg = $this->getLimitedConfig($senderName);
        if ($limitCfg === null) return true;

        $maxMutes = (int)($limitCfg["max_mutes"] ?? 0);
        $cooldownHours = (int)($limitCfg["cooldown_hours"] ?? 24);
        if ($maxMutes <= 0) return true;

        $senderKey = strtolower($senderName);
        $limitsData = $this->limitsConfig->get($senderKey, null);

        if ($limitsData === null || !is_array($limitsData)) {
            $limitsData = [
                "mutes_used" => 0,
                "period_start" => time()
            ];
        }

        $periodStart = (int)($limitsData["period_start"] ?? time());
        $mutesUsed = (int)($limitsData["mutes_used"] ?? 0);
        $cooldownSeconds = $cooldownHours * 3600;

        if ((time() - $periodStart) >= $cooldownSeconds) {
            $mutesUsed = 0;
            $periodStart = time();
        }

        if ($mutesUsed >= $maxMutes) {
            $resetTime = $periodStart + $cooldownSeconds;
            $remaining = $this->getTimeRemaining($resetTime);
            $sender->sendMessage("§c[RcMute] Вы исчерпали лимит мутов (§e" . $maxMutes . "§c)! Сброс через: §e" . $remaining);
            return false;
        }

        $mutesUsed++;
        $this->limitsConfig->set($senderKey, [
            "mutes_used" => $mutesUsed,
            "period_start" => $periodStart
        ]);
        $this->limitsConfig->save();

        $left = $maxMutes - $mutesUsed;
        $resetTime = $periodStart + $cooldownSeconds;
        $remaining = $this->getTimeRemaining($resetTime);
        $sender->sendMessage("§e[RcMute] Использовано мутов: §c" . $mutesUsed . "/" . $maxMutes . "§e. Осталось: §c" . $left . "§e. Сброс через: §c" . $remaining);

        return true;
    }

    private function checkLimitedUnmute(CommandSender $sender, array $muteData): bool
    {
        if (!($sender instanceof Player)) return true;

        $limitCfg = $this->getLimitedConfig($sender->getName());
        if ($limitCfg === null) return true;

        $canUnmuteStaff = (bool)($limitCfg["can_unmute_staff"] ?? false);
        if ($canUnmuteStaff) return true;

        $muteAdmin = $muteData["admin"] ?? "";
        if ($this->isStaff($muteAdmin)) {
            $sender->sendMessage("§c[RcMute] Вы не можете снять наказание выданное сотрудником проекта!");
            return false;
        }

        return true;
    }

    // ==================== СОБЫТИЯ ====================

    /**
     * Блокировка чата при муте
     */
    public function onChat(PlayerChatEvent $event): void
    {
        $player = $event->getPlayer();
        $name = strtolower($player->getName());

        if (!$this->mutesConfig->exists($name)) return;

        $data = $this->mutesConfig->get($name);

        // Проверка истечения
        if (isset($data["expire"]) && time() >= $data["expire"]) {
            $this->mutesConfig->remove($name);
            $this->mutesConfig->save();
            return;
        }

        $event->cancel();

        $expireStr = isset($data["expire"]) ? $this->formatTimestamp($data["expire"]) : "Никогда";
        $remaining = isset($data["expire"]) ? $this->getTimeRemaining($data["expire"]) : "Никогда";

        $player->sendMessage("§eВам была выдана блокировка чата игроком §c" . $data["admin"] . " §eпо причине: §c" . $data["reason"] . " §eдо размута: §c" . $expireStr . " §e(осталось: §c" . $remaining . "§e)");
    }

    /**
     * Уведомление при входе если замучен
     */
    public function onJoin(PlayerJoinEvent $event): void
    {
        $player = $event->getPlayer();
        $name = strtolower($player->getName());

        if (!$this->mutesConfig->exists($name)) return;

        $data = $this->mutesConfig->get($name);

        if (isset($data["expire"]) && time() >= $data["expire"]) {
            $this->mutesConfig->remove($name);
            $this->mutesConfig->save();
            return;
        }

        $expireStr = isset($data["expire"]) ? $this->formatTimestamp($data["expire"]) : "Никогда";
        $remaining = isset($data["expire"]) ? $this->getTimeRemaining($data["expire"]) : "Никогда";

        $player->sendMessage("§eУ вас активная блокировка чата от игрока §c" . $data["admin"] . " §eпо причине: §c" . $data["reason"] . " §eдо размута: §c" . $expireStr . " §e(осталось: §c" . $remaining . "§e)");
    }

    // ==================== КОМАНДЫ ====================

    public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool
    {
        switch (strtolower($command->getName())) {
            case "rcmute": return $this->handleMute($sender, $args);
            case "rcunmute": return $this->handleUnmute($sender, $args);
            case "rcmuteinfo": return $this->handleMuteInfo($sender, $args);
            case "rcmutelist": return $this->handleMuteList($sender, $args);
        }
        return false;
    }

    // ===== /rcmute =====
    private function handleMute(CommandSender $sender, array $args): bool
    {
        if (count($args) < 3) {
            $sender->sendMessage("§c[RcMute] Использование: /rcmute <ник> <время_мин> <причина>");
            return true;
        }

        $targetInput = array_shift($args);
        $timeStr = array_shift($args);
        $reason = implode(" ", $args);

        $targetName = $this->resolveTargetName($targetInput);
        $targetKey = strtolower($targetName);
        $adminName = $this->getAdminName($sender);

        if (!$this->canMuteTarget($sender, $targetName)) return true;

        $minutes = $this->parseMinutes($timeStr);
        if ($minutes === null) {
            $sender->sendMessage("§c[RcMute] Укажите корректное время в минутах (> 0)");
            return true;
        }

        if (empty(trim($reason))) {
            $sender->sendMessage("§c[RcMute] Укажите причину мута!");
            return true;
        }

        if (!$this->checkLimitedTime($sender, $minutes)) return true;

        // Проверка существующего мута
        if ($this->mutesConfig->exists($targetKey)) {
            $existing = $this->mutesConfig->get($targetKey);
            if (isset($existing["expire"]) && $existing["expire"] > time()) {
                $sender->sendMessage("§c[RcMute] Игрок " . $targetName . " уже замучен до §e" . $this->formatTimestamp($existing["expire"]) . " §c. Мут будет перезаписан.");
            }
        }

        if (!$this->checkAndUseMuteLimit($sender)) return true;

        $expireTime = time() + ($minutes * 60);
        $expireStr = $this->formatTimestamp($expireTime);

        $muteData = [
            "admin" => $adminName,
            "reason" => $reason,
            "time" => time(),
            "expire" => $expireTime,
            "date" => $this->formatTimestamp(time()),
        ];

        $this->mutesConfig->set($targetKey, $muteData);
        $this->mutesConfig->save();

        // Уведомление цели если онлайн
        $targetPlayer = $this->getServer()->getPlayerExact($targetName);
        if ($targetPlayer === null) $targetPlayer = $this->findPlayer($targetInput);
        if ($targetPlayer !== null) {
            $targetPlayer->sendMessage("§eВам была выдана блокировка чата игроком §c" . $adminName . " §eпо причине: §c" . $reason . " §eдо размута: §c" . $expireStr);
        }

        $this->broadcast("§eИгрок §c" . $adminName . " §eвыдал блокировку чата игроку §c" . $targetName . " §eпричина: §c" . $reason . "§e. до размута: §c" . $expireStr);
        $this->logAction("[RcMute] " . $adminName . " выдал мут " . $targetName . " на " . $minutes . " мин. Причина: " . $reason);

        return true;
    }

    // ===== /rcunmute =====
    private function handleUnmute(CommandSender $sender, array $args): bool
    {
        if (count($args) < 2) {
            $sender->sendMessage("§c[RcMute] Использование: /rcunmute <ник> <причина>");
            return true;
        }

        $targetInput = array_shift($args);
        $reason = implode(" ", $args);
        $targetKey = strtolower($targetInput);
        $adminName = $this->getAdminName($sender);

        if (empty(trim($reason))) {
            $sender->sendMessage("§c[RcMute] Укажите причину размута!");
            return true;
        }

        if (!$this->mutesConfig->exists($targetKey)) {
            $sender->sendMessage("§c[RcMute] Игрок " . $targetInput . " не замучен!");
            return true;
        }

        $muteData = $this->mutesConfig->get($targetKey);

        if (!$this->checkLimitedUnmute($sender, $muteData)) return true;

        $previousAdmin = $muteData["admin"];

        $this->mutesConfig->remove($targetKey);
        $this->mutesConfig->save();

        // Уведомление цели если онлайн
        $targetPlayer = $this->getServer()->getPlayerExact($targetInput);
        if ($targetPlayer !== null) {
            $targetPlayer->sendMessage("§aБлокировка чата была снята игроком §e" . $adminName . " §aпо причине: §e" . $reason);
        }

        $this->broadcastUnmute("§eИгрок §c" . $adminName . " §eснял блокировку чата игроку §c" . $targetInput . " §eпричина: §c" . $reason);
        $this->getServer()->broadcastMessage(" - §eРанее было выдано сотрудником §c" . $previousAdmin);
        $this->logAction("[RcMute] " . $adminName . " снял мут " . $targetInput . ". Причина: " . $reason);

        return true;
    }

    // ===== /rcmuteinfo =====
    private function handleMuteInfo(CommandSender $sender, array $args): bool
    {
        if (count($args) < 1) {
            $sender->sendMessage("§c[RcMute] Использование: /rcmuteinfo <ник>");
            return true;
        }

        $targetKey = strtolower($args[0]);

        $group = $this->getPlayerGroup($args[0]);
        if ($group !== "") {
            $sender->sendMessage("§e[RcMute] Группа игрока §f" . $args[0] . "§e: §c" . $group);
        }

        if (!$this->mutesConfig->exists($targetKey)) {
            $sender->sendMessage("§a[RcMute] Блокировок чата не найдено для " . $args[0]);
            return true;
        }

        $data = $this->mutesConfig->get($targetKey);

        if (isset($data["expire"]) && time() >= $data["expire"]) {
            $sender->sendMessage("§7[Блокировка чата] Истёк");
            $this->mutesConfig->remove($targetKey);
            $this->mutesConfig->save();
            return true;
        }

        $expireStr = isset($data["expire"]) ? $this->formatTimestamp($data["expire"]) : "Никогда";
        $remaining = isset($data["expire"]) ? $this->getTimeRemaining($data["expire"]) : "Никогда";

        $sender->sendMessage("§c[Блокировка чата] §eАдминистратор: §c" . $data["admin"] . " §eПричина: §c" . $data["reason"] . " §eВыдан: §f" . ($data["date"] ?? "?") . " §eДо: §c" . $expireStr . " §eОсталось: §c" . $remaining);

        return true;
    }

    // ===== /rcmutelist =====
    private function handleMuteList(CommandSender $sender, array $args): bool
    {
        $page = isset($args[0]) && is_numeric($args[0]) ? max(1, (int)$args[0]) : 1;
        $perPage = 8;
        $allMutes = [];

        foreach ($this->mutesConfig->getAll() as $name => $data) {
            $expired = isset($data["expire"]) && time() >= $data["expire"];
            $type = $expired ? "§7ИСТЁК" : "§cАКТИВ";
            $allMutes[] = $type . " §f" . $name . " §7| §f" . $data["admin"] . " §7| §f" . $data["reason"];
        }

        $total = count($allMutes);
        $maxPage = max(1, (int)ceil($total / $perPage));
        $page = min($page, $maxPage);

        $sender->sendMessage("§e[RcMute] Список мутов (стр. $page/$maxPage, всего: $total)");

        if ($total === 0) {
            $sender->sendMessage("§a Список пуст.");
        } else {
            $offset = ($page - 1) * $perPage;
            $slice = array_slice($allMutes, $offset, $perPage);
            $i = $offset + 1;
            foreach ($slice as $line) {
                $sender->sendMessage("§f" . $i . ". " . $line);
                $i++;
            }
        }

        return true;
    }
}
