<?php

namespace InzeOwr\RcOrg;

use pocketmine\player\Player;
use pocketmine\Server;
use pocketmine\utils\Config;
use jojoe77777\FormAPI\SimpleForm;
use jojoe77777\FormAPI\CustomForm;
use onebone\economyapi\EconomyAPI;

class CourtSystem {

    private Main $plugin;
    private Config $criminalData;
    private Config $lawsuits; 

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
        $this->criminalData = new Config($plugin->getDataFolder() . "criminal_data.json", Config::JSON);
        $this->lawsuits = new Config($plugin->getDataFolder() . "lawsuits.json", Config::JSON);
    }

    public function canUseCourtItem(Player $player): bool {
        $org = $this->plugin->getPlayerOrg($player->getName());
        $rank = $this->plugin->getPlayerRank($player->getName());
        
        if ($org === "GS" && $rank >= 14) return true;
        if ($org === "GP" && $rank >= 14) return true;
        
        return false;
    }

    // --- СУДИМОСТИ ---

    public function addCriminalRecord(string $targetName, string $judgeName, string $reason): bool {
        $key = strtolower($targetName);

        $targetOrg = $this->plugin->getPlayerOrg($targetName);
        $targetRank = $this->plugin->getPlayerRank($targetName);
        
        if ($targetOrg !== null && $targetRank >= 16) {
            $judge = Server::getInstance()->getPlayerExact($judgeName);
            if ($judge !== null) {
                $judge->sendMessage("§c§l[Суд] §r§l§fЗапрещено выносить судимость руководящему составу (16+ ранг).");
            }
            return false;
        }

        $judgeOrg = $this->plugin->getPlayerOrg($judgeName);
        $judgeRank = $this->plugin->getPlayerRank($judgeName);
        $judgeRankName = $this->plugin->getRankName($judgeOrg ?? "GS", $judgeRank);

        $records = $this->criminalData->get($key, []);
        $records[] = [
            "judge" => $judgeName,
            "judge_org" => $judgeOrg,
            "judge_rank_int" => $judgeRank,
            "judge_fio" => $this->plugin->getFio($judgeName),
            "judge_rank" => $judgeRankName,
            "reason" => $reason,
            "target_fio" => $this->plugin->getFio($targetName),
            "date" => date("d.m.Y"),
            "time" => date("H:i:s"),
            "datetime" => date("d.m.Y H:i:s")
        ];
        $this->criminalData->set($key, $records);
        $this->criminalData->save();

        if ($targetOrg !== null && $targetOrg !== "MF") {
            $this->plugin->setPlayerOrg($targetName, null);
        }

        $target = Server::getInstance()->getPlayerExact($targetName);
        if ($target !== null) {
            $target->sendMessage("§c§l СУДИМОСТЬ");
            $target->sendMessage("§r§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
            $target->sendMessage("§r§l§fВам вынесен обвинительный приговор.");
            $target->sendMessage("§r§l§fСудья: §e{$judgeName}");
            $target->sendMessage("§r§l§fОснование: §e{$reason}");
            $target->sendMessage("§r§l§7Вам запрещено поступать на государственную службу.");
            $target->sendMessage("§r§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
        }

        $this->plugin->addLog("GS", "Сотрудник {$judgeName} ({$judgeOrg}) вынес судимость гражданину {$targetName}. Основание: {$reason}");
        return true;
    }

    public function removeCriminalRecord(string $targetName, int $index): bool {
        $key = strtolower($targetName);
        $records = $this->criminalData->get($key, []);
        
        if (!isset($records[$index])) return false;
        
        array_splice($records, $index, 1);
        
        if (empty($records)) {
            $this->criminalData->remove($key);
        } else {
            $this->criminalData->set($key, $records);
        }
        $this->criminalData->save();
        return true;
    }

    public function getCriminalRecords(string $targetName): array {
        return $this->criminalData->get(strtolower($targetName), []);
    }

    public function hasCriminalRecord(string $targetName): bool {
        $records = $this->criminalData->get(strtolower($targetName), []);
        return !empty($records);
    }

    // --- ИСКИ ---

    public function createLawsuit(string $plaintiff, string $defendant, string $reason): void {
        $id = uniqid();
        $data = [
            "id" => $id,
            "plaintiff" => $plaintiff, 
            "defendant" => $defendant, 
            "reason" => $reason,
            "status" => "pending", 
            "date" => date("d.m.Y H:i"),
            "judge" => null,
            "info" => null 
        ];
        
        $this->lawsuits->set($id, $data);
        $this->lawsuits->save();

        $onlineJudges = 0;
        foreach(Server::getInstance()->getOnlinePlayers() as $p) {
            $org = $this->plugin->getPlayerOrg($p->getName());
            $rank = $this->plugin->getPlayerRank($p->getName());
            if ($org === "GS" && $rank >= 14) {
                $p->sendMessage("§e§l[Суд] §r§l§fПоступил новый иск от §b{$plaintiff}§f.");
                $onlineJudges++;
            }
        }

        if ($onlineJudges === 0) {
            $this->plugin->getVKBot()->sendMessage("⚖ Новый иск!\nОт: $plaintiff\nНа: $defendant\nПричина: $reason");
        }
    }

    public function getPendingLawsuits(): array {
        $all = $this->lawsuits->getAll();
        $pending = [];
        foreach ($all as $id => $data) {
            if ($data['status'] === 'pending') $pending[$id] = $data;
        }
        return $pending;
    }

    public function approveLawsuit(string $id, string $judgeName, string $time, string $vkLink): void {
        $data = $this->lawsuits->get($id);
        if (!$data) return;

        $data['status'] = 'approved';
        $data['judge'] = $judgeName;
        $data['info'] = ["time" => $time, "vk" => $vkLink];
        $this->lawsuits->set($id, $data);
        $this->lawsuits->save();

        $this->notifyPlayer($data['plaintiff'], "§a§l[Суд] §r§l§fВаш иск одобрен! Суд: {$time}. Связь: {$vkLink}");
        $this->notifyPlayer($data['defendant'], "§c§l[Суд] §r§l§fНа вас подан иск! Суд: {$time}. Судья: {$judgeName}");
    }

    public function denyLawsuit(string $id, string $judgeName, string $reason): void {
        $data = $this->lawsuits->get($id);
        if (!$data) return;

        $data['status'] = 'denied';
        $data['judge'] = $judgeName;
        $data['info'] = ["reason" => $reason];
        $this->lawsuits->set($id, $data);
        $this->lawsuits->save();

        $this->notifyPlayer($data['plaintiff'], "§c§l[Суд] §r§l§fВаш иск отклонен. Причина: {$reason}");
    }

    private function notifyPlayer(string $name, string $msg): void {
        $p = Server::getInstance()->getPlayerExact($name);
        if ($p) {
            $p->sendMessage($msg);
        } else {
            $offline = new Config($this->plugin->getDataFolder() . "offline_msgs.json", Config::JSON);
            $msgs = $offline->get($name, []);
            $msgs[] = $msg;
            $offline->set($name, $msgs);
            $offline->save();
        }
    }

    public function checkOfflineNotifications(Player $player): void {
        $offline = new Config($this->plugin->getDataFolder() . "offline_msgs.json", Config::JSON);
        $name = $player->getName();
        if ($offline->exists($name)) {
            $msgs = $offline->get($name);
            foreach ($msgs as $msg) $player->sendMessage($msg);
            $offline->remove($name);
            $offline->save();
        }
    }

    // --- ФОРМЫ СУДИМОСТЕЙ ---

    public function openCourtMenu(Player $judge, string $targetName): void {
        $fio = $this->plugin->getFio($targetName);
        $hasCriminal = $this->hasCriminalRecord($targetName);

        $form = new SimpleForm(function (Player $player, ?int $data) use ($targetName, $hasCriminal) {
            if ($data === null) return;

            if ($data === 0) {
                $this->openAddCriminalForm($player, $targetName);
            } elseif ($data === 1) {
                if (!$hasCriminal) {
                    $player->sendMessage("§c§l[Суд] §r§l§fУ гражданина нет судимостей.");
                    return;
                }
                $records = $this->getCriminalRecords($targetName);
                $this->openRemoveCriminalList($player, $targetName, $records);
            }
        });

        $form->setTitle("§l§5СУДЕБНЫЕ ДЕЙСТВИЯ");
        $statusText = $hasCriminal ? "§cИмеется судимость" : "§aСудимостей нет";
        $form->setContent(
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" .
            "§l§fГражданин: §e{$targetName}\n" .
            "§l§fФИО: §e{$fio}\n" .
            "§l§fСтатус: {$statusText}\n" .
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        );

        $form->addButton("§l§cВыдать судимость");
        $form->addButton("§l§aСнять судимость");

        $judge->sendForm($form);
    }

    public function openAddCriminalForm(Player $judge, string $targetName): void {
        $form = new CustomForm(function (Player $player, ?array $data) use ($targetName) {
            if ($data === null) return;

            $reason = trim($data[1] ?? "");
            if (empty($reason)) {
                $player->sendMessage("§c§l[Ошибка] §r§l§fНеобходимо указать основание для вынесения приговора.");
                return;
            }

            if ($this->addCriminalRecord($targetName, $player->getName(), $reason)) {
                $player->sendMessage("§a§l[Суд] §r§l§fСудимость вынесена гражданину §e{$targetName}§f.");
            }
        });

        $fio = $this->plugin->getFio($targetName);
        $judgeOrg = $this->plugin->getPlayerOrg($judge->getName()) ?? "GS";
        $judgeRankName = $this->plugin->getRankName($judgeOrg, $this->plugin->getPlayerRank($judge->getName()));

        $form->setTitle("§l§5ВЫНЕСЕНИЕ ПРИГОВОРА");

        $form->addLabel(
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" .
            "§l§fПодсудимый: §e{$targetName}\n" .
            "§l§fФИО: §e{$fio}\n" .
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" .
            "§l§fСудья: §e{$judge->getName()}\n" .
            "§l§fДолжность: §e{$judgeRankName}\n" .
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        );

        $form->addInput("§l§fОснование приговора:", "Укажите причину");

        $judge->sendForm($form);
    }

    public function openRemoveCriminalList(Player $judge, string $targetName, array $records): void {
        $form = new SimpleForm(function (Player $player, ?int $data) use ($targetName, $records) {
            if ($data === null) return;
            if (!isset($records[$data])) return;

            if ($this->canUseCourtItem($player) || $player->hasPermission("rcorg.admin")) {
                if ($this->removeCriminalRecord($targetName, $data)) {
                    $player->sendMessage("§a§l[Суд] §r§l§fСудимость снята с гражданина §e{$targetName}§f.");
                    $target = $player->getServer()->getPlayerExact($targetName);
                    if ($target !== null) {
                        $target->sendMessage("§a§l[Суд] §r§l§fВаша судимость была погашена решением суда.");
                    }
                    $this->plugin->addLog("GS", "Судья {$player->getName()} снял судимость с гражданина {$targetName}.");
                }
            } else {
                $player->sendMessage("§c§l[Ошибка] §r§l§fУ вас нет полномочий для снятия судимости.");
            }
        });

        $form->setTitle("§l§5СНЯТИЕ СУДИМОСТИ");
        $form->setContent(
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" .
            "§l§fГражданин: §e{$targetName}\n" .
            "§l§fВыберите судимость для снятия:\n" .
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        );

        foreach ($records as $i => $record) {
            $form->addButton("§l§c#" . ($i + 1) . "\n§r§l§7{$record['reason']}");
        }

        $judge->sendForm($form);
    }

    // НПС суда
    public function openCourtNpcMenu(Player $player): void {
        $records = $this->getCriminalRecords($player->getName());

        if (empty($records)) {
            $player->sendMessage("§a§l[Суд] §r§l§fУ вас нет судимостей. Ваша репутация чиста.");
            return;
        }

        $this->openMyCriminalRecords($player, $records);
    }

    public function openMyCriminalRecords(Player $player, array $records): void {
        $fio = $this->plugin->getFio($player->getName());

        $form = new SimpleForm(function (Player $player, ?int $data) use ($records) {
            if ($data === null) return;
            if (!isset($records[$data])) return;

            $record = $records[$data];
            $this->openMyCriminalDetail($player, $record, $data);
        });

        $form->setTitle("§l§5ВАШИ СУДИМОСТИ");
        $form->setContent(
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" .
            "§l§fГражданин: §e{$player->getName()}\n" .
            "§l§fФИО: §e{$fio}\n" .
            "§l§fВсего судимостей: §e" . count($records) . "\n" .
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        );

        foreach ($records as $i => $record) {
            $form->addButton("§l§cСудимость #" . ($i + 1) . "\n§r§l§7{$record['date']}");
        }

        $player->sendForm($form);
    }

    public function openMyCriminalDetail(Player $player, array $record, int $index): void {
        $form = new SimpleForm(function (Player $player, ?int $data) use ($index) {
            if ($data === null) return;

            if ($data === 0) {
                $cost = 2500000;
                $money = EconomyAPI::getInstance()->myMoney($player);
                if ($money < $cost) {
                    $player->sendMessage("§c§l[Суд] §r§l§fНедостаточно средств для погашения судимости. Требуется: §e" . number_format($cost) . "$");
                    return;
                }

                EconomyAPI::getInstance()->reduceMoney($player, $cost);
                $result = $this->removeCriminalRecord($player->getName(), $index);
                if ($result) {
                    $player->sendMessage("§a§l[Суд] §r§l§fСудимость успешно погашена. С вашего счёта списано: §e" . number_format($cost) . "$");

                    if (!$this->hasCriminalRecord($player->getName())) {
                        $player->sendMessage("§a§l[Суд] §r§l§fВсе судимости погашены. Вам доступно трудоустройство в государственные структуры.");
                    }

                    $this->plugin->addLog("GS", "Гражданин {$player->getName()} самостоятельно погасил судимость #{$index} за " . number_format($cost) . "$.");
                } else {
                    $player->sendMessage("§c§l[Ошибка] §r§l§fНе удалось погасить судимость.");
                }
            }
        });

        $form->setTitle("§l§5ДЕЛО #" . ($index + 1));
        $form->setContent(
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" .
            "§l§fСудья: §e{$record['judge']}\n" .
            "§l§fФИО судьи: §e{$record['judge_fio']}\n" .
            "§l§fДолжность: §e{$record['judge_rank']}\n" .
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" .
            "§l§fОснование: §e{$record['reason']}\n" .
            "§l§fДата: §e{$record['date']}\n" .
            "§l§fВремя (МСК): §e{$record['time']}\n" .
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" .
            "§l§fСтоимость погашения: §e2 500 000$\n" .
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        );

        $form->addButton("§l§aПогасить судимость за 2 500 000$");

        $player->sendForm($form);
    }

    // --- МЕТОДЫ ДЛЯ ПРОСМОТРА СУДИМОСТЕЙ (Для Прокуратуры) ---

    public function openCriminalRecordView(Player $player, string $targetName, array $records): void {
        if (empty($records)) {
            $player->sendMessage("§a§l[Суд] §r§l§fУ гражданина §e{$targetName} §fсудимостей не обнаружено.");
            return;
        }

        $form = new SimpleForm(function (Player $player, ?int $data) use ($targetName, $records) {
            if ($data === null) return;
            if (!isset($records[$data])) return;

            $record = $records[$data];
            $this->openCriminalRecordDetailView($player, $targetName, $record, $data);
        });

        $fio = $this->plugin->getFio($targetName);
        $form->setTitle("§l§5СУДИМОСТИ: {$targetName}");
        $form->setContent(
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" .
            "§l§fГражданин: §e{$targetName}\n" .
            "§l§fФИО: §e{$fio}\n" .
            "§l§fВсего судимостей: §e" . count($records) . "\n" .
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        );

        foreach ($records as $i => $record) {
            $form->addButton("§l§cСудимость #" . ($i + 1) . "\n§r§l§7{$record['date']}");
        }

        $player->sendForm($form);
    }

    public function openCriminalRecordDetailView(Player $player, string $targetName, array $record, int $index): void {
        $canRemove = $this->canUseCourtItem($player) || $player->hasPermission("rcorg.admin");

        $form = new SimpleForm(function (Player $player, ?int $data) use ($targetName, $index, $canRemove) {
            if ($data === null) return;

            if ($canRemove && $data === 0) {
                if ($this->removeCriminalRecord($targetName, $index)) {
                    $player->sendMessage("§a§l[Суд] §r§l§fСудимость снята с гражданина §e{$targetName}§f.");
                    $this->plugin->addLog("GS", "Сотрудник {$player->getName()} снял судимость с гражданина {$targetName}.");
                }
            }
        });

        $fio = $this->plugin->getFio($targetName);

        $form->setTitle("§l§5ДЕЛО #" . ($index + 1));
        $form->setContent(
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" .
            "§l§fОбвиняемый: §e{$targetName}\n" .
            "§l§fФИО обвиняемого: §e{$fio}\n" .
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" .
            "§l§fСудья: §e{$record['judge']}\n" .
            "§l§fФИО судьи: §e{$record['judge_fio']}\n" .
            "§l§fДолжность: §e{$record['judge_rank']}\n" .
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" .
            "§l§fОснование: §e{$record['reason']}\n" .
            "§l§fДата: §e{$record['date']}\n" .
            "§l§fВремя (МСК): §e{$record['time']}\n" .
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        );

        if ($canRemove) {
            $form->addButton("§l§aСнять данную судимость");
        } else {
            $form->addButton("§l§cЗакрыть");
        }

        $player->sendForm($form);
    }

    // --- ФОРМЫ ИСКОВ (для судьи — Планшет Исков) ---

    public function openJudgeLawsuitList(Player $judge): void {
        $pending = $this->getPendingLawsuits();

        if (empty($pending)) {
            $judge->sendMessage("§a§l[Суд] §r§l§fНет ожидающих рассмотрения исков.");
            return;
        }

        $ids = array_keys($pending);
        $lawsuitList = array_values($pending);

        $form = new SimpleForm(function (Player $player, ?int $data) use ($ids, $lawsuitList) {
            if ($data === null) return;
            if (!isset($ids[$data])) return;

            $this->openJudgeLawsuitDetail($player, $ids[$data], $lawsuitList[$data]);
        });

        $form->setTitle("§l§5ВХОДЯЩИЕ ИСКИ");
        $form->setContent(
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" .
            "§l§fОжидают рассмотрения: §e" . count($pending) . "\n" .
            "§l§7Выберите иск для обработки:\n" .
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        );

        foreach ($lawsuitList as $lawsuit) {
            $form->addButton(
                "§l§e{$lawsuit['plaintiff']} → {$lawsuit['defendant']}\n" .
                "§r§l§7{$lawsuit['date']}"
            );
        }

        $judge->sendForm($form);
    }

    private function openJudgeLawsuitDetail(Player $judge, string $id, array $lawsuit): void {
        $plaintiffFio = $this->plugin->getFio($lawsuit['plaintiff']);
        $defendantFio = $this->plugin->getFio($lawsuit['defendant']);

        $form = new SimpleForm(function (Player $player, ?int $data) use ($id, $lawsuit) {
            if ($data === null) return;

            if ($data === 0) {
                $this->openApproveLawsuitForm($player, $id, $lawsuit);
            } elseif ($data === 1) {
                $this->openDenyLawsuitForm($player, $id, $lawsuit);
            }
        });

        $form->setTitle("§l§5ИСК: {$lawsuit['plaintiff']}");
        $form->setContent(
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" .
            "§l§fИстец: §e{$lawsuit['plaintiff']}\n" .
            "§l§fФИО истца: §e{$plaintiffFio}\n" .
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" .
            "§l§fОтветчик: §e{$lawsuit['defendant']}\n" .
            "§l§fФИО ответчика: §e{$defendantFio}\n" .
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" .
            "§l§fПричина иска:\n§7{$lawsuit['reason']}\n" .
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" .
            "§l§fДата подачи: §7{$lawsuit['date']}\n" .
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        );

        $form->addButton("§l§aОДОБРИТЬ ИСК\n§r§l§7Назначить заседание");
        $form->addButton("§l§cОТКЛОНИТЬ ИСК\n§r§l§7Отказать в рассмотрении");
        $form->addButton("§l§fЗакрыть");

        $judge->sendForm($form);
    }

    private function openApproveLawsuitForm(Player $judge, string $id, array $lawsuit): void {
        $form = new CustomForm(function (Player $player, ?array $data) use ($id) {
            if ($data === null) return;

            $time = trim($data[1] ?? "");
            $vkLink = trim($data[2] ?? "");

            if (empty($time)) {
                $player->sendMessage("§c§l[Ошибка] §r§l§fНеобходимо указать дату и время заседания.");
                return;
            }
            if (empty($vkLink)) {
                $player->sendMessage("§c§l[Ошибка] §r§l§fНеобходимо указать ссылку для связи.");
                return;
            }

            $this->approveLawsuit($id, $player->getName(), $time, $vkLink);
            $player->sendMessage("§a§l[Суд] §r§l§fИск одобрен. Стороны уведомлены.");
            $this->plugin->addLog("GS", "Судья {$player->getName()} одобрил иск #{$id}. Заседание: {$time}");
        });

        $form->setTitle("§l§aОДОБРЕНИЕ ИСКА");
        $form->addLabel(
            "§l§fИстец: §e{$lawsuit['plaintiff']}\n" .
            "§l§fОтветчик: §e{$lawsuit['defendant']}\n\n" .
            "§l§7Укажите дату/время заседания и контакт для связи."
        );
        $form->addInput("§l§fДата и время заседания:", "01.01.2025 18:00");
        $form->addInput("§l§fСсылка VK / контакт:", "vk.com/id...");

        $judge->sendForm($form);
    }

    private function openDenyLawsuitForm(Player $judge, string $id, array $lawsuit): void {
        $form = new CustomForm(function (Player $player, ?array $data) use ($id) {
            if ($data === null) return;

            $reason = trim($data[1] ?? "");
            if (empty($reason)) {
                $player->sendMessage("§c§l[Ошибка] §r§l§fНеобходимо указать причину отклонения.");
                return;
            }

            $this->denyLawsuit($id, $player->getName(), $reason);
            $player->sendMessage("§c§l[Суд] §r§l§fИск отклонён. Истец уведомлён.");
            $this->plugin->addLog("GS", "Судья {$player->getName()} отклонил иск #{$id}. Причина: {$reason}");
        });

        $form->setTitle("§l§cОТКЛОНЕНИЕ ИСКА");
        $form->addLabel(
            "§l§fИстец: §e{$lawsuit['plaintiff']}\n" .
            "§l§fОтветчик: §e{$lawsuit['defendant']}\n\n" .
            "§l§7Укажите причину отклонения иска."
        );
        $form->addInput("§l§fПричина отклонения:", "Недостаточно оснований");

        $judge->sendForm($form);
    }

    // --- ФОРМА ПОДАЧИ ИСКА (для граждан через NPC) ---

    public function openFileLawsuitForm(Player $player): void {
        $form = new CustomForm(function (Player $player, ?array $data) {
            if ($data === null) return;

            $defendant = trim($data[1] ?? "");
            $reason = trim($data[2] ?? "");

            if (empty($defendant)) {
                $player->sendMessage("§c§l[Ошибка] §r§l§fУкажите ник ответчика.");
                return;
            }
            if (empty($reason)) {
                $player->sendMessage("§c§l[Ошибка] §r§l§fУкажите причину иска.");
                return;
            }
            if (strtolower($defendant) === strtolower($player->getName())) {
                $player->sendMessage("§c§l[Ошибка] §r§l§fВы не можете подать иск на самого себя.");
                return;
            }

            $cost = 50000;
            $money = EconomyAPI::getInstance()->myMoney($player);
            if ($money < $cost) {
                $player->sendMessage("§c§l[Ошибка] §r§l§fНедостаточно средств. Госпошлина: §e" . number_format($cost) . "$");
                return;
            }

            EconomyAPI::getInstance()->reduceMoney($player, $cost);
            $this->createLawsuit($player->getName(), $defendant, $reason);
            $player->sendMessage("§a§l[Суд] §r§l§fИсковое заявление подано. Госпошлина §e" . number_format($cost) . "$ §fсписана.");
            $player->sendMessage("§l§7Ожидайте решения судьи.");
        });

        $form->setTitle("§l§5ПОДАЧА ИСКОВОГО ЗАЯВЛЕНИЯ");
        $form->addLabel(
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" .
            "§l§fИстец: §e{$player->getName()}\n" .
            "§l§fФИО: §e" . $this->plugin->getFio($player->getName()) . "\n" .
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" .
            "§l§fГоспошлина: §e50 000$\n" .
            "§l§7Заполните данные ответчика и причину.\n" .
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        );
        $form->addInput("§l§fНик ответчика:", "Steve");
        $form->addInput("§l§fПричина иска:", "Нанесение ущерба, мошенничество...");

        $player->sendForm($form);
    }
}