<?php

namespace InzeOwr\RcOrg;

use pocketmine\player\Player;
use pocketmine\Server;
use jojoe77777\FormAPI\SimpleForm;
use jojoe77777\FormAPI\CustomForm;

class CuffForms {

    public static function openCuffActionsMenu(Player $officer): void {
        $main = Main::getInstance();
        $cuffSystem = $main->getCuffSystem();

        $form = new SimpleForm(function (Player $player, ?int $data) use ($main, $cuffSystem) {
            if ($data === null) return;

            $cuffedList = $main->getCuffedByOfficer($player->getName());
            if (empty($cuffedList)) {
                $player->sendMessage("§c§l[Ошибка] §r§l§fУ вас нет задержанных.");
                return;
            }

            if ($data === 0) {
                self::openTieMenu($player, $cuffedList);
            } elseif ($data === 1) {
                self::openUntieMenu($player, $cuffedList);
            }
        });

        $form->setTitle("§l§6ДЕЙСТВИЯ С НАРУЧНИКАМИ");
        $form->setContent(
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" .
            "§l§fВыберите действие:\n" .
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        );

        $form->addButton("§l§aПривязать задержанного\n§r§l§7Обездвижить");
        $form->addButton("§l§eОтвязать задержанного\n§r§l§7Разрешить движение");

        $officer->sendForm($form);
    }

    public static function openTieMenu(Player $officer, array $cuffedList): void {
        $main = Main::getInstance();
        $cuffSystem = $main->getCuffSystem();

        $form = new SimpleForm(function (Player $player, ?int $data) use ($cuffedList, $main, $cuffSystem) {
            if ($data === null) return;
            if (!isset($cuffedList[$data])) return;

            $targetName = $cuffedList[$data];
            $target = Server::getInstance()->getPlayerExact($targetName);

            if ($target === null) {
                $player->sendMessage("§c§l[Ошибка] §r§l§fИгрок не в сети.");
                return;
            }

            $cuffSystem->tiePlayer($player, $target);
        });

        $form->setTitle("§l§aПРИВЯЗАТЬ");
        $form->setContent(
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" .
            "§l§fВыберите задержанного для привязки:\n" .
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        );

        foreach ($cuffedList as $name) {
            $tied = $cuffSystem->isTied($name) ? "§c[ПРИВЯЗАН]" : "§a[СВОБОДЕН]";
            $form->addButton("§l{$name}\n§r§l{$tied}");
        }

        $officer->sendForm($form);
    }

    public static function openUntieMenu(Player $officer, array $cuffedList): void {
        $main = Main::getInstance();
        $cuffSystem = $main->getCuffSystem();

        $tiedList = [];
        foreach ($cuffedList as $name) {
            if ($cuffSystem->isTied($name)) {
                $tiedList[] = $name;
            }
        }

        if (empty($tiedList)) {
            $officer->sendMessage("§c§l[Ошибка] §r§l§fНет привязанных задержанных.");
            return;
        }

        $form = new SimpleForm(function (Player $player, ?int $data) use ($tiedList, $cuffSystem) {
            if ($data === null) return;
            if (!isset($tiedList[$data])) return;

            $targetName = $tiedList[$data];
            $cuffSystem->untiePlayer($targetName, $player);
        });

        $form->setTitle("§l§eОТВЯЗАТЬ");
        $form->setContent(
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" .
            "§l§fВыберите привязанного для освобождения:\n" .
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        );

        foreach ($tiedList as $name) {
            $form->addButton("§l{$name}\n§r§l§7Отвязать");
        }

        $officer->sendForm($form);
    }
}