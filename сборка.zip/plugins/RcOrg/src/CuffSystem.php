<?php

namespace InzeOwr\RcOrg;

use pocketmine\player\Player;
use pocketmine\Server;
use pocketmine\utils\Config;
use pocketmine\entity\effect\EffectInstance;
use pocketmine\entity\effect\VanillaEffects;

class CuffSystem {

    private Main $plugin;
    private Config $cuffData;
    private Config $mafiaData;

    // Массивы состояний
    private array $tied = [];
    private array $mafiaCaptures = [];
    private array $bagged = [];

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
        $this->cuffData = new Config($plugin->getDataFolder() . "cuff_data.json", Config::JSON);
        $this->mafiaData = new Config($plugin->getDataFolder() . "mafia_captures.json", Config::JSON);
        
        $this->loadCuffData();
        $this->loadMafiaData();
    }

    // ==================== ЗАГРУЗКА ДАННЫХ ====================

    private function loadCuffData(): void {
        foreach ($this->cuffData->getAll() as $name => $data) {
            if (isset($data['tied']) && $data['tied'] === true) {
                $this->tied[strtolower($name)] = [
                    "officer" => $data['officer'] ?? "Unknown",
                    "pos" => null
                ];
            }
        }
    }

    private function loadMafiaData(): void {
        foreach ($this->mafiaData->getAll() as $name => $data) {
            if (isset($data['capture_time']) && $data['capture_time'] > time()) {
                $this->mafiaCaptures[strtolower($name)] = [
                    "captor" => $data['captor'] ?? "Unknown",
                    "time" => (int)$data['capture_time']
                ];
                
                if (isset($data['bagged']) && $data['bagged'] === true) {
                    $this->bagged[strtolower($name)] = $data['captor'] ?? "Unknown";
                }
            } else {
                $this->mafiaData->remove($name);
            }
        }
        $this->mafiaData->save();
    }

    // ==================== ПРИВЯЗКА (РП НАРУЧНИКИ) ====================

    public function tiePlayer(Player $officer, Player $target): void {
        $tName = strtolower($target->getName());
        $oName = strtolower($officer->getName());

        if ($this->isTied($target->getName())) {
            $officer->sendMessage("§c§l[Ошибка] §r§l§fИгрок уже привязан.");
            return;
        }

        if (!$this->plugin->isCuffed($target->getName())) {
            $officer->sendMessage("§c§l[Ошибка] §r§l§fСначала наденьте наручники на игрока.");
            return;
        }

        $cuffOfficer = $this->plugin->getOfficer($target->getName());
        if ($cuffOfficer !== $oName) {
            $officer->sendMessage("§c§l[Ошибка] §r§l§fЭтот гражданин задержан другим офицером.");
            return;
        }

        $this->tied[$tName] = [
            "officer" => $oName,
            "pos" => $target->getPosition()
        ];

        $this->cuffData->set($tName, [
            "tied" => true,
            "officer" => $oName,
            "pos" => [
                "x" => $target->getPosition()->x,
                "y" => $target->getPosition()->y,
                "z" => $target->getPosition()->z,
                "world" => $target->getWorld()->getFolderName()
            ]
        ]);
        $this->cuffData->save();

        $target->setNoClientPredictions(true);

        $officerOrg = $this->plugin->getPlayerOrg($officer->getName());
        $coloredOrg = $this->plugin->getColoredOrgName($officerOrg);

        $target->sendMessage("§c§l[ЗАДЕРЖАНИЕ] §r§l§fВы были привязаны офицером {$coloredOrg}§f. Движение невозможно.");
        $officer->sendMessage("§a§l[Рация] §r§l§fЗадержанный §e{$target->getName()} §fуспешно привязан.");
    }

    public function untiePlayer(string $targetName, ?Player $officer = null): void {
        $key = strtolower($targetName);
        
        if (!isset($this->tied[$key])) {
            if ($officer) $officer->sendMessage("§c§l[Ошибка] §r§l§fИгрок не привязан.");
            return;
        }

        unset($this->tied[$key]);
        $this->cuffData->remove($key);
        $this->cuffData->save();

        $target = Server::getInstance()->getPlayerExact($targetName);
        if ($target !== null) {
            $target->setNoClientPredictions(false);
            $target->sendMessage("§a§l[Информация] §r§l§fВас отвязали. Вы всё ещё в наручниках.");
        }

        if ($officer) {
            $officer->sendMessage("§a§l[Рация] §r§l§fГражданин §e{$targetName} §fотвязан.");
        }
    }

    public function isTied(string $name): bool {
        return isset($this->tied[strtolower($name)]);
    }

    public function getTiedOfficer(string $name): ?string {
        return $this->tied[strtolower($name)]['officer'] ?? null;
    }

    // ==================== ВЫХОД В НАРУЧНИКАХ = 7 ДНЕЙ ТЮРЬМЫ ====================

    public function handleCuffedQuit(Player $player): void {
        $name = $player->getName();
        
        if (!$this->plugin->isCuffed($name)) return;

        $officerName = $this->plugin->getOfficer($name);

        // 7 дней = 604800 секунд
        $jailTime = 7 * 24 * 60 * 60;
        $releaseTime = time() + $jailTime;

        $this->plugin->jailTimers[strtolower($name)] = $releaseTime;
        $this->plugin->jailData->set(strtolower($name), [
            "release_time" => $releaseTime,
            "reason" => "Выход из игры в наручниках (NRP)",
            "officer" => "Система",
            "officer_rank" => "Anti-NRP",
            "officer_org" => "Server",
            "date" => date("d.m.Y H:i:s"),
            "nrp_jail" => true
        ]);
        $this->plugin->jailData->save();

        // Снимаем привязку если была
        if ($this->isTied($name)) {
            $this->untiePlayer($name);
        }

        $this->plugin->uncuffPlayer($name);
        
        if ($officerName) {
            $officerPlayer = Server::getInstance()->getPlayerExact($officerName);
            if ($officerPlayer) {
                $officerPlayer->sendMessage("§c§l[Рация] §r§l§fЗадержанный §e{$name} §fпокинул сервер в наручниках. Ему назначено 7 дней тюрьмы за NRP.");
            }
        }
    }

    // ==================== МАФИЯ: СВЯЗЫВАНИЕ ====================

    public function canBindMafia(Player $player): bool {
        $org = $this->plugin->getPlayerOrg($player->getName());
        $rank = $this->plugin->getPlayerRank($player->getName());
        return ($org === "MF" && $rank >= 6);
    }

    public function bindPlayer(Player $mafioso, Player $target): void {
        $tName = strtolower($target->getName());
        $mName = strtolower($mafioso->getName());

        if ($this->isBound($target->getName())) {
            $mafioso->sendMessage("§c§l[Ошибка] §r§l§fЖертва уже связана.");
            return;
        }

        if ($this->plugin->isCuffed($target->getName())) {
            $mafioso->sendMessage("§c§l[Ошибка] §r§l§fНельзя связать гражданина в наручниках правоохранительных органов.");
            return;
        }

        if ($mafioso->getPosition()->distance($target->getPosition()) > 5) {
            $mafioso->sendMessage("§c§l[Ошибка] §r§l§fЖертва слишком далеко.");
            return;
        }

        if ($mName === $tName) {
            $mafioso->sendMessage("§c§l[Ошибка] §r§l§fВы не можете связать самого себя.");
            return;
        }

        $captureTime = time() + 600; // 10 минут

        $this->mafiaCaptures[$tName] = [
            "captor" => $mName,
            "time" => $captureTime
        ];

        $this->mafiaData->set($tName, [
            "captor" => $mName,
            "capture_time" => $captureTime,
            "date" => date("d.m.Y H:i:s")
        ]);
        $this->mafiaData->save();

        $target->sendMessage("§c§l[ПОХИЩЕНИЕ] §r§l§fВы были связаны членом §d§lОПГ§r§f. Сопротивление бесполезно.");
        $mafioso->sendMessage("§a§l[ОПГ] §r§l§fЖертва §e{$target->getName()} §fуспешно связана. Время: 10 минут.");
    }

    public function unbindPlayer(string $targetName, ?Player $mafioso = null): void {
        $key = strtolower($targetName);
        
        if (!isset($this->mafiaCaptures[$key])) {
            if ($mafioso) $mafioso->sendMessage("§c§l[Ошибка] §r§l§fЖертва не связана.");
            return;
        }

        unset($this->mafiaCaptures[$key]);
        if (isset($this->bagged[$key])) {
            $this->removeBag($targetName);
        }

        $this->mafiaData->remove($key);
        $this->mafiaData->save();

        $target = Server::getInstance()->getPlayerExact($targetName);
        if ($target !== null) {
            $target->setNoClientPredictions(false);
            $target->sendMessage("§a§l[Освобождение] §r§l§fВас развязали.");
        }

        if ($mafioso) {
            $mafioso->sendMessage("§a§l[ОПГ] §r§l§fЖертва §e{$targetName} §fосвобождена.");
        }
    }

    public function isBound(string $name): bool {
        $key = strtolower($name);
        if (!isset($this->mafiaCaptures[$key])) return false;
        
        if ($this->mafiaCaptures[$key]['time'] <= time()) {
            $this->unbindPlayer($name);
            return false;
        }
        return true;
    }

    public function getBoundCaptor(string $name): ?string {
        return $this->mafiaCaptures[strtolower($name)]['captor'] ?? null;
    }

    public function getBoundTime(string $name): int {
        $key = strtolower($name);
        if (!isset($this->mafiaCaptures[$key])) return 0;
        return max(0, $this->mafiaCaptures[$key]['time'] - time());
    }

    // ==================== МАФИЯ: МЕШОК НА ГОЛОВУ ====================

    public function putBag(Player $mafioso, Player $target): void {
        $tName = strtolower($target->getName());
        $mName = strtolower($mafioso->getName());

        if (!$this->isBound($target->getName())) {
            $mafioso->sendMessage("§c§l[Ошибка] §r§l§fСначала свяжите жертву.");
            return;
        }

        $captor = $this->getBoundCaptor($target->getName());
        if ($captor !== $mName) {
            $mafioso->sendMessage("§c§l[Ошибка] §r§l§fЖертва связана другим членом §d§lОПГ§r§f.");
            return;
        }

        if ($this->hasBag($target->getName())) {
            $mafioso->sendMessage("§c§l[Ошибка] §r§l§fНа жертве уже надет мешок.");
            return;
        }

        $this->bagged[$tName] = $mName;

        $this->mafiaData->setNested("$tName.bagged", true);
        $this->mafiaData->save();

        $target->getEffects()->add(new EffectInstance(VanillaEffects::BLINDNESS(), 999999, 255, false));
        $target->sendMessage("§c§l[ПОХИЩЕНИЕ] §r§l§fНа вас надели мешок. Вы ничего не видите!");

        $mafioso->sendMessage("§a§l[ОПГ] §r§l§fМешок надет на §e{$target->getName()}§f. Жертва ослеплена.");
    }

    public function removeBag(string $targetName, ?Player $mafioso = null): void {
        $key = strtolower($targetName);
        
        if (!isset($this->bagged[$key])) {
            if ($mafioso) $mafioso->sendMessage("§c§l[Ошибка] §r§l§fНа жертве нет мешка.");
            return;
        }

        unset($this->bagged[$key]);
        $this->mafiaData->setNested("$key.bagged", false);
        $this->mafiaData->save();

        $target = Server::getInstance()->getPlayerExact($targetName);
        if ($target !== null) {
            $target->getEffects()->remove(VanillaEffects::BLINDNESS());
            $target->sendMessage("§a§l[Освобождение] §r§l§fМешок сняли. Вы можете видеть.");
        }

        if ($mafioso) {
            $mafioso->sendMessage("§a§l[ОПГ] §r§l§fМешок снят с §e{$targetName}§f.");
        }
    }

    public function hasBag(string $name): bool {
        return isset($this->bagged[strtolower($name)]);
    }

    // ==================== ВЫХОД ИЗ ИГРЫ С МЕШКОМ = ШТРАФ 5К ====================

    public function handleBaggedQuit(Player $player): void {
        $name = $player->getName();
        
        if (!$this->isBound($name)) return;

        $captorName = $this->getBoundCaptor($name);

        $penalty = 5000;
        $api = \onebone\economyapi\EconomyAPI::getInstance();
        $current = $api->myMoney($player);

        if ($current >= $penalty) {
            $api->reduceMoney($player, $penalty);
        } else {
            $debt = $penalty - (int)$current;
            $api->setMoney($player, 0);
            
            $debtData = $this->plugin->data;
            $existingDebt = $debtData->getNested(strtolower($name) . ".mafia_debt", 0);
            $debtData->setNested(strtolower($name) . ".mafia_debt", $existingDebt + $debt);
            $debtData->save();
        }

        $this->unbindPlayer($name);

        if ($captorName) {
            $captorPlayer = Server::getInstance()->getPlayerExact($captorName);
            if ($captorPlayer) {
                $captorPlayer->sendMessage("§c§l[ОПГ] §r§l§fЖертва §e{$name} §fпокинула игру. Штраф 5000$ применён.");
            }
        }
    }

    // ==================== ПРОВЕРКА ДОЛГА ====================

    public function checkDebt(Player $player): void {
        $name = strtolower($player->getName());
        $debt = $this->plugin->data->getNested("$name.mafia_debt", 0);

        if ($debt <= 0) return;

        $api = \onebone\economyapi\EconomyAPI::getInstance();
        $earned = $api->myMoney($player);

        if ($earned > 0) {
            if ($earned >= $debt) {
                $api->reduceMoney($player, $debt);
                $this->plugin->data->removeNested("$name.mafia_debt");
                $this->plugin->data->save();
                $player->sendMessage("§a§l[Долг] §r§l§fВаш долг §d§lОПГ §r§l§f(§e" . number_format($debt) . "$§f) погашен.");
            } else {
                $api->setMoney($player, 0);
                $remaining = $debt - (int)$earned;
                $this->plugin->data->setNested("$name.mafia_debt", $remaining);
                $this->plugin->data->save();
                $player->sendMessage("§c§l[Долг] §r§l§fЧастично погашено §e" . number_format((int)$earned) . "$§f. Осталось: §e" . number_format($remaining) . "$");
            }
        }
    }

    // ==================== ДВИЖЕНИЕ ПРИВЯЗАННОГО ИГРОКА ====================

    public function handleTiedMovement(Player $player): void {
        $name = $player->getName();
        
        if (!$this->isTied($name)) return;

        $key = strtolower($name);
        $tiedData = $this->tied[$key];
        $tiedPos = $tiedData['pos'] ?? null;

        if ($tiedPos !== null) {
            $player->teleport($tiedPos);
        }
    }

    // ==================== ДВИЖЕНИЕ СВЯЗАННОГО МАФИЕЙ ====================

    public function handleBoundMovement(Player $player): void {
        $name = $player->getName();
        
        if (!$this->isBound($name)) return;

        $captorName = $this->getBoundCaptor($name);
        if ($captorName === null) return;

        $captor = Server::getInstance()->getPlayerExact($captorName);
        if ($captor === null || !$captor->isOnline()) {
            return;
        }

        if ($player->getPosition()->distance($captor->getPosition()) > 3) {
            $cPos = $captor->getPosition();
            $dir = $captor->getDirectionVector()->multiply(-1.5);
            $player->teleport($cPos->add($dir->x, 0, $dir->z));
        }
    }

    // ==================== АДМИН: СНЯТЬ ВСЁ ====================

    public function adminUncuff(string $targetName, Player $admin): void {
        $key = strtolower($targetName);

        if ($this->plugin->isCuffed($targetName)) {
            $this->plugin->uncuffPlayer($targetName);
        }

        if ($this->isTied($targetName)) {
            $this->untiePlayer($targetName);
        }

        if ($this->isBound($targetName)) {
            $this->unbindPlayer($targetName);
        }

        $target = Server::getInstance()->getPlayerExact($targetName);
        if ($target !== null) {
            $target->setNoClientPredictions(false);
            $target->sendMessage("§a§l[Администрация] §r§l§fВы были освобождены администратором §e{$admin->getName()}§f.");
        }

        $admin->sendMessage("§a§l[Система] §r§l§fВсе ограничения с §e{$targetName} §fсняты.");
    }

    // ==================== АДМИН: ОСВОБОЖДЕНИЕ ИЗ ТЮРЬМЫ ====================

    public function adminUnjail(string $targetName, Player $admin): void {
        $key = strtolower($targetName);

        if (!$this->plugin->isJailed($targetName)) {
            $admin->sendMessage("§c§l[Ошибка] §r§l§fИгрок не находится в тюрьме.");
            return;
        }

        unset($this->plugin->jailTimers[$key]);
        $this->plugin->jailData->remove($key);
        $this->plugin->jailData->save();

        $target = Server::getInstance()->getPlayerExact($targetName);
        if ($target !== null) {
            $target->setNoClientPredictions(false);
            $this->plugin->teleportToRelease($target);
            $target->sendMessage("§a§l[Администрация] §r§l§fВы досрочно освобождены администратором §e{$admin->getName()}§f.");
        }

        $admin->sendMessage("§a§l[Система] §r§l§fИгрок §e{$targetName} §fосвобождён из тюрьмы.");
    }

    // ==================== TICK TASK ====================

    public function onTick(): void {
        foreach (Server::getInstance()->getOnlinePlayers() as $player) {
            $name = $player->getName();

            // Проверка долга мафии
            $this->checkDebt($player);

            // Обновление слепоты от мешка
            if ($this->hasBag($name) && !$player->getEffects()->has(VanillaEffects::BLINDNESS())) {
                $player->getEffects()->add(new EffectInstance(VanillaEffects::BLINDNESS(), 999999, 255, false));
            }

            // Автоосвобождение по таймеру мафии
            if ($this->isBound($name) && $this->getBoundTime($name) <= 0) {
                $this->unbindPlayer($name);
                $player->sendMessage("§a§l[Освобождение] §r§l§fВремя похищения истекло. Вы свободны.");
            }
        }
    }
}