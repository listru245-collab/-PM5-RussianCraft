<?php

namespace InzeOwr\RcOrg;

use pocketmine\player\Player;
use pocketmine\Server;
use pocketmine\utils\Config;
use jojoe77777\FormAPI\SimpleForm;
use jojoe77777\FormAPI\CustomForm;

class ImmunitySystem {

    private Main $plugin;
    private Config $removedImmunity;

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
        $this->removedImmunity = new Config($plugin->getDataFolder() . "immunity_removed.json", Config::JSON);
    }

    public function hasImmunity(string $playerName): bool {
        $org = $this->plugin->getPlayerOrg($playerName);
        $rank = $this->plugin->getPlayerRank($playerName);
        
        if ($org === "MF" || $org === null) return false;
        
        if ($rank >= 15) {
            if ($this->removedImmunity->exists(strtolower($playerName))) return false;
            return true;
        }
        return false;
    }

    public function removeImmunity(string $targetName, string $reason, string $judgeName): void {
        $this->removedImmunity->set(strtolower($targetName), [
            "by" => $judgeName,
            "reason" => $reason,
            "date" => date("d.m.Y H:i")
        ]);
        $this->removedImmunity->save();
    }

    public function restoreImmunity(string $targetName): void {
        $this->removedImmunity->remove(strtolower($targetName));
        $this->removedImmunity->save();
    }

    /**
     * Собирает всех с иммунитетом (15+ ранг, не MF), группирует по организациям
     */
    private function collectImmuneByOrg(): array {
        $api = $this->plugin;
        $byOrg = [];

        foreach ($api->data->getAll() as $nick => $data) {
            $org = $data['org'] ?? null;
            $rank = $data['rank'] ?? 0;
            $realName = $data['real_name'] ?? $nick;

            if ($org && $org !== "MF" && $rank >= 15) {
                $isRemoved = $this->removedImmunity->exists(strtolower($realName));
                $status = $isRemoved ? "§c[СНЯТА]" : "§a[АКТИВНА]";
                $rankName = $api->getRankName($org, $rank);

                if (!isset($byOrg[$org])) {
                    $byOrg[$org] = [];
                }

                $byOrg[$org][] = [
                    "name" => $realName,
                    "status" => $status,
                    "org" => $org,
                    "rank" => $rank,
                    "rank_name" => $rankName,
                    "removed" => $isRemoved
                ];
            }
        }

        // Сортировка внутри каждой организации по рангу (высшие сверху)
        foreach ($byOrg as $org => &$players) {
            usort($players, fn($a, $b) => $b['rank'] <=> $a['rank']);
        }
        unset($players);

        return $byOrg;
    }

    // Главное меню — список организаций
    public function openImmunityMenu(Player $player): void {
        $api = $this->plugin;
        $byOrg = $this->collectImmuneByOrg();

        if (empty($byOrg)) {
            $player->sendMessage("§7§l[Суд] §r§l§fСписок неприкосновенных лиц пуст.");
            return;
        }

        $orgKeys = array_keys($byOrg);

        $form = new SimpleForm(function (Player $player, $data) use ($byOrg, $orgKeys) {
            if ($data === null) return;
            if (!isset($orgKeys[$data])) return;

            $selectedOrg = $orgKeys[$data];
            $this->openOrgImmunityList($player, $selectedOrg, $byOrg[$selectedOrg]);
        });

        $form->setTitle("§l§6РЕЕСТР НЕПРИКОСНОВЕННОСТИ");
        $form->setContent("§l§fВыберите организацию для просмотра:");

        foreach ($orgKeys as $orgKey) {
            $orgName = $api->getOrgName($orgKey);
            $color = $api->getOrgColor($orgKey);
            $count = count($byOrg[$orgKey]);

            // Считаем активных и снятых
            $active = 0;
            $removed = 0;
            foreach ($byOrg[$orgKey] as $p) {
                if ($p['removed']) $removed++;
                else $active++;
            }

            $form->addButton("§l§{$color}{$orgName}\n§r§l§7Лиц: {$count} §a({$active}) §c({$removed})");
        }

        $player->sendForm($form);
    }

    // Список сотрудников с иммунитетом в конкретной организации
    private function openOrgImmunityList(Player $player, string $orgKey, array $players): void {
        $api = $this->plugin;
        $orgName = $api->getOrgName($orgKey);
        $color = $api->getOrgColor($orgKey);

        $form = new SimpleForm(function (Player $player, $data) use ($players) {
            if ($data === null) return;
            if (!isset($players[$data])) return;

            $target = $players[$data];
            $this->openImmunityAction($player, $target);
        });

        $form->setTitle("§l§{$color}{$orgName} — НЕПРИКОСНОВЕННОСТЬ");

        foreach ($players as $p) {
            $online = Server::getInstance()->getPlayerExact($p['name']) !== null;
            $onlineStr = $online ? "§a●" : "§c●";
            $form->addButton("§l{$onlineStr} {$p['name']}\n§r§l§7{$p['rank_name']} ({$p['rank']}) {$p['status']}");
        }

        $player->sendForm($form);
    }

    // Действие с конкретным игроком
    public function openImmunityAction(Player $player, array $target): void {
        $api = $this->plugin;
        $fio = $api->getFio($target['name']);
        $orgName = $api->getOrgName($target['org']);
        $color = $api->getOrgColor($target['org']);

        if ($target['removed']) {
            // Уже снята — показываем инфо и кнопку восстановления
            $info = $this->removedImmunity->get(strtolower($target['name']), []);

            $form = new SimpleForm(function (Player $player, $data) use ($target) {
                if ($data === null) return;
                if ($data === 0) {
                    $this->restoreImmunity($target['name']);
                    $player->sendMessage("§a§l[Суд] §r§l§fНеприкосновенность гражданина {$target['name']} восстановлена.");

                    $t = Server::getInstance()->getPlayerExact($target['name']);
                    if ($t) $t->sendMessage("§a§l[СУД] §r§l§fВаша неприкосновенность восстановлена решением суда.");

                    $this->plugin->addLog("GS", "Судья {$player->getName()} восстановил неприкосновенность {$target['name']}.");
                }
            });

            $form->setTitle("§l§4{$target['name']} — СНЯТА");
            $content = "§l§fГражданин: §e{$target['name']}\n";
            $content .= "§l§fФИО: §e{$fio}\n";
            $content .= "§l§fОрганизация: §{$color}{$orgName}\n";
            $content .= "§l§fДолжность: §e{$target['rank_name']} ({$target['rank']})\n\n";
            $content .= "§l§cНеприкосновенность СНЯТА\n";
            if (isset($info['by'])) $content .= "§l§fКем: §7{$info['by']}\n";
            if (isset($info['reason'])) $content .= "§l§fПричина: §7{$info['reason']}\n";
            if (isset($info['date'])) $content .= "§l§fДата: §7{$info['date']}\n";

            $form->setContent($content);
            $form->addButton("§l§aВОССТАНОВИТЬ НЕПРИКОСНОВЕННОСТЬ");
            $form->addButton("§l§fЗакрыть");
            $player->sendForm($form);
            return;
        }

        // Неприкосновенность активна — форма снятия
        $form = new CustomForm(function (Player $player, $data) use ($target) {
            if ($data === null) return;
            $reason = trim($data[1] ?? "");
            if (empty($reason)) {
                $player->sendMessage("§c§l[Ошибка] §r§l§fНеобходимо указать причину снятия неприкосновенности.");
                return;
            }

            $this->removeImmunity($target['name'], $reason, $player->getName());
            $player->sendMessage("§a§l[Суд] §r§l§fНеприкосновенность с гражданина {$target['name']} снята.");

            $t = Server::getInstance()->getPlayerExact($target['name']);
            if ($t) $t->sendMessage("§c§l[СУД] §r§l§fС вас снята неприкосновенность! Причина: $reason");

            $this->plugin->addLog("GS", "Судья {$player->getName()} снял неприкосновенность с {$target['name']}. Причина: $reason");
        });

        $form->setTitle("§l§4СНЯТИЕ НЕПРИКОСНОВЕННОСТИ");
        $label = "§l§fГражданин: §e{$target['name']}\n";
        $label .= "§l§fФИО: §e{$fio}\n";
        $label .= "§l§fОрганизация: §{$color}{$orgName}\n";
        $label .= "§l§fДолжность: §e{$target['rank_name']} ({$target['rank']})\n\n";
        $label .= "§l§cВнимание! Снятие неприкосновенности позволит задерживать данного сотрудника.";

        $form->addLabel($label);
        $form->addInput("§l§fПричина снятия:", "Госизмена, превышение полномочий");
        $player->sendForm($form);
    }
}