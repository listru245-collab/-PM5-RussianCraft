<?php

namespace InzeOwr\RcOrg;

use pocketmine\player\Player;
use pocketmine\Server;
use jojoe77777\FormAPI\SimpleForm;
use jojoe77777\FormAPI\CustomForm;

class MafiaForms {

    // ==================== МЕНЮ МАФИИ: СВЯЗЫВАНИЕ/МЕШОК ====================

    public static function openMafiaBindMenu(Player $mafioso): void {
        $main = Main::getInstance();
        $cuffSystem = $main->getCuffSystem();

        $form = new SimpleForm(function (Player $player, ?int $data) {
            if ($data === null) return;
            if ($data === 0) {
                $online = [];
                foreach (Server::getInstance()->getOnlinePlayers() as $p) {
                    if ($p->getName() !== $player->getName()) $online[] = $p->getName();
                }
                if (empty($online)) { $player->sendMessage("§c§l[Ошибка] §r§l§fНет игроков."); return; }
                self::openBindTargetMenu($player, $online);
            } elseif ($data === 1) {
                $online = [];
                foreach (Server::getInstance()->getOnlinePlayers() as $p) {
                    if ($p->getName() !== $player->getName()) $online[] = $p->getName();
                }
                self::openBagTargetMenu($player, $online);
            } elseif ($data === 2) {
                self::openRemoveBagMenu($player);
            } elseif ($data === 3) {
                self::openUnbindMenu($player);
            }
        });

        $form->setTitle("§l§5ИНСТРУМЕНТЫ ОПГ");
        $form->setContent(
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" .
            "§l§dВыберите действие:\n" .
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        );
        $form->addButton("§l§cСвязать жертву\n§r§l§7Захват (10 мин)");
        $form->addButton("§l§8Надеть мешок\n§r§l§7Ослепление");
        $form->addButton("§l§eСнять мешок\n§r§l§7Убрать слепоту");
        $form->addButton("§l§aРазвязать\n§r§l§7Освободить");
        $mafioso->sendForm($form);
    }

    public static function openBindTargetMenu(Player $mafioso, array $online): void {
        $cuffSystem = Main::getInstance()->getCuffSystem();
        $form = new SimpleForm(function (Player $player, ?int $data) use ($online, $cuffSystem) {
            if ($data === null) return;
            if (!isset($online[$data])) return;
            $target = Server::getInstance()->getPlayerExact($online[$data]);
            if ($target === null) { $player->sendMessage("§c§l[Ошибка] §r§l§fИгрок не в сети."); return; }
            $cuffSystem->bindPlayer($player, $target);
        });
        $form->setTitle("§l§cСВЯЗАТЬ");
        $form->setContent("§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n§l§fВыберите жертву:\n§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
        foreach ($online as $name) {
            $status = $cuffSystem->isBound($name) ? "§c[СВЯЗАН]" : "§a[СВОБОДЕН]";
            $form->addButton("§l{$name}\n§r§l{$status}");
        }
        $mafioso->sendForm($form);
    }

    public static function openBagTargetMenu(Player $mafioso, array $online): void {
        $cuffSystem = Main::getInstance()->getCuffSystem();
        $boundList = [];
        foreach ($online as $name) {
            if ($cuffSystem->isBound($name)) $boundList[] = $name;
        }
        if (empty($boundList)) { $mafioso->sendMessage("§c§l[Ошибка] §r§l§fНет связанных жертв."); return; }
        $form = new SimpleForm(function (Player $player, ?int $data) use ($boundList, $cuffSystem) {
            if ($data === null) return;
            if (!isset($boundList[$data])) return;
            $target = Server::getInstance()->getPlayerExact($boundList[$data]);
            if ($target === null) { $player->sendMessage("§c§l[Ошибка] §r§l§fИгрок не в сети."); return; }
            $cuffSystem->putBag($player, $target);
        });
        $form->setTitle("§l§8НАДЕТЬ МЕШОК");
        $form->setContent("§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n§l§fВыберите связанную жертву:\n§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
        foreach ($boundList as $name) {
            $hasBag = $cuffSystem->hasBag($name) ? "§8[МЕШОК]" : "§7[БЕЗ МЕШКА]";
            $form->addButton("§l{$name}\n§r§l{$hasBag}");
        }
        $mafioso->sendForm($form);
    }

    public static function openRemoveBagMenu(Player $mafioso): void {
        $cuffSystem = Main::getInstance()->getCuffSystem();
        $baggedList = [];
        foreach (Server::getInstance()->getOnlinePlayers() as $p) {
            if ($cuffSystem->hasBag($p->getName())) $baggedList[] = $p->getName();
        }
        if (empty($baggedList)) { $mafioso->sendMessage("§c§l[Ошибка] §r§l§fНет жертв с мешками."); return; }
        $form = new SimpleForm(function (Player $player, ?int $data) use ($baggedList, $cuffSystem) {
            if ($data === null) return;
            if (!isset($baggedList[$data])) return;
            $cuffSystem->removeBag($baggedList[$data], $player);
        });
        $form->setTitle("§l§eСНЯТЬ МЕШОК");
        $form->setContent("§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n§l§fВыберите жертву:\n§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
        foreach ($baggedList as $name) {
            $form->addButton("§l{$name}\n§r§l§8Снять мешок");
        }
        $mafioso->sendForm($form);
    }

    public static function openUnbindMenu(Player $mafioso): void {
        $cuffSystem = Main::getInstance()->getCuffSystem();
        $boundList = [];
        foreach (Server::getInstance()->getOnlinePlayers() as $p) {
            if ($cuffSystem->isBound($p->getName())) $boundList[] = $p->getName();
        }
        if (empty($boundList)) { $mafioso->sendMessage("§c§l[Ошибка] §r§l§fНет связанных жертв."); return; }
        $form = new SimpleForm(function (Player $player, ?int $data) use ($boundList, $cuffSystem) {
            if ($data === null) return;
            if (!isset($boundList[$data])) return;
            $cuffSystem->unbindPlayer($boundList[$data], $player);
        });
        $form->setTitle("§l§aРАЗВЯЗАТЬ");
        $form->setContent("§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n§l§fВыберите жертву:\n§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
        foreach ($boundList as $name) {
            $remaining = Main::getInstance()->getCuffSystem()->getBoundTime($name);
            $form->addButton("§l{$name}\n§r§l§7Осталось: " . Main::getInstance()->formatTime($remaining));
        }
        $mafioso->sendForm($form);
    }

    // ==================== КРАФТ НАРКОТИКОВ ====================

    public static function openDrugCraftMenu(Player $player): void {
        $mafiaSystem = Main::getInstance()->getMafiaSystem();
        $form = new SimpleForm(function (Player $player, ?int $data) use ($mafiaSystem) {
            if ($data === null) return;
            $drugs = array_keys(MafiaSystem::DRUGS);
            if (!isset($drugs[$data])) return;
            $mafiaSystem->startCrafting($player, $drugs[$data]);
        });
        $form->setTitle("§l§5ПОДПОЛЬНАЯ ЛАБОРАТОРИЯ");
        $form->setContent(
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" .
            "§l§dВыберите продукт для производства.\n" .
            "§l§7Каждый тип требует уникальное задание.\n" .
            "§l§7Провал = потеря ингредиентов.\n" .
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        );
        foreach (MafiaSystem::DRUGS as $type => $info) {
            $minigame = MafiaSystem::MINIGAMES[$mafiaSystem->drugMinigames[$type]] ?? "???";
            $recipe = $mafiaSystem->getRecipe($type);
            $diff = $recipe ? $recipe['difficulty'] : 1;
            $stars = str_repeat("*", $diff) . str_repeat(".", 5 - $diff);
            $form->addButton("{$info['name']}\n§r§l§7[{$stars}] {$minigame}");
        }
        $player->sendForm($form);
    }

    // ==================== ТАЙНИК ====================

    public static function openDrugInventory(Player $player): void {
        $mafiaSystem = Main::getInstance()->getMafiaSystem();
        $drugs = $mafiaSystem->getDrugs($player->getName());
        $form = new SimpleForm(function (Player $player, ?int $data) use ($drugs) {
            if ($data === null) return;
            $drugTypes = [];
            foreach ($drugs as $type => $count) {
                if ($count > 0) $drugTypes[] = $type;
            }
            if (!isset($drugTypes[$data])) return;
            self::openDrugManageMenu($player, $drugTypes[$data]);
        });
        $form->setTitle("§l§5ТАЙНИК");
        if (empty($drugs) || array_sum($drugs) === 0) {
            $form->setContent("§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n§l§7Тайник пуст. Производите в лаборатории.\n§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
            $player->sendForm($form);
            return;
        }
        $content = "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n§l§fВаши запасы:\n§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n";
        $total = 0;
        foreach ($drugs as $type => $count) {
            if ($count > 0 && isset(MafiaSystem::DRUGS[$type])) {
                $content .= "§l" . MafiaSystem::DRUGS[$type]['name'] . "§r§f: §e{$count}шт.\n";
                $total += $count;
            }
        }
        $content .= "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n§l§fВсего: §e{$total}шт.";
        $form->setContent($content);
        foreach ($drugs as $type => $count) {
            if ($count > 0 && isset(MafiaSystem::DRUGS[$type])) {
                $form->addButton(MafiaSystem::DRUGS[$type]['name'] . "\n§r§l§7x{$count}");
            }
        }
        $player->sendForm($form);
    }

    public static function openDrugManageMenu(Player $player, string $drugType): void {
        $mafiaSystem = Main::getInstance()->getMafiaSystem();
        $count = $mafiaSystem->getDrugCount($player->getName(), $drugType);
        $drugInfo = MafiaSystem::DRUGS[$drugType] ?? null;
        if (!$drugInfo || $count <= 0) { $player->sendMessage("§c§l[Ошибка] §r§l§fНет этого наркотика."); return; }
        $form = new SimpleForm(function (Player $player, ?int $data) use ($drugType) {
            if ($data === null) return;
            if ($data === 0) self::openSellDrugMenu($player, $drugType);
            elseif ($data === 1) self::openTransferDrugMenu($player, $drugType);
        });
        $form->setTitle("§l{$drugInfo['name']}");
        $form->setContent("§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n§l§fУ вас: §e{$count}шт.\n§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
        $form->addButton("§l§aПродать игроку\n§r§l§7За деньги (с подтверждением)");
        $form->addButton("§l§eПередать бесплатно\n§r§l§7С подтверждением");
        $player->sendForm($form);
    }

    // ==================== ПРОДАЖА ====================

    public static function openSellDrugMenu(Player $seller, string $drugType): void {
        $mafiaSystem = Main::getInstance()->getMafiaSystem();
        $online = [];
        foreach (Server::getInstance()->getOnlinePlayers() as $p) {
            if ($p->getName() !== $seller->getName()) $online[] = $p->getName();
        }
        if (empty($online)) { $seller->sendMessage("§c§l[Ошибка] §r§l§fНет игроков."); return; }
        $maxCount = $mafiaSystem->getDrugCount($seller->getName(), $drugType);
        $drugInfo = MafiaSystem::DRUGS[$drugType];
        $form = new CustomForm(function (Player $player, ?array $data) use ($drugType, $online, $mafiaSystem, $drugInfo, $maxCount) {
            if ($data === null) return;
            $targetIndex = (int)($data[1] ?? 0);
            $amount = (int)($data[2] ?? 1);
            $pricePerUnit = (int)($data[3] ?? 100);
            if (!isset($online[$targetIndex])) return;
            $targetName = $online[$targetIndex];
            if ($amount < 1 || $amount > $maxCount) { $player->sendMessage("§c§l[Ошибка] §r§l§fНекорректное количество."); return; }
            if ($pricePerUnit < 1) { $player->sendMessage("§c§l[Ошибка] §r§l§fЦена должна быть больше 0."); return; }
            $target = Server::getInstance()->getPlayerExact($targetName);
            if ($target === null) { $player->sendMessage("§c§l[Ошибка] §r§l§fИгрок вышел."); return; }
            $totalPrice = $amount * $pricePerUnit;
            $dealId = $mafiaSystem->createDeal($player->getName(), $targetName, $drugType, $amount, $pricePerUnit);
            $player->sendMessage("§a§l[Сделка] §r§l§fПредложение отправлено §e{$targetName}§f.");
            $player->sendMessage("§l§7Товар: {$drugInfo['name']} x{$amount} | Итого: " . number_format($totalPrice) . "$");
            self::openDealConfirmMenu($target, $dealId);
        });
        $form->setTitle("§l§aPРОДАЖА: {$drugInfo['name']}");
        $form->addLabel("§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n§l§fТовар: {$drugInfo['name']}\n§l§fДоступно: §e{$maxCount}шт.\n§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
        $form->addDropdown("§l§fПокупатель:", $online);
        $form->addSlider("§l§fКоличество:", 1, $maxCount, 1, 1);
        $form->addInput("§l§fЦена за 1шт.:", "1000", "1000");
        $seller->sendForm($form);
    }

    public static function openDealConfirmMenu(Player $buyer, string $dealId): void {
        $mafiaSystem = Main::getInstance()->getMafiaSystem();
        $deal = $mafiaSystem->getDeal($dealId);
        if ($deal === null) { $buyer->sendMessage("§c§l[Ошибка] §r§l§fСделка не найдена."); return; }
        $drugInfo = MafiaSystem::DRUGS[$deal['drug']];
        $form = new SimpleForm(function (Player $player, ?int $data) use ($dealId, $mafiaSystem) {
            if ($data === null) { $mafiaSystem->declineDeal($dealId, $player); return; }
            if ($data === 0) $mafiaSystem->acceptDeal($dealId, $player);
            elseif ($data === 1) $mafiaSystem->declineDeal($dealId, $player);
        });
        $form->setTitle("§l§5ПРЕДЛОЖЕНИЕ СДЕЛКИ");
        $form->setContent(
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" .
            "§l§fПродавец: §e{$deal['seller']}\n" .
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" .
            "§l§fТовар: {$drugInfo['name']}\n" .
            "§l§fКоличество: §e{$deal['amount']}шт.\n" .
            "§l§fЦена за шт.: §e" . number_format($deal['price_per_unit']) . "$\n" .
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" .
            "§l§fИТОГО: §e§l" . number_format($deal['total_price']) . "$\n" .
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        );
        $form->addButton("§l§aПРИНЯТЬ\n§r§l§7Купить товар");
        $form->addButton("§l§cОТКАЗАТЬСЯ\n§r§l§7Отменить");
        $buyer->sendForm($form);
    }

    // ==================== БЕСПЛАТНАЯ ПЕРЕДАЧА ====================

    public static function openTransferDrugMenu(Player $from, string $drugType): void {
        $mafiaSystem = Main::getInstance()->getMafiaSystem();
        $online = [];
        foreach (Server::getInstance()->getOnlinePlayers() as $p) {
            if ($p->getName() !== $from->getName()) $online[] = $p->getName();
        }
        if (empty($online)) { $from->sendMessage("§c§l[Ошибка] §r§l§fНет игроков."); return; }
        $maxCount = $mafiaSystem->getDrugCount($from->getName(), $drugType);
        $drugInfo = MafiaSystem::DRUGS[$drugType];
        $form = new CustomForm(function (Player $player, ?array $data) use ($drugType, $online, $mafiaSystem, $drugInfo, $maxCount) {
            if ($data === null) return;
            $targetIndex = (int)($data[1] ?? 0);
            $amount = (int)($data[2] ?? 1);
            if (!isset($online[$targetIndex])) return;
            $targetName = $online[$targetIndex];
            if ($amount < 1 || $amount > $maxCount) { $player->sendMessage("§c§l[Ошибка] §r§l§fНекорректное количество."); return; }
            $target = Server::getInstance()->getPlayerExact($targetName);
            if ($target === null) { $player->sendMessage("§c§l[Ошибка] §r§l§fИгрок вышел."); return; }
            $transferId = $mafiaSystem->createTransfer($player->getName(), $targetName, $drugType, $amount);
            $player->sendMessage("§a§l[Передача] §r§l§fПредложение отправлено §e{$targetName}§f.");
            $player->sendMessage("§l§7Товар: {$drugInfo['name']} x{$amount} (бесплатно)");
            self::openTransferConfirmMenu($target, $transferId);
        });
        $form->setTitle("§l§ePЕРЕДАЧА: {$drugInfo['name']}");
        $form->addLabel("§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n§l§fТовар: {$drugInfo['name']}\n§l§fДоступно: §e{$maxCount}шт.\n§l§7Бесплатная передача\n§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
        $form->addDropdown("§l§fПолучатель:", $online);
        $form->addSlider("§l§fКоличество:", 1, $maxCount, 1, 1);
        $from->sendForm($form);
    }

    public static function openTransferConfirmMenu(Player $receiver, string $transferId): void {
        $mafiaSystem = Main::getInstance()->getMafiaSystem();
        $transfer = $mafiaSystem->getTransfer($transferId);
        if ($transfer === null) { $receiver->sendMessage("§c§l[Ошибка] §r§l§fПередача не найдена."); return; }
        $drugInfo = MafiaSystem::DRUGS[$transfer['drug']];
        $form = new SimpleForm(function (Player $player, ?int $data) use ($transferId, $mafiaSystem) {
            if ($data === null) { $mafiaSystem->declineTransfer($transferId, $player); return; }
            if ($data === 0) $mafiaSystem->acceptTransfer($transferId, $player);
            elseif ($data === 1) $mafiaSystem->declineTransfer($transferId, $player);
        });
        $form->setTitle("§l§ePРЕДЛОЖЕНИЕ ПЕРЕДАЧИ");
        $form->setContent(
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" .
            "§l§fОтправитель: §e{$transfer['from']}\n" .
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" .
            "§l§fТовар: {$drugInfo['name']}\n" .
            "§l§fКоличество: §e{$transfer['amount']}шт.\n" .
            "§l§fЦена: §a§lБЕСПЛАТНО\n" .
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        );
        $form->addButton("§l§aПРИНЯТЬ\n§r§l§7Получить товар");
        $form->addButton("§l§cОТКАЗАТЬСЯ\n§r§l§7Отклонить");
        $receiver->sendForm($form);
    }

    // ==================== ФОРМА УПОТРЕБЛЕНИЯ (нажатие по воздуху) ====================

    public static function openDrugUseMenu(Player $player, string $drugType): void {
        $drugInfo = MafiaSystem::DRUGS[$drugType] ?? null;
        if ($drugInfo === null) return;
        $effectsDesc = match($drugType) {
            "cocaine" => "Скорость II + Прыгучесть I (60 сек.)",
            "heroin" => "Регенерация III + Замедление I (90 сек.)",
            "meth" => "Скорость III + Сила II + Спешка II (45 сек.)",
            "weed" => "Ночное зрение + Замедление I + Голод I (120 сек.)",
            "lsd" => "Ночное зрение + Тошнота + Прыгучесть III (80 сек.)",
            "mdma" => "Поглощение III + Прыгучесть II + Скорость I (70 сек.)",
            default => "Неизвестно"
        };
        $form = new SimpleForm(function (Player $player, ?int $data) use ($drugType) {
            if ($data === null) return;
            if ($data === 0) {
                Main::getInstance()->getMafiaSystem()->useDrug($player, $drugType);
            }
        });
        $form->setTitle("§l{$drugInfo['name']}");
        $form->setContent(
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" .
            "§l§fВещество: {$drugInfo['name']}\n" .
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" .
            "§l§fЭффекты:\n" .
            "§e{$effectsDesc}\n" .
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" .
            "§c§l! Внимание: предмет будет использован !"
        );
        $form->addButton("§l§aУпотребить\n§r§l§7Применить эффекты");
        $form->addButton("§l§7Отмена\n§r§l§8Не использовать");
        $player->sendForm($form);
    }

    // ==================== МИНИ-ИГРЫ ====================

    public static function openSequenceGame(Player $player, string $drugType, array $sequence, string $sequenceStr): void {
        $len = count($sequence);
        $form = new CustomForm(function (Player $player, ?array $data) use ($drugType, $sequence) {
            if ($data === null) { Main::getInstance()->getMafiaSystem()->completeCrafting($player, $drugType, false); return; }
            $answer = trim($data[1] ?? "");
            $correct = implode("-", $sequence);
            Main::getInstance()->getMafiaSystem()->completeCrafting($player, $drugType, $answer === $correct);
        });
        $form->setTitle("§l§5ЛАБОРАТОРИЯ — Последовательность");
        $form->addLabel(
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" .
            "§l§dЭтап: Кодирование партии\n" .
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" .
            "§l§fДля маркировки партии запомните\n" .
            "§l§fследующий серийный код:\n\n" .
            "§e§l>> {$sequenceStr} <<\n\n" .
            "§l§7Количество цифр: {$len}\n" .
            "§l§7Введите через дефис: например 3-7-1-9-4\n" .
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        );
        $form->addInput("§l§fСерийный код партии:", "1-2-3-4-5");
        $player->sendForm($form);
    }

    public static function openMathGame(Player $player, string $drugType, string $question, int $answer, int $difficulty = 1): void {
        $diffName = match($difficulty) { 1 => "Простой", 2 => "Средний", 3 => "Сложный", default => "Неизвестно" };
        $form = new CustomForm(function (Player $player, ?array $data) use ($drugType, $answer) {
            if ($data === null) { Main::getInstance()->getMafiaSystem()->completeCrafting($player, $drugType, false); return; }
            $playerAnswer = (int)($data[1] ?? 0);
            Main::getInstance()->getMafiaSystem()->completeCrafting($player, $drugType, $playerAnswer === $answer);
        });
        $form->setTitle("§l§5ЛАБОРАТОРИЯ — Расчёт дозировки");
        $form->addLabel(
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" .
            "§l§dЭтап: Расчёт пропорций\n" .
            "§l§7Уровень сложности: §e{$diffName}\n" .
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" .
            "§l§fДля правильной дозировки вещества\n" .
            "§l§fрешите расчёт:\n\n" .
            "§e§l{$question} = ?\n\n" .
            "§l§7Ошибка в расчёте испортит партию!\n" .
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        );
        $form->addInput("§l§fРезультат расчёта:", "0");
        $player->sendForm($form);
    }

    public static function openReactionGame(Player $player, string $drugType, string $correct, array $colors): void {
        $form = new SimpleForm(function (Player $player, ?int $data) use ($drugType, $correct, $colors) {
            if ($data === null) { Main::getInstance()->getMafiaSystem()->completeCrafting($player, $drugType, false); return; }
            $selected = $colors[$data] ?? "";
            Main::getInstance()->getMafiaSystem()->completeCrafting($player, $drugType, $selected === $correct);
        });
        $form->setTitle("§l§5ЛАБОРАТОРИЯ — Контроль качества");
        $form->setContent(
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" .
            "§l§dЭтап: Проверка реагента\n" .
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" .
            "§l§fИндикатор показал цвет реакции.\n" .
            "§l§fДля продолжения синтеза выберите\n" .
            "§l§fправильный цвет индикатора:\n\n" .
            "§l§fЦвет реакции: {$correct}\n\n" .
            "§l§7Неверный выбор уничтожит партию!\n" .
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        );
        foreach ($colors as $color) {
            $form->addButton("§l{$color}");
        }
        $player->sendForm($form);
    }

    public static function openMemoryGame(Player $player, string $drugType, array $shown, array $items): void {
        $shownStr = implode(", ", $shown);
        $shownCount = count($shown);
        $form = new CustomForm(function (Player $player, ?array $data) use ($drugType, $shown, $items) {
            if ($data === null) { Main::getInstance()->getMafiaSystem()->completeCrafting($player, $drugType, false); return; }
            $selected = [];
            foreach ($items as $i => $item) {
                if (isset($data[$i + 1]) && $data[$i + 1] === true) $selected[] = $item;
            }
            sort($shown);
            sort($selected);
            Main::getInstance()->getMafiaSystem()->completeCrafting($player, $drugType, $shown === $selected);
        });
        $form->setTitle("§l§5ЛАБОРАТОРИЯ — Инвентаризация");
        $form->addLabel(
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" .
            "§l§dЭтап: Подбор оборудования\n" .
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" .
            "§l§fДля этой партии потребуются\n" .
            "§l§fследующие инструменты:\n\n" .
            "§e§l{$shownStr}\n\n" .
            "§l§7Отметьте ровно {$shownCount} предмета из списка.\n" .
            "§l§7Лишний или недостающий — провал!\n" .
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        );
        foreach ($items as $item) {
            $form->addToggle("§l{$item}", false);
        }
        $player->sendForm($form);
    }

    public static function openPatternGame(Player $player, string $drugType, array $pattern): void {
        $patternStr = "";
        foreach ($pattern as $row) {
            foreach ($row as $cell) {
                $patternStr .= $cell === 1 ? "§e[X]§f " : "§7[.]§f ";
            }
            $patternStr .= "\n";
        }
        $form = new CustomForm(function (Player $player, ?array $data) use ($drugType, $pattern) {
            if ($data === null) { Main::getInstance()->getMafiaSystem()->completeCrafting($player, $drugType, false); return; }
            $answer = trim($data[1] ?? "");
            $correct = implode("-", array_map(fn($row) => implode("", $row), $pattern));
            Main::getInstance()->getMafiaSystem()->completeCrafting($player, $drugType, $answer === $correct);
        });
        $form->setTitle("§l§5ЛАБОРАТОРИЯ — Молекулярная сетка");
        $form->addLabel(
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" .
            "§l§dЭтап: Кристаллическая решётка\n" .
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" .
            "§l§fВоспроизведите молекулярную\n" .
            "§l§fструктуру вещества:\n\n" .
            "{$patternStr}\n" .
            "§l§7[X] = 1, [.] = 0\n" .
            "§l§7Строки через дефис: 101-010-101\n" .
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        );
        $form->addInput("§l§fМолекулярная формула:", "101-010-101");
        $player->sendForm($form);
    }

    public static function openMixingGame(Player $player, string $drugType, array $ingredients): void {
        $shuffled = $ingredients;
        shuffle($shuffled);
        $form = new CustomForm(function (Player $player, ?array $data) use ($drugType, $ingredients, $shuffled) {
            if ($data === null) { Main::getInstance()->getMafiaSystem()->completeCrafting($player, $drugType, false); return; }
            $s1 = $shuffled[(int)($data[1] ?? 0)] ?? "";
            $s2 = $shuffled[(int)($data[2] ?? 0)] ?? "";
            $s3 = $shuffled[(int)($data[3] ?? 0)] ?? "";
            $success = ($s1 === $ingredients[0] && $s2 === $ingredients[1] && $s3 === $ingredients[2]);
            Main::getInstance()->getMafiaSystem()->completeCrafting($player, $drugType, $success);
        });
        $form->setTitle("§l§5ЛАБОРАТОРИЯ — Синтез");
        $form->addLabel(
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" .
            "§l§dЭтап: Синтез вещества\n" .
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" .
            "§l§fДобавьте реагенты в правильной\n" .
            "§l§fпоследовательности:\n\n" .
            "§e§l1) " . $ingredients[0] . "\n" .
            "§e§l2) " . $ingredients[1] . "\n" .
            "§e§l3) " . $ingredients[2] . "\n\n" .
            "§l§7Неправильный порядок = взрыв!\n" .
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        );
        $form->addDropdown("§l§fРеагент #1:", $shuffled);
        $form->addDropdown("§l§fРеагент #2:", $shuffled);
        $form->addDropdown("§l§fРеагент #3:", $shuffled);
        $player->sendForm($form);
    }
}