<?php

namespace InzeOwr\RcOrg;

use pocketmine\entity\Human;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\player\Player;
use pocketmine\math\Vector3;

class OrgNPC extends Human {

    private string $orgTag = "";

    public function initEntity(CompoundTag $nbt): void {
        parent::initEntity($nbt);
        $this->orgTag = $nbt->getString("org_tag", "");
        
        // Отключаем движение на клиенте (чтобы не дергался)
        $this->setNoClientPredictions(); 
        
        // Имя видно всегда (даже издалека)
        $this->setNameTagAlwaysVisible(true);
    }

    public function saveNBT(): CompoundTag {
        $nbt = parent::saveNBT();
        $nbt->setString("org_tag", $this->orgTag);
        return $nbt;
    }

    public function getOrgTag(): string {
        return $this->orgTag;
    }
    
    // Запрет на получение урона
    public function attack(EntityDamageEvent $source): void {
        $source->cancel(); 
    }

    // Обработка клика
    public function onInteract(Player $player, Vector3 $clickPos): bool {
        // Если тег JAIL - это тюремщик
        if ($this->orgTag === "JAIL") {
            Main::getInstance()->openJailMenu($player);
        } else {
            // Иначе - обычный NPC фракции
            Main::getInstance()->handleNpcTouch($player, $this);
        }
        return true;
    }
}