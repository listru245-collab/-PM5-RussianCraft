<?php

namespace InzeOwr\RcOrg;

use pocketmine\utils\Config;
use pocketmine\Server;
use pocketmine\player\Player;

class ProsecutorSystem {

    private Main $plugin;
    private Config $inspections;
    private Config $strikes;
    private Config $pendingStrikes;

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
        $this->inspections = new Config($plugin->getDataFolder() . "inspections.json", Config::JSON);
        $this->strikes = new Config($plugin->getDataFolder() . "org_strikes.json", Config::JSON);
        $this->pendingStrikes = new Config($plugin->getDataFolder() . "pending_strikes.json", Config::JSON);
    }

    public function isFrozen(string $orgKey): bool {
        return $this->inspections->exists($orgKey);
    }

    public function startInspection(string $orgKey, string $prosecutor): bool {
        $leaderInfo = $this->plugin->getLeaderInfo($orgKey);
        $leaderName = $leaderInfo['nick'];
        
        $leaderPlayer = Server::getInstance()->getPlayerExact($leaderName);
        if ($leaderPlayer === null && $leaderName !== "Отсутствует") {
            return false;
        }
        if ($leaderName === "Отсутствует") {
            return false; 
        }

        $this->inspections->set($orgKey, $prosecutor);
        $this->inspections->save();
        return true;
    }

    public function stopInspection(string $orgKey): void {
        $this->inspections->remove($orgKey);
        $this->inspections->save();
    }

    public function stopInspectionByPlayer(string $prosecutorName): void {
        $all = $this->inspections->getAll();
        foreach ($all as $org => $inspector) {
            if (strtolower($inspector) === strtolower($prosecutorName)) {
                $this->inspections->remove($org);
                $this->inspections->save();
                Server::getInstance()->broadcastMessage("§c§l[Городская Прокуратура] §r§l§fПроверка организации §e{$org} §fбыла прервана (Прокурор покинул город).");
            }
        }
    }

    /**
     * Получить количество выговоров
     */
    public function getStrikes(string $orgKey): int {
        $strikesData = $this->strikes->get($orgKey, []);
        if (is_array($strikesData)) {
            return count($strikesData);
        }
        return 0;
    }

    /**
     * Получить все выговоры организации (массив)
     */
    public function getStrikesData(string $orgKey): array {
        $data = $this->strikes->get($orgKey, []);
        return is_array($data) ? $data : [];
    }

    /**
     * Добавить выговор напрямую (после подтверждения)
     */
    public function addStrikeDirectly(string $orgKey, array $strikeData): void {
        $current = $this->getStrikesData($orgKey);
        $current[] = $strikeData;
        $this->strikes->set($orgKey, $current);
        $this->strikes->save();

        $count = count($current);
        $coloredOrg = $this->plugin->getColoredOrgName($orgKey);

        if ($count >= 3) {
            $leaderInfo = $this->plugin->getLeaderInfo($orgKey);
            $leaderName = $leaderInfo['nick'];
            
            if ($leaderName !== "Отсутствует") {
                $leaderRank = $this->plugin->getPlayerRank($leaderName);
                
                // Снимаем только 16 ранг (лидер), 17 ранг (админ) не трогаем
                if ($leaderRank <= 16) {
                    $this->plugin->setPlayerOrg($leaderName, null);
                }
                
                $this->plugin->setLeaderInfo($orgKey, "Отсутствует", "Должность вакантна");
                $this->strikes->set($orgKey, []);
                $this->strikes->save();
                
                Server::getInstance()->broadcastMessage("§c§l[Городская Прокуратура] §r§l§fЛидер организации {$coloredOrg} §fбыл снят за 3/3 выговоров.");
            }
        } else {
            Server::getInstance()->broadcastMessage("§c§l[Городская Прокуратура] §r§l§fОрганизация {$coloredOrg} §fполучила выговор ({$count}/3).");
            Server::getInstance()->broadcastMessage("§l§7Причина: {$strikeData['reason']}");
        }
    }

    /**
     * Удалить выговор по индексу
     */
    public function removeStrike(string $orgKey, int $index): bool {
        $current = $this->getStrikesData($orgKey);
        if (!isset($current[$index])) {
            return false;
        }
        array_splice($current, $index, 1);
        $this->strikes->set($orgKey, $current);
        $this->strikes->save();
        return true;
    }

    /**
     * Генерация уникального короткого ID (1 буква + 4 цифры)
     */
    private function generateUniqueId(): string {
        do {
            $id = chr(rand(65, 90)) . str_pad((string)rand(0, 9999), 4, "0", STR_PAD_LEFT);
        } while ($this->getPendingStrike($id) !== null);
        return $id;
    }

    /**
     * Создать запрос на выговор (ожидает подтверждения)
     */
    public function createPendingStrike(string $orgKey, array $strikeData): string {
        $id = $this->generateUniqueId();
        $strikeData['org'] = $orgKey;
        $strikeData['id'] = $id;
        $strikeData['created_at'] = date("d.m.Y H:i:s");
        
        $pending = $this->pendingStrikes->getAll();
        $pending[$id] = $strikeData;
        $this->pendingStrikes->setAll($pending);
        $this->pendingStrikes->save();
        
        return $id;
    }

    /**
     * Получить ожидающий выговор
     */
    public function getPendingStrike(string $id): ?array {
        return $this->pendingStrikes->get($id, null);
    }

    /**
     * Получить все ожидающие выговоры
     */
    public function getAllPendingStrikes(): array {
        return $this->pendingStrikes->getAll();
    }

    /**
     * Подтвердить выговор
     */
    public function confirmPendingStrike(string $id, string $confirmedBy): bool {
    $strike = $this->getPendingStrike($id);
    if ($strike === null) {
        return false;
    }

    $orgKey = $strike['org'];
    $strike['confirmed_by'] = $confirmedBy;
    $strike['confirmed_at'] = date("d.m.Y H:i:s");
    
    unset($strike['id']);
    unset($strike['org']);
    
    $this->addStrikeDirectly($orgKey, $strike);
    
    // Логируем выговор
    $count = $this->getStrikes($orgKey);
    $prosecutor = $strike['prosecutor'] ?? "Неизвестен";
    $reason = $strike['reason'] ?? "Не указана";
    $rating = $strike['rating'] ?? 0;
    
    $this->plugin->addLog($orgKey, "§4§lВЫГОВОР ({$count}/3): §c§l{$prosecutor} §6§l— Оценка: §e§l{$rating}/10 §6§l— Причина: §e§l{$reason} §6§l— Подтвердил: §c§l{$confirmedBy}");
    
    $this->pendingStrikes->remove($id);
    $this->pendingStrikes->save();
    
    return true;
}
    /**
     * Отклонить выговор
     */
    public function denyPendingStrike(string $id, string $deniedBy, string $denyReason): bool {
        $strike = $this->getPendingStrike($id);
        if ($strike === null) {
            return false;
        }

        $orgKey = $strike['org'];
        $prosecutor = $strike['prosecutor'] ?? "Неизвестен";
        $coloredOrg = $this->plugin->getColoredOrgName($orgKey);
        $reason = $strike['reason'] ?? "Не указана";
        
        $msg = [];
        $msg[] = "§e§l[Городская Прокуратура] §r§l§fВыговор организации {$coloredOrg} §fотклонён.";
        $msg[] = "§l§fПрокурор: §7{$prosecutor}";
        $msg[] = "§l§fПричина выговора: §7{$reason}";
        $msg[] = "§l§fОтклонил: §e{$deniedBy}";
        $msg[] = "§l§fПричина отклонения: §c{$denyReason}";
        
        foreach (Server::getInstance()->getOnlinePlayers() as $player) {
            $playerOrg = $this->plugin->getPlayerOrg($player->getName());
            if ($playerOrg === "GP") {
                foreach ($msg as $line) {
                    $player->sendMessage($line);
                }
            }
        }
        
        $admins = $this->getOnlineAdmins();
        foreach ($admins as $admin) {
            $adminOrg = $this->plugin->getPlayerOrg($admin->getName());
            if ($adminOrg !== "GP") {
                foreach ($msg as $line) {
                    $admin->sendMessage($line);
                }
            }
        }
        
        $this->pendingStrikes->remove($id);
        $this->pendingStrikes->save();
        
        return true;
    }

    /**
     * Получить онлайн админов
     */
    public function getOnlineAdmins(): array {
        $admins = [];
        $allowedGroups = ["ADMIN", "SADMIN", "CURATOR", "GLADMIN", "MANAGER", "OWNER", "CREATOR"];
        
        $rcGroup = Server::getInstance()->getPluginManager()->getPlugin("RcGroup");
        if ($rcGroup === null || !$rcGroup->isEnabled()) {
            return $admins;
        }

        foreach (Server::getInstance()->getOnlinePlayers() as $player) {
            $group = $rcGroup->getGroup($player->getName());
            if (in_array(strtoupper($group), $allowedGroups)) {
                $admins[] = $player;
            }
        }
        
        return $admins;
    }

    /**
     * Получить онлайн старших админов (для 3/3)
     */
    public function getOnlineSeniorAdmins(): array {
        $admins = [];
        $allowedGroups = ["CURATOR", "GLADMIN", "MANAGER", "OWNER", "CREATOR"];
        
        $rcGroup = Server::getInstance()->getPluginManager()->getPlugin("RcGroup");
        if ($rcGroup === null || !$rcGroup->isEnabled()) {
            return $admins;
        }

        foreach (Server::getInstance()->getOnlinePlayers() as $player) {
            $group = $rcGroup->getGroup($player->getName());
            if (in_array(strtoupper($group), $allowedGroups)) {
                $admins[] = $player;
            }
        }
        
        return $admins;
    }

    /**
     * Может ли игрок подтверждать обычные выговоры
     */
    public function canConfirmStrike(Player $player): bool {
        $allowedGroups = ["ADMIN", "SADMIN", "CURATOR", "GLADMIN", "MANAGER", "OWNER", "CREATOR"];
        
        $rcGroup = Server::getInstance()->getPluginManager()->getPlugin("RcGroup");
        if ($rcGroup === null || !$rcGroup->isEnabled()) {
            return false;
        }

        $group = $rcGroup->getGroup($player->getName());
        return in_array(strtoupper($group), $allowedGroups);
    }

    /**
     * Может ли игрок подтверждать 3/3 выговор
     */
    public function canConfirmThirdStrike(Player $player): bool {
        $allowedGroups = ["CURATOR", "GLADMIN", "MANAGER", "OWNER", "CREATOR"];
        
        $rcGroup = Server::getInstance()->getPluginManager()->getPlugin("RcGroup");
        if ($rcGroup === null || !$rcGroup->isEnabled()) {
            return false;
        }

        $group = $rcGroup->getGroup($player->getName());
        return in_array(strtoupper($group), $allowedGroups);
    }

    /**
     * Уведомить админов о новом выговоре
     */
    public function notifyAdmins(string $id, bool $isThirdStrike = false): void {
        $strike = $this->getPendingStrike($id);
        if ($strike === null) return;

        $orgKey = $strike['org'];
        $reason = $strike['reason'];
        $prosecutor = $strike['prosecutor'] ?? "Неизвестен";
        $rating = $strike['rating'] ?? 0;
        $coloredOrg = $this->plugin->getColoredOrgName($orgKey);
        
        $admins = $isThirdStrike ? $this->getOnlineSeniorAdmins() : $this->getOnlineAdmins();
        
        $currentStrikes = $this->getStrikes($orgKey);
        $willBe = $currentStrikes + 1;
        
        foreach ($admins as $admin) {
            $admin->sendMessage("§c§l━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
            $admin->sendMessage("§c§l[!] ЗАПРОС НА ВЫГОВОР");
            $admin->sendMessage("§l§fОрганизация: {$coloredOrg}");
            $admin->sendMessage("§l§fВыговор: §e{$willBe}/3" . ($isThirdStrike ? " §4[СНЯТИЕ ЛИДЕРА!]" : ""));
            $admin->sendMessage("§l§fПрокурор: §e{$prosecutor}");
            $admin->sendMessage("§l§fОценка: §e{$rating}/10");
            $admin->sendMessage("§l§fПричина: §7{$reason}");
            $admin->sendMessage("§e§l/rcproverkaorg yes {$id} §r§l§f— подтвердить");
            $admin->sendMessage("§e§l/rcproverkaorg no {$id} <причина> §r§l§f— отклонить");
            $admin->sendMessage("§c§l━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
        }
        
        if (empty($admins)) {
            $prosecutorPlayer = Server::getInstance()->getPlayerExact($strike['prosecutor'] ?? "");
            if ($prosecutorPlayer !== null) {
                $prosecutorPlayer->sendMessage("§e§l[Городская Прокуратура] §r§l§fЗапрос на выговор создан. Ожидайте подтверждения администратора.");
            }
        }
    }
}