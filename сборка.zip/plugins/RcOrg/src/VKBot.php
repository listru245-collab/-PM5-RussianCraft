<?php

namespace InzeOwr\RcOrg;

use pocketmine\Server;
use pocketmine\scheduler\AsyncTask;

class VKBot {

    private string $token;
    private int $chatId;

    public function __construct(string $token, int $chatId) {
        $this->token = $token;
        $this->chatId = $chatId;
    }

    public function sendMessage(string $message): void {
        if (empty($this->token) || $this->chatId === 0) return;

        $url = "https://api.vk.com/method/messages.send";
        $params = [
            'access_token' => $this->token,
            // ИСПРАВЛЕНО: Теперь берется чистый ID из конфига
            'peer_id' => $this->chatId, 
            'message' => $message,
            'random_id' => rand(0, 999999),
            'v' => '5.131'
        ];

        $serializedParams = serialize($params);

        Server::getInstance()->getAsyncPool()->submitTask(new class($url, $serializedParams) extends AsyncTask {
            private string $url;
            private string $serializedParams;

            public function __construct(string $url, string $serializedParams) {
                $this->url = $url;
                $this->serializedParams = $serializedParams;
            }

            public function onRun(): void {
                $params = unserialize($this->serializedParams);

                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL, $this->url);
                curl_setopt($ch, CURLOPT_POST, 1);
                curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($params));
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                $result = curl_exec($ch);
                curl_close($ch);
            }
        });
    }
}