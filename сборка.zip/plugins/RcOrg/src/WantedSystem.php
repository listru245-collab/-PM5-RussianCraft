<?php

namespace InzeOwr\RcOrg;

use pocketmine\player\Player;
use pocketmine\Server;
use pocketmine\utils\Config;
use jojoe77777\FormAPI\CustomForm;

class WantedSystem {

    private Main $plugin;
    private Config $wanted;

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
        $this->wanted = new Config($plugin->getDataFolder() . "wanted.json", Config::JSON);
    }

    public function addStars(string $targetName, int $amount, string $reason, ?Player $officer = null): void {
        $name = strtolower($targetName);
        $current = $this->wanted->get($name, 0);
        $new = $current + $amount;
        if ($new > 7) $new = 7;
        
        $this->wanted->set($name, $new);
        $this->wanted->save();

        $officerName = $officer ? $officer->getName() : "Система";
        $officerInfo = "";
        $color = "f";
        
        if ($officer) {
            $org = $this->plugin->getPlayerOrg($officer->getName());
            $rank = $this->plugin->getPlayerRank($officer->getName());
            $rankName = $this->plugin->getRankName($org, $rank);
            $orgName = $this->plugin->getOrgName($org);
            $color = $this->plugin->getOrgColor($org);
            $coloredOrg = $this->plugin->getColoredOrgName($org);
            $officerInfo = "{$rankName} {$officerName} ({$coloredOrg}§l§{$color})";
        } else {
            $officerInfo = "§c[СИСТЕМА]";
            $color = "c";
        }

        $msg = "§l§{$color}{$officerInfo} §r§l§fобъявил в розыск гражданина §e{$targetName} §f(§c{$new}★§f). Причина: §7{$reason}";
        
        foreach (Server::getInstance()->getOnlinePlayers() as $p) {
            $pOrg = $this->plugin->getPlayerOrg($p->getName());
            if ($pOrg !== null && $pOrg !== "MF") $p->sendMessage($msg);
        }
        
        $t = Server::getInstance()->getPlayerExact($targetName);
        if ($t) {
            $t->sendMessage("§c§l[РОЗЫСК] §r§l§fВам выдано §e{$amount} §fуровень розыска! Текущий: §c{$new}★§f.");
            $t->sendMessage("§l§fПричина: §7{$reason}");
            if ($officer) {
                $org = $this->plugin->getPlayerOrg($officer->getName());
                $rankName = $this->plugin->getRankName($org, $this->plugin->getPlayerRank($officer->getName()));
                $coloredOrg = $this->plugin->getColoredOrgName($org);
                $t->sendMessage("§l§fСотрудник: §e{$rankName} {$officer->getName()} §7({$coloredOrg}§7)");
            }
        }

        if ($officer) {
            $officer->sendMessage("§a§l[Розыск] §r§l§fГражданин §e{$targetName} §fобъявлен в розыск (§c{$new}★§f). Причина: §7{$reason}");
            $org = $this->plugin->getPlayerOrg($officer->getName());
            if ($org) {
                $this->plugin->addLog($org, "Сотрудник {$officer->getName()} объявил {$targetName} в розыск ({$new}★). Причина: {$reason}");
            }
        }
    }

    public function getStars(string $name): int {
        return $this->wanted->get(strtolower($name), 0);
    }

    public function clearStars(string $name): void {
        $this->wanted->remove(strtolower($name));
        $this->wanted->save();
    }
    
    public function hasStars(string $name): bool {
        return $this->getStars($name) > 0;
    }

    public function openWantedMenu(Player $officer): void {
    $online = [];
    foreach(Server::getInstance()->getOnlinePlayers() as $p) {
        if ($p->getName() !== $officer->getName()) {
            $online[] = $p->getName();
        }
    }

    if (empty($online)) {
        $officer->sendMessage("§c§l[Розыск] §r§l§fНа сервере нет других игроков.");
        return;
    }

    $form = new CustomForm(function (Player $player, $data) use ($online) {
        if ($data === null) return;
        
        $action = (int)($data[0] ?? 0);
        $targetIndex = (int)($data[1] ?? 0);
        
        if (!isset($online[$targetIndex])) return;
        $targetName = $online[$targetIndex];

        if ($action === 0) {
            // Выдать розыск
            $stars = (int)($data[2] ?? 1);
            $reason = trim($data[3] ?? "");

            if (empty($reason)) {
                $player->sendMessage("§c§l[Ошибка] §r§l§fУкажите причину розыска.");
                return;
            }
            
            if (Main::getInstance()->getImmunitySystem()->hasImmunity($targetName)) {
                $player->sendMessage("§c§l[Ошибка] §r§l§fУ гражданина §e{$targetName} §fдействует статус неприкосновенности!");
                return;
            }
            
            $tOrg = Main::getInstance()->getPlayerOrg($targetName);
            $tRank = Main::getInstance()->getPlayerRank($targetName);
            if ($tOrg !== null && $tOrg !== "MF" && $tRank >= 15) {
                 $player->sendMessage("§c§l[Ошибка] §r§l§fЗапрещено объявлять в розыск руководство гос. структур.");
                 return;
            }

            $this->addStars($targetName, $stars, $reason, $player);
            
        } elseif ($action === 1) {
            // Снять розыск
            if (!$this->hasStars($targetName)) {
                $player->sendMessage("§c§l[Розыск] §r§l§fУ гражданина нет звёзд розыска.");
                return;
            }
            
            $this->clearStars($targetName);
            $player->sendMessage("§a§l[Розыск] §r§l§fРозыск с гражданина §e{$targetName} §fснят.");
            
            $target = Server::getInstance()->getPlayerExact($targetName);
            if ($target) {
                $target->sendMessage("§a§l[Розыск] §r§l§fС вас снят розыск сотрудником правоохранительных органов.");
            }
            
            $org = Main::getInstance()->getPlayerOrg($player->getName());
            if ($org) {
                Main::getInstance()->addLog($org, "§c§l{$player->getName()} §6§lснял розыск с §b§l{$targetName}");
            }
        }
    });

    $form->setTitle("§l§9УПРАВЛЕНИЕ РОЗЫСКОМ");
    $form->addDropdown("§l§fДействие:", ["Выдать розыск", "Снять розыск"]);
    $form->addDropdown("§l§fВыберите гражданина:", $online);
    $form->addSlider("§l§fКоличество звезд:", 1, 7, 1, 1);
    $form->addInput("§l§fПричина:", "Убийство, нападение на сотрудника...");
    $officer->sendForm($form);
}
}