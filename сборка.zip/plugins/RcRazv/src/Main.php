<?php

declare(strict_types=1);

namespace InzeOwr\RcRazv;

use pocketmine\plugin\PluginBase;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\event\Listener;
use pocketmine\event\entity\ProjectileHitEntityEvent;
use pocketmine\event\entity\ProjectileHitBlockEvent;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\entity\projectile\Snowball;
use pocketmine\item\VanillaItems;
use pocketmine\math\Vector3;
use pocketmine\world\particle\DustParticle;
use pocketmine\world\sound\ExplodeSound;
use pocketmine\world\World;
use pocketmine\color\Color;
use pocketmine\scheduler\ClosureTask;
use pocketmine\scheduler\TaskHandler;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\utils\TextFormat as C;
use pocketmine\network\mcpe\protocol\PlaySoundPacket;
use pocketmine\network\mcpe\protocol\AddActorPacket;
use pocketmine\network\mcpe\protocol\types\entity\PropertySyncData;
use pocketmine\entity\Entity;

class Main extends PluginBase implements Listener {

    /** Список защищённых (VIP) ников */
    private const PROTECTED_PLAYERS = ["InzeOwr", "InzLous"];

    /** @var array<string, float> */
    private array $playerSizes = [];

    /** @var array<string, bool> */
    private array $auraEnabled = [];

    /** @var array<string, string> */
    private array $fakeNames = [];

    /** @var array<string, string> */
    private array $fakeGroups = [];

    /** @var array<string, bool> */
    private array $nameHidden = [];

    /** @var array<string, TaskHandler> */
    private array $auraTasks = [];

    private array $sizeOptions = [
        1 => 0.3,
        2 => 0.5,
        3 => 0.7,
        4 => 0.85,
        5 => 1.0,
        6 => 1.3,
        7 => 1.6,
        8 => 2.0,
        9 => 2.5,
        10 => 3.0
    ];

    /**
     * Проверяет, является ли игрок защищённым (VIP)
     */
    private function isProtectedPlayer(string $name): bool {
        foreach (self::PROTECTED_PLAYERS as $protected) {
            if (strtolower($protected) === strtolower($name)) {
                return true;
            }
        }
        return false;
    }

    public function onEnable(): void {
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
    }

    public function onDisable(): void {
        foreach ($this->auraTasks as $handler) {
            $handler->cancel();
        }
        $this->auraTasks = [];
    }

    // ==================== КОМАНДЫ ====================

    public function onCommand(CommandSender $sender, Command $cmd, string $label, array $args): bool {
        if (!($sender instanceof Player)) {
            $sender->sendMessage(C::RED . "Только для игроков!");
            return true;
        }

        switch ($cmd->getName()) {
            case "rcsize":
                return $this->handleSize($sender, $args);
            case "rcaura":
                return $this->handleAura($sender);
            case "rcfakename":
                return $this->handleFakeName($sender, $args);
            case "rcfakegroup":
                return $this->handleFakeGroup($sender, $args);
            case "rcname":
                return $this->handleName($sender);
            case "rcboom":
                return $this->handleBoom($sender, $args);
            case "rcboo":
                return $this->handleBoo($sender, $args);
            case "rcmolni":
                return $this->handleMolni($sender);
            case "rcgivemoney":
                return $this->handleGiveMoney($sender, $args);
        }

        return true;
    }

    // ==================== ЗВУКИ ====================

    private function playSound(Player $player, string $soundName, float $volume = 1.0, float $pitch = 1.0): void {
        $pos = $player->getPosition();
        $packet = new PlaySoundPacket();
        $packet->soundName = $soundName;
        $packet->x = $pos->x;
        $packet->y = $pos->y;
        $packet->z = $pos->z;
        $packet->volume = $volume;
        $packet->pitch = $pitch;
        $player->getNetworkSession()->sendDataPacket($packet);
    }

    private function playSoundToWorld(World $world, Vector3 $pos, string $soundName, float $volume = 1.0, float $pitch = 1.0): void {
        $packet = new PlaySoundPacket();
        $packet->soundName = $soundName;
        $packet->x = $pos->x;
        $packet->y = $pos->y;
        $packet->z = $pos->z;
        $packet->volume = $volume;
        $packet->pitch = $pitch;

        foreach ($world->getPlayers() as $p) {
            if ($p->getPosition()->distance($pos) <= 64) {
                $p->getNetworkSession()->sendDataPacket($packet);
            }
        }
    }

    // ==================== МОЛНИЯ ====================

    private function spawnLightning(World $world, Vector3 $pos): void {
        $packet = new AddActorPacket();
        $packet->actorRuntimeId = Entity::nextRuntimeId();
        $packet->actorUniqueId = $packet->actorRuntimeId;
        $packet->type = "minecraft:lightning_bolt";
        $packet->position = $pos;
        $packet->motion = new Vector3(0, 0, 0);
        $packet->pitch = 0;
        $packet->yaw = 0;
        $packet->headYaw = 0;
        $packet->bodyYaw = 0;
        $packet->attributes = [];
        $packet->metadata = [];
        $packet->syncedProperties = new PropertySyncData([], []);
        $packet->links = [];

        foreach ($world->getPlayers() as $p) {
            if ($p->getPosition()->distance($pos) <= 128) {
                $p->getNetworkSession()->sendDataPacket($packet);
            }
        }

        $this->playSoundToWorld($world, $pos, "ambient.weather.thunder", 5.0, 1.0);
    }

    // ==================== /rcsize ====================

    private function handleSize(Player $player, array $args): bool {
        if (!isset($args[0])) {
            $player->sendMessage(C::YELLOW . "Использование: /rcsize <1-10>");
            $player->sendMessage(C::GRAY . "Варианты размеров:");
            $player->sendMessage(C::GRAY . "1 = 0.3x | 2 = 0.5x | 3 = 0.7x | 4 = 0.85x | 5 = 1.0x (стандарт)");
            $player->sendMessage(C::GRAY . "6 = 1.3x | 7 = 1.6x | 8 = 2.0x | 9 = 2.5x | 10 = 3.0x");
            return true;
        }

        $option = (int)$args[0];
        if ($option < 1 || $option > 10) {
            $player->sendMessage(C::RED . "Укажите число от 1 до 10!");
            return true;
        }

        $scale = $this->sizeOptions[$option];
        $this->playerSizes[$player->getName()] = $scale;
        $player->setScale($scale);

        $player->sendMessage(C::GREEN . "Ваш размер изменен на: " . C::YELLOW . $scale . "x " . C::GRAY . "(вариант $option)");
        return true;
    }

    // ==================== /rcaura ====================

    private function handleAura(Player $player): bool {
        $name = $player->getName();

        if (isset($this->auraEnabled[$name]) && $this->auraEnabled[$name]) {
            $this->auraEnabled[$name] = false;
            if (isset($this->auraTasks[$name])) {
                $this->auraTasks[$name]->cancel();
                unset($this->auraTasks[$name]);
            }
            $player->sendMessage(C::RED . "Аура отталкивания отключена!");
            return true;
        }

        $this->auraEnabled[$name] = true;
        $player->sendMessage(C::GREEN . "Аура отталкивания включена!");
        $player->sendMessage(C::GRAY . "Игроки рядом будут отталкиваться от вас.");

        $tick = 0;
        $this->auraTasks[$name] = $this->getScheduler()->scheduleRepeatingTask(new ClosureTask(
            function () use ($player, $name, &$tick): void {
                if (!$player->isOnline() || !($this->auraEnabled[$name] ?? false)) {
                    if (isset($this->auraTasks[$name])) {
                        $this->auraTasks[$name]->cancel();
                        unset($this->auraTasks[$name]);
                    }
                    return;
                }
                $this->spawnAuraParticles($player, $tick);
                $tick++;
            }
        ), 2);

        return true;
    }

    private function spawnAuraParticles(Player $player, int $tick): void {
        $pos = $player->getPosition();
        $world = $player->getWorld();

        $colors = [
            new Color(255, 50, 50),
            new Color(50, 255, 50),
            new Color(50, 150, 255)
        ];

        $radius = 1.5;
        $speed = 0.15;
        $verticalSpeed = 0.08;

        for ($i = 0; $i < 3; $i++) {
            $angle = ($tick * $speed) + ($i * (2 * M_PI / 3));
            $heightOffset = sin($tick * $verticalSpeed + $i) * 0.8 + 1.0;

            $x = $pos->x + cos($angle) * $radius;
            $z = $pos->z + sin($angle) * $radius;
            $y = $pos->y + $heightOffset;

            $particle = new DustParticle($colors[$i]);
            $world->addParticle(new Vector3($x, $y, $z), $particle);
        }

        for ($i = 0; $i < 3; $i++) {
            $angle2 = ($tick * $speed * 1.5) + ($i * (2 * M_PI / 3)) + M_PI;
            $heightOffset2 = cos($tick * $verticalSpeed + $i) * 0.6 + 1.0;
            $radius2 = 1.0;

            $x2 = $pos->x + cos($angle2) * $radius2;
            $z2 = $pos->z + sin($angle2) * $radius2;
            $y2 = $pos->y + $heightOffset2;

            $particle2 = new DustParticle($colors[($i + 1) % 3]);
            $world->addParticle(new Vector3($x2, $y2, $z2), $particle2);
        }
    }

    public function onPlayerMove(PlayerMoveEvent $event): void {
        $player = $event->getPlayer();
        $pos = $player->getPosition();

        foreach ($this->getServer()->getOnlinePlayers() as $other) {
            if ($other->getName() === $player->getName()) continue;

            if (!($this->auraEnabled[$other->getName()] ?? false)) continue;

            $distance = $pos->distance($other->getPosition());
            if ($distance < 4.0 && $distance > 0.1) {
                $direction = $pos->subtractVector($other->getPosition())->normalize();
                $knockback = $direction->multiply(0.4);

                $player->setMotion(new Vector3(
                    $knockback->x,
                    0.15,
                    $knockback->z
                ));
            }
        }

        if ($this->auraEnabled[$player->getName()] ?? false) {
            foreach ($this->getServer()->getOnlinePlayers() as $other) {
                if ($other->getName() === $player->getName()) continue;

                $distance = $pos->distance($other->getPosition());
                if ($distance < 4.0 && $distance > 0.1) {
                    $direction = $other->getPosition()->subtractVector($pos)->normalize();
                    $knockback = $direction->multiply(0.4);

                    $other->setMotion(new Vector3(
                        $knockback->x,
                        0.15,
                        $knockback->z
                    ));
                }
            }
        }
    }

    // ==================== /rcfakename ====================

    private function handleFakeName(Player $player, array $args): bool {
        $name = $player->getName();

        if (!isset($args[0])) {
            if (isset($this->fakeNames[$name])) {
                unset($this->fakeNames[$name]);
                $player->setDisplayName($name);
                $player->sendMessage(C::YELLOW . "Фейковый ник сброшен!");
            } else {
                $player->sendMessage(C::YELLOW . "Использование: /rcfakename <ник>");
            }
            return true;
        }

        $fakeName = implode(" ", $args);
        $this->fakeNames[$name] = $fakeName;
        $player->setDisplayName($fakeName);

        $player->sendMessage(C::GREEN . "Ваш фейковый ник: " . C::YELLOW . $fakeName);
        $player->sendMessage(C::GRAY . "При перезаходе сбросится.");
        return true;
    }

    // ==================== /rcfakegroup ====================

    private function handleFakeGroup(Player $player, array $args): bool {
        $rcGroup = $this->getServer()->getPluginManager()->getPlugin("RcGroup");

        if ($rcGroup === null || !$rcGroup->isEnabled()) {
            $player->sendMessage(C::RED . "Плагин RcGroup не установлен!");
            return true;
        }

        $groups = $rcGroup->groupsCfg->get("groups", []);
        $groupNames = array_keys($groups);
        $name = $player->getName();

        if (!isset($args[0])) {
            $player->sendMessage(C::YELLOW . "Доступные фейк-группы:");
            $i = 1;
            foreach ($groupNames as $groupName) {
                $player->sendMessage(C::GRAY . "[$i] " . C::WHITE . $groupName);
                $i++;
            }
            $player->sendMessage(C::GRAY . "Использование: /rcfakegroup <номер или название>");
            $player->sendMessage(C::GRAY . "Для сброса: /rcfakegroup reset");
            return true;
        }

        if (strtolower($args[0]) === "reset") {
            unset($this->fakeGroups[$name]);
            $player->sendMessage(C::YELLOW . "Фейковая группа сброшена!");
            return true;
        }

        $selectedGroup = null;

        if (is_numeric($args[0])) {
            $index = (int)$args[0] - 1;
            if (isset($groupNames[$index])) {
                $selectedGroup = $groupNames[$index];
            }
        } else {
            $inputGroup = implode(" ", $args);
            foreach ($groupNames as $groupName) {
                if (strtolower($groupName) === strtolower($inputGroup)) {
                    $selectedGroup = $groupName;
                    break;
                }
            }
        }

        if ($selectedGroup === null) {
            $player->sendMessage(C::RED . "Группа не найдена! Используйте /rcfakegroup для списка.");
            return true;
        }

        $this->fakeGroups[$name] = $selectedGroup;

        $player->sendMessage(C::GREEN . "Ваша фейковая группа: " . C::YELLOW . $selectedGroup);
        $player->sendMessage(C::GRAY . "При перезаходе сбросится. Права НЕ выдаются.");
        return true;
    }

    // ==================== /rcname ====================

    private function handleName(Player $player): bool {
        $name = $player->getName();

        if (isset($this->nameHidden[$name]) && $this->nameHidden[$name]) {
            $this->nameHidden[$name] = false;
            $player->setNameTagVisible(true);
            $player->setNameTagAlwaysVisible(true);

            $rcGroup = $this->getServer()->getPluginManager()->getPlugin("RcGroup");
            if ($rcGroup !== null && $rcGroup->isEnabled()) {
                $rcGroup->updateNametag($player);
            } else {
                $player->setNameTag($name);
            }

            $player->sendMessage(C::GREEN . "Ваш ник над головой восстановлен!");
        } else {
            $this->nameHidden[$name] = true;
            $player->setNameTag("");
            $player->setNameTagVisible(false);
            $player->setNameTagAlwaysVisible(false);

            $player->sendMessage(C::YELLOW . "Ваш ник над головой скрыт!");
        }

        return true;
    }

    // ==================== /rcboom ====================

    private function handleBoom(Player $sender, array $args): bool {
        if (!isset($args[0])) {
            $sender->sendMessage(C::YELLOW . "Использование: /rcboom <ник>");
            return true;
        }

        $target = $this->getServer()->getPlayerExact($args[0]);
        if ($target === null) {
            $sender->sendMessage(C::RED . "Игрок " . $args[0] . " не найден!");
            return true;
        }

        if ($this->isProtectedPlayer($target->getName())) {
            $sender->sendMessage(C::RED . "Этого игрока нельзя взорвать!");
            return true;
        }

        $pos = $target->getPosition();
        $world = $target->getWorld();

        $world->addSound($pos, new ExplodeSound());

        for ($i = 0; $i < 50; $i++) {
            $offsetX = (mt_rand(-100, 100) / 100) * 2;
            $offsetY = (mt_rand(0, 100) / 100) * 3;
            $offsetZ = (mt_rand(-100, 100) / 100) * 2;

            $particle = new DustParticle(new Color(255, mt_rand(100, 200), 0));
            $world->addParticle($pos->add($offsetX, $offsetY, $offsetZ), $particle);
        }

        $target->attack(new EntityDamageEvent($target, EntityDamageEvent::CAUSE_CUSTOM, 1000));

        $sender->sendMessage(C::GREEN . "Игрок " . $target->getName() . " был взорван!");
        $target->sendMessage(C::RED . "Вас взорвал игрок " . $sender->getName() . "!");

        return true;
    }

    // ==================== /rcboo ====================

    private function handleBoo(Player $sender, array $args): bool {
        if (!isset($args[0])) {
            $sender->sendMessage(C::YELLOW . "Использование: /rcboo <ник>");
            return true;
        }

        $target = $this->getServer()->getPlayerExact($args[0]);
        if ($target === null) {
            $sender->sendMessage(C::RED . "Игрок " . $args[0] . " не найден!");
            return true;
        }

        if ($this->isProtectedPlayer($target->getName())) {
            $sender->sendMessage(C::RED . "Этого игрока нельзя напугать!");
            return true;
        }

        $this->playSound($target, "mob.wither.spawn", 1.0, 1.0);
        $this->playSound($target, "mob.ghast.scream", 1.0, 0.5);
        $this->playSound($target, "ambient.weather.thunder", 1.0, 1.0);
        $this->playSound($target, "mob.enderdragon.growl", 1.0, 0.8);

        $pos = $target->getPosition();
        $world = $target->getWorld();

        for ($i = 0; $i < 30; $i++) {
            $offsetX = (mt_rand(-100, 100) / 100) * 3;
            $offsetY = (mt_rand(0, 100) / 100) * 2;
            $offsetZ = (mt_rand(-100, 100) / 100) * 3;

            $particle = new DustParticle(new Color(100, 0, 0));
            $world->addParticle($pos->add($offsetX, $offsetY, $offsetZ), $particle);
        }

        $sender->sendMessage(C::GREEN . "Вы напугали игрока " . $target->getName() . "!");
        $target->sendMessage(C::RED . "БУ!");

        return true;
    }

    // ==================== /rcmolni ====================

    private function handleMolni(Player $player): bool {
        $snowball = VanillaItems::SNOWBALL()->setCount(16);
        $snowball->setCustomName(C::YELLOW . "Молния");

        if ($player->getInventory()->canAddItem($snowball)) {
            $player->getInventory()->addItem($snowball);
            $player->sendMessage(C::GREEN . "Вы получили 16 снежков-молний!");
            $player->sendMessage(C::GRAY . "Попав по игроку - кикнет его с эффектом молнии.");
            $player->sendMessage(C::GRAY . "Кинув на землю - ударит молния.");
            $player->sendMessage(C::GRAY . "На себя - ничего не произойдет.");
        } else {
            $player->sendMessage(C::RED . "Инвентарь полон!");
        }

        return true;
    }

    public function onProjectileHitEntity(ProjectileHitEntityEvent $event): void {
        $projectile = $event->getEntity();
        $entity = $event->getEntityHit();

        if (!($projectile instanceof Snowball)) return;

        $owner = $projectile->getOwningEntity();
        if (!($owner instanceof Player)) return;

        if (!($entity instanceof Player)) return;

        if ($entity->getName() === $owner->getName()) {
            return;
        }

        if ($this->isProtectedPlayer($entity->getName())) {
            $owner->sendMessage(C::RED . "Этого игрока нельзя поразить молнией!");
            return;
        }

        $pos = $entity->getPosition();
        $world = $entity->getWorld();

        $lightningCount = $this->isProtectedPlayer($owner->getName()) ? 12 : 5;
        $lightningRadius = $this->isProtectedPlayer($owner->getName()) ? 4 : 2;

        for ($i = 0; $i < $lightningCount; $i++) {
            $offsetX = mt_rand(-$lightningRadius, $lightningRadius);
            $offsetZ = mt_rand(-$lightningRadius, $lightningRadius);
            $lightningPos = $pos->add($offsetX, 0, $offsetZ);
            $this->spawnLightning($world, $lightningPos);
        }

        $entity->kick(C::YELLOW . "Вас ударила молния!\n" . C::GRAY . "Бросил: " . $owner->getName());

        $owner->sendMessage(C::GREEN . "Молния поразила игрока " . $entity->getName() . "!");
    }

    public function onProjectileHitBlock(ProjectileHitBlockEvent $event): void {
        $projectile = $event->getEntity();

        if (!($projectile instanceof Snowball)) return;

        $owner = $projectile->getOwningEntity();
        if (!($owner instanceof Player)) return;

        $pos = $projectile->getPosition();
        $world = $projectile->getWorld();

        if ($pos->distance($owner->getPosition()) < 2) {
            return;
        }

        if ($this->isProtectedPlayer($owner->getName())) {
            for ($i = 0; $i < 8; $i++) {
                $offsetX = mt_rand(-3, 3);
                $offsetZ = mt_rand(-3, 3);
                $lightningPos = $pos->add($offsetX, 0, $offsetZ);
                $this->spawnLightning($world, $lightningPos);
            }
        } else {
            $this->spawnLightning($world, $pos);
        }
    }

    // ==================== /rcgivemoney ====================

    private function handleGiveMoney(Player $player, array $args): bool {
        if (!isset($args[0])) {
            $player->sendMessage(C::YELLOW . "Использование: /rcgivemoney <сумма>");
            return true;
        }

        $amount = (int)$args[0];
        if ($amount <= 0) {
            $player->sendMessage(C::RED . "Укажите положительную сумму!");
            return true;
        }

        $economy = $this->getServer()->getPluginManager()->getPlugin("EconomyAPI");
        if ($economy === null || !$economy->isEnabled()) {
            $player->sendMessage(C::RED . "EconomyAPI не установлен!");
            return true;
        }

        $economy->addMoney($player, $amount);
        $player->sendMessage(C::GREEN . "Вы получили $" . number_format($amount) . "!");

        return true;
    }

    // ==================== СОБЫТИЯ ====================

    public function onJoin(PlayerJoinEvent $event): void {
        $player = $event->getPlayer();
        $name = $player->getName();

        unset($this->fakeNames[$name]);
        unset($this->fakeGroups[$name]);
        unset($this->nameHidden[$name]);
        unset($this->playerSizes[$name]);
        unset($this->auraEnabled[$name]);

        if (isset($this->auraTasks[$name])) {
            $this->auraTasks[$name]->cancel();
            unset($this->auraTasks[$name]);
        }

        $player->setScale(1.0);
        $player->setDisplayName($name);
        $player->setNameTagVisible(true);
        $player->setNameTagAlwaysVisible(true);
    }

    public function onQuit(PlayerQuitEvent $event): void {
        $name = $event->getPlayer()->getName();

        unset($this->playerSizes[$name]);
        unset($this->auraEnabled[$name]);
        unset($this->fakeNames[$name]);
        unset($this->fakeGroups[$name]);
        unset($this->nameHidden[$name]);

        if (isset($this->auraTasks[$name])) {
            $this->auraTasks[$name]->cancel();
            unset($this->auraTasks[$name]);
        }
    }

    // ==================== ГЕТТЕРЫ ====================

    public function getFakeName(string $playerName): ?string {
        return $this->fakeNames[$playerName] ?? null;
    }

    public function getFakeGroup(string $playerName): ?string {
        return $this->fakeGroups[$playerName] ?? null;
    }

    public function isNameHidden(string $playerName): bool {
        return $this->nameHidden[$playerName] ?? false;
    }
}
