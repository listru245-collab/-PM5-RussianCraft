<?php

declare(strict_types=1);

namespace InzeOwr\RcRg;

use pocketmine\plugin\PluginBase;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\math\Vector3;
use pocketmine\event\Listener;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\event\block\SignChangeEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\block\Door;
use pocketmine\block\Trapdoor;
use pocketmine\block\FenceGate;
use pocketmine\block\Chest;
use pocketmine\block\Furnace;
use pocketmine\block\Barrel;
use pocketmine\block\ShulkerBox;
use pocketmine\block\Lever;
use pocketmine\block\Button;
use pocketmine\block\BaseSign;
use pocketmine\block\Block;
use pocketmine\block\utils\SignText;
use pocketmine\item\VanillaItems;
use pocketmine\item\Item;
use pocketmine\Server;

class Main extends PluginBase implements Listener {

    private const WAND_NAME = "§r§l§9✦ §l§bИнструмент РГ §l§9✦";

    /** @var array<string, array> */
    private array $regions = [];

    /** @var array<string, array{pos1?: Vector3, pos2?: Vector3, world?: string}> */
    private array $selections = [];

    private Forms $forms;
    private string $dataPath;

    public function onEnable(): void {
        @mkdir($this->getDataFolder());
        $this->dataPath = $this->getDataFolder() . "regions.json";
        $this->loadRegions();
        $this->forms = new Forms($this);
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
        $this->getLogger()->info("§a§lRcRg §f§lv2.3.0 §a§lзагружен — Автор: §b§lInzeOwr");
        $this->getLogger()->info("§9§lАдминистрация г. Береговой, Береговая область");
    }

    public function onDisable(): void {
        $this->saveRegions();
    }

    public function getForms(): Forms {
        return $this->forms;
    }

    // ============ WAND ============

    private function createWand(): Item {
        $axe = VanillaItems::IRON_AXE();
        $axe->setCustomName(self::WAND_NAME);
        $axe->setLore([
            "§r§l§7Инструмент администрации",
            "§r§l§8г. Береговой для выделения",
            "§r§l§8территории регионов",
            "",
            "§r§l§eЛКМ §l§fпо блоку §l§7— §l§aпервая точка",
            "§r§l§eПКМ §l§fпо блоку §l§7— §l§bвторая точка"
        ]);
        return $axe;
    }

    private function isWand(Item $item): bool {
        return $item->getCustomName() === self::WAND_NAME;
    }

    // ============ ЗАГРУЗКА / СОХРАНЕНИЕ ============

    private function loadRegions(): void {
        if (!file_exists($this->dataPath)) {
            file_put_contents($this->dataPath, json_encode([], JSON_PRETTY_PRINT));
            return;
        }
        $data = json_decode(file_get_contents($this->dataPath), true);
        if (is_array($data)) {
            foreach ($data as $regionData) {
                $name = $regionData["name"] ?? "";
                if ($name !== "") {
                    if (!isset($regionData["members"])) {
                        $regionData["members"] = [];
                    }
                    $this->regions[$name] = $regionData;
                }
            }
        }
    }

    private function saveRegions(): void {
        $data = array_values($this->regions);
        file_put_contents($this->dataPath, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    }

    public function saveRegionData(string $name, array $regionData): void {
        $this->regions[$name] = $regionData;
        $this->saveRegions();
    }

    public function getRegionData(string $name): ?array {
        return $this->regions[$name] ?? null;
    }

    // ============ ГЕОМЕТРИЯ ============

    private function isInsideRegion(array $region, Vector3 $pos, string $world): bool {
        if (($region["world"] ?? "") !== $world) return false;

        $p1 = $region["pos1"];
        $p2 = $region["pos2"];

        $minX = min((int)$p1["x"], (int)$p2["x"]);
        $maxX = max((int)$p1["x"], (int)$p2["x"]);
        $minY = min((int)$p1["y"], (int)$p2["y"]);
        $maxY = max((int)$p1["y"], (int)$p2["y"]);
        $minZ = min((int)$p1["z"], (int)$p2["z"]);
        $maxZ = max((int)$p1["z"], (int)$p2["z"]);

        $x = $pos->getFloorX();
        $y = $pos->getFloorY();
        $z = $pos->getFloorZ();

        return $x >= $minX && $x <= $maxX &&
               $y >= $minY && $y <= $maxY &&
               $z >= $minZ && $z <= $maxZ;
    }

    private function isBorderOfRegion(array $region, Vector3 $pos, string $world): bool {
        if (!$this->isInsideRegion($region, $pos, $world)) return false;

        $p1 = $region["pos1"];
        $p2 = $region["pos2"];

        $minX = min((int)$p1["x"], (int)$p2["x"]);
        $maxX = max((int)$p1["x"], (int)$p2["x"]);
        $minY = min((int)$p1["y"], (int)$p2["y"]);
        $maxY = max((int)$p1["y"], (int)$p2["y"]);
        $minZ = min((int)$p1["z"], (int)$p2["z"]);
        $maxZ = max((int)$p1["z"], (int)$p2["z"]);

        $x = $pos->getFloorX();
        $y = $pos->getFloorY();
        $z = $pos->getFloorZ();

        return $x === $minX || $x === $maxX ||
               $y === $minY || $y === $maxY ||
               $z === $minZ || $z === $maxZ;
    }

    private function getDistanceToRegion(Player $player, array $region): float {
        if ($player->getWorld()->getFolderName() !== ($region["world"] ?? "")) {
            return PHP_FLOAT_MAX;
        }

        $p1 = $region["pos1"];
        $p2 = $region["pos2"];

        $minX = min((int)$p1["x"], (int)$p2["x"]);
        $maxX = max((int)$p1["x"], (int)$p2["x"]);
        $minY = min((int)$p1["y"], (int)$p2["y"]);
        $maxY = max((int)$p1["y"], (int)$p2["y"]);
        $minZ = min((int)$p1["z"], (int)$p2["z"]);
        $maxZ = max((int)$p1["z"], (int)$p2["z"]);

        $px = $player->getPosition()->getX();
        $py = $player->getPosition()->getY();
        $pz = $player->getPosition()->getZ();

        $cx = max($minX, min($px, $maxX));
        $cy = max($minY, min($py, $maxY));
        $cz = max($minZ, min($pz, $maxZ));

        return sqrt(($px - $cx) ** 2 + ($py - $cy) ** 2 + ($pz - $cz) ** 2);
    }

    /**
     * @return array[]
     */
    private function getRegionsAt(Vector3 $pos, string $world): array {
        $result = [];
        foreach ($this->regions as $region) {
            if ($this->isInsideRegion($region, $pos, $world)) {
                $result[] = $region;
            }
        }
        return $result;
    }

    /**
     * Проверяет, есть ли у игрока доступ к купленной квартире в данной точке
     * Если да — возвращает эту квартиру, иначе null
     */
    private function getOwnedApartmentAccess(Vector3 $pos, string $world, string $playerName): ?array {
        $regions = $this->getRegionsAt($pos, $world);
        foreach ($regions as $region) {
            if (($region["type"] ?? 0) === 1) { // Квартира
                $owner = $region["owner"] ?? null;
                if ($owner !== null && $this->hasApartmentAccess($region, $playerName)) {
                    return $region;
                }
            }
        }
        return null;
    }

    private function getRegionBySign(Vector3 $signPos, string $world): ?array {
        foreach ($this->regions as $region) {
            $sp = $region["signPos"] ?? null;
            $sw = $region["signWorld"] ?? null;
            if ($sp !== null && $sw === $world) {
                if ((int)$sp["x"] === $signPos->getFloorX() &&
                    (int)$sp["y"] === $signPos->getFloorY() &&
                    (int)$sp["z"] === $signPos->getFloorZ()) {
                    return $region;
                }
            }
        }
        return null;
    }

    private function hasApartmentAccess(array $region, string $playerName): bool {
        $playerLower = strtolower($playerName);
        $owner = $region["owner"] ?? null;

        if ($owner !== null && strtolower($owner) === $playerLower) {
            return true;
        }

        $members = $region["members"] ?? [];
        foreach ($members as $member) {
            if (strtolower($member) === $playerLower) {
                return true;
            }
        }

        return false;
    }

    private function isOwner(array $region, string $playerName): bool {
        $owner = $region["owner"] ?? null;
        return $owner !== null && strtolower($owner) === strtolower($playerName);
    }

    public function formatPrice(int $price): string {
        return number_format($price, 0, '', '.');
    }

    public function updateApartmentSign(array $region): void {
        $sp = $region["signPos"] ?? null;
        $sw = $region["signWorld"] ?? null;
        if ($sp === null || $sw === null) return;

        $world = $this->getServer()->getWorldManager()->getWorldByName($sw);
        if ($world === null) return;

        $pos = new Vector3((int)$sp["x"], (int)$sp["y"], (int)$sp["z"]);

        $owner = $region["owner"] ?? null;
        if ($owner !== null) {
            $signText = new SignText([
                "§l§b✦ §l§9Квартира §l§b✦",
                "§l§a" . $owner,
                "§l§2Занята",
                ""
            ]);
        } else {
            $signText = new SignText([
                "§l§b✦ §l§9Квартира §l§b✦",
                "§l§6" . $this->formatPrice($region["price"]) . " ₽",
                "§l§eНажмите",
                "§l§eдля покупки"
            ]);
        }

        $block = $world->getBlock($pos);
        $world->setBlock($pos, $block);

        $tile = $world->getTile($pos);
        if ($tile instanceof \pocketmine\block\tile\Sign) {
            $tile->setText($signText);
        }
    }

    // ============ КОМАНДЫ ============

    public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool {
        if (!$sender instanceof Player) {
            $sender->sendMessage("§c§l✦ §c§lКоманда доступна только для игроков");
            return true;
        }

        switch ($command->getName()) {

            case "rcrgwand":
                if (!$sender->hasPermission("rcrg.create")) {
                    $sender->sendMessage("§c§l✦ §c§lНедостаточно полномочий");
                    return true;
                }
                $wand = $this->createWand();
                $sender->getInventory()->addItem($wand);
                $sender->sendMessage("§a§l✦ §a§lИнструмент выделения выдан");
                $sender->sendMessage("§e§l  ЛКМ §f§lпо блоку §7§l— §a§lпервая точка");
                $sender->sendMessage("§e§l  ПКМ §f§lпо блоку §7§l— §b§lвторая точка");
                return true;

            case "rcclaimrg":
                if (!$sender->hasPermission("rcrg.create")) {
                    $sender->sendMessage("§c§l✦ §c§lНедостаточно полномочий");
                    return true;
                }

                if (count($args) < 2) {
                    $sender->sendMessage("§c§l✦ §c§lИспользование: §f§l/rcclaimrg <название> <1|2>");
                    $sender->sendMessage("§e§l  1 §7§l— §b§lсерверный регион");
                    $sender->sendMessage("§e§l  2 §7§l— §d§lквартирный регион");
                    return true;
                }

                $regionName = $args[0];
                $typeArg = $args[1];

                if ($typeArg !== "1" && $typeArg !== "2") {
                    $sender->sendMessage("§c§l✦ §c§lТип: §e§l1 §7§l(серверный) §c§lили §e§l2 §7§l(квартирный)");
                    return true;
                }

                $pName = strtolower($sender->getName());

                if (!isset($this->selections[$pName]["pos1"]) || !isset($this->selections[$pName]["pos2"])) {
                    $sender->sendMessage("§c§l✦ §c§lВыделите две точки инструментом");
                    $sender->sendMessage("§7§l  Используйте §f§l/rcrgwand");
                    return true;
                }

                if (isset($this->regions[$regionName])) {
                    $sender->sendMessage("§c§l✦ §c§lРегион §f§l" . $regionName . " §c§lуже существует");
                    return true;
                }

                $regionType = $typeArg === "1" ? 0 : 1;
                $typeName = $regionType === 0 ? "§b§lСерверный" : "§d§lКвартирный";

                $sel = $this->selections[$pName];
                $this->regions[$regionName] = [
                    "name" => $regionName,
                    "world" => $sel["world"],
                    "pos1" => [
                        "x" => $sel["pos1"]->getFloorX(),
                        "y" => $sel["pos1"]->getFloorY(),
                        "z" => $sel["pos1"]->getFloorZ()
                    ],
                    "pos2" => [
                        "x" => $sel["pos2"]->getFloorX(),
                        "y" => $sel["pos2"]->getFloorY(),
                        "z" => $sel["pos2"]->getFloorZ()
                    ],
                    "type" => $regionType,
                    "price" => 0,
                    "owner" => null,
                    "members" => [],
                    "signWorld" => null,
                    "signPos" => null
                ];
                $this->saveRegions();
                unset($this->selections[$pName]);

                $sender->sendMessage("§a§l✦ §a§lРегион §f§l" . $regionName . " §a§lзарегистрирован");
                $sender->sendMessage("§9§l  Тип: " . $typeName);

                if ($regionType === 1) {
                    $sender->sendMessage("§7§l  Установите табличку с названием и ценой");
                }
                return true;

            case "rcremoverg":
                if (!$sender->hasPermission("rcrg.admin")) {
                    $sender->sendMessage("§c§l✦ §c§lНедостаточно полномочий");
                    return true;
                }
                if (!isset($args[0])) {
                    $sender->sendMessage("§c§l✦ §c§lИспользование: §f§l/rcremoverg <название>");
                    return true;
                }
                $regionName = $args[0];
                if (isset($this->regions[$regionName])) {
                    $r = $this->regions[$regionName];
                    $oldOwner = $r["owner"] ?? null;
                    $oldMembers = $r["members"] ?? [];

                    unset($this->regions[$regionName]);
                    $this->saveRegions();
                    $sender->sendMessage("§a§l✦ §a§lРегион §f§l" . $regionName . " §a§lликвидирован");

                    if ($oldOwner !== null) {
                        $ownerPlayer = $this->getServer()->getPlayerExact($oldOwner);
                        if ($ownerPlayer !== null) {
                            $ownerPlayer->sendMessage("§c§l✦ §c§lВаша квартира ликвидирована администрацией");
                        }
                    }
                    foreach ($oldMembers as $memberName) {
                        $member = $this->getServer()->getPlayerExact($memberName);
                        if ($member !== null) {
                            $member->sendMessage("§c§l✦ §c§lКвартира ликвидирована администрацией");
                        }
                    }
                } else {
                    $sender->sendMessage("§c§l✦ §c§lРегион §f§l" . $regionName . " §c§lне найден");
                }
                return true;

            case "rclistrg":
                if (!$sender->hasPermission("rcrg.admin")) {
                    $sender->sendMessage("§c§l✦ §c§lНедостаточно полномочий");
                    return true;
                }
                if (empty($this->regions)) {
                    $sender->sendMessage("§7§l✦ §7§lРеестр регионов пуст");
                    return true;
                }
                $sender->sendMessage("§9§l✦ §9§lРеестр регионов г. Береговой\n");
                foreach ($this->regions as $r) {
                    $type = ($r["type"] ?? 0) === 0 ? "§b§lСерверный" : "§d§lКвартира";
                    $owner = ($r["owner"] ?? null) !== null ? "§a§l" . $r["owner"] : "§7§lСвободна";
                    $price = ($r["price"] ?? 0) > 0 ? "§6§l" . $this->formatPrice($r["price"]) . " ₽" : "§7§l—";
                    $members = !empty($r["members"] ?? []) ? " §8§l| §e§lЖильцы: §f§l" . implode(", ", $r["members"]) : "";
                    $line = "§f§l  " . $r["name"] . " §8§l| " . $type;
                    if (($r["type"] ?? 0) === 1) {
                        $line .= " §8§l| " . $owner . " §8§l| " . $price . $members;
                    }
                    $sender->sendMessage($line);
                }
                return true;

            case "rcresetrg":
                if (!$sender->hasPermission("rcrg.admin")) {
                    $sender->sendMessage("§c§l✦ §c§lНедостаточно полномочий");
                    return true;
                }
                if (!isset($args[0])) {
                    $sender->sendMessage("§c§l✦ §c§lИспользование: §f§l/rcresetrg <название>");
                    return true;
                }
                $regionName = $args[0];
                if (!isset($this->regions[$regionName])) {
                    $sender->sendMessage("§c§l✦ §c§lРегион §f§l" . $regionName . " §c§lне найден");
                    return true;
                }
                $r = &$this->regions[$regionName];
                if (($r["type"] ?? 0) !== 1) {
                    $sender->sendMessage("§c§l✦ §c§lРегион не является квартирой");
                    return true;
                }

                $oldOwner = $r["owner"];
                $oldMembers = $r["members"] ?? [];
                $r["owner"] = null;
                $r["members"] = [];
                $this->saveRegions();
                $this->updateApartmentSign($r);

                $sender->sendMessage("§a§l✦ §a§lКвартира §f§l" . $regionName . " §a§lсброшена");

                if ($oldOwner !== null) {
                    $ownerPlayer = $this->getServer()->getPlayerExact($oldOwner);
                    if ($ownerPlayer !== null) {
                        $ownerPlayer->sendMessage("§c§l✦ §c§lВаша квартира изъята администрацией");
                    }
                }
                foreach ($oldMembers as $memberName) {
                    $member = $this->getServer()->getPlayerExact($memberName);
                    if ($member !== null) {
                        $member->sendMessage("§c§l✦ §c§lВы выселены администрацией");
                    }
                }
                return true;
        }

        return false;
    }

    // ============ СОБЫТИЯ ============

    /**
     * @priority LOWEST
     */
    public function onSignChange(SignChangeEvent $event): void {
        $player = $event->getPlayer();
        $block = $event->getBlock();
        $lines = $event->getNewText()->getLines();

        $regionName = trim($lines[0] ?? "");
        $priceStr = trim($lines[1] ?? "");

        if ($regionName === "" || $priceStr === "") return;
        if (!isset($this->regions[$regionName])) return;

        if (!$player->hasPermission("rcrg.admin")) {
            $player->sendMessage("§c§l✦ §c§lНет полномочий для оформления квартир");
            return;
        }

        $r = &$this->regions[$regionName];

        if (($r["type"] ?? 0) !== 1) {
            $player->sendMessage("§c§l✦ §c§lРегион §f§l" . $regionName . " §c§lне квартирный");
            $player->sendMessage("§7§l  Создайте с типом §e§l2§7§l: §f§l/rcclaimrg " . $regionName . " 2");
            return;
        }

        if (!is_numeric($priceStr)) {
            $player->sendMessage("§c§l✦ §c§lУкажите стоимость числом во второй строке");
            return;
        }

        $price = (int)$priceStr;
        $r["price"] = $price;
        $r["owner"] = null;
        $r["members"] = [];
        $r["signWorld"] = $block->getPosition()->getWorld()->getFolderName();
        $r["signPos"] = [
            "x" => $block->getPosition()->getFloorX(),
            "y" => $block->getPosition()->getFloorY(),
            "z" => $block->getPosition()->getFloorZ()
        ];
        $this->saveRegions();

        $formatted = $this->formatPrice($price);

        $event->setNewText(new SignText([
            "§l§b✦ §l§9Квартира §l§b✦",
            "§l§6" . $formatted . " ₽",
            "§l§eНажмите",
            "§l§eдля покупки"
        ]));

        $player->sendMessage("§a§l✦ §a§lКвартира §f§l" . $regionName . " §a§lвыставлена");
        $player->sendMessage("§6§l  Стоимость: §f§l" . $formatted . " ₽");
    }

    /**
     * @priority HIGHEST
     */
    public function onInteract(PlayerInteractEvent $event): void {
        $player = $event->getPlayer();
        $block = $event->getBlock();
        $action = $event->getAction();
        $item = $player->getInventory()->getItemInHand();

        // ====== ИНСТРУМЕНТ ВЫДЕЛЕНИЯ ======
        if ($this->isWand($item) && $player->hasPermission("rcrg.create")) {
            $pos = $block->getPosition();
            $pName = strtolower($player->getName());
            $worldName = $pos->getWorld()->getFolderName();
            $x = $pos->getFloorX();
            $y = $pos->getFloorY();
            $z = $pos->getFloorZ();

            if ($action === PlayerInteractEvent::LEFT_CLICK_BLOCK) {
                $this->selections[$pName]["pos1"] = new Vector3($x, $y, $z);
                $this->selections[$pName]["world"] = $worldName;
                $event->cancel();
                $player->sendMessage("§a§l✦ §a§lПервая точка §7§l[§f§l" . $x . "§7§l, §f§l" . $y . "§7§l, §f§l" . $z . "§7§l]");
                return;
            }

            if ($action === PlayerInteractEvent::RIGHT_CLICK_BLOCK) {
                $this->selections[$pName]["pos2"] = new Vector3($x, $y, $z);
                if (!isset($this->selections[$pName]["world"])) {
                    $this->selections[$pName]["world"] = $worldName;
                }
                $event->cancel();
                $player->sendMessage("§b§l✦ §b§lВторая точка §7§l[§f§l" . $x . "§7§l, §f§l" . $y . "§7§l, §f§l" . $z . "§7§l]");

                if (isset($this->selections[$pName]["pos1"])) {
                    $p1 = $this->selections[$pName]["pos1"];
                    $p2 = $this->selections[$pName]["pos2"];
                    $sizeX = abs($p1->getFloorX() - $p2->getFloorX()) + 1;
                    $sizeY = abs($p1->getFloorY() - $p2->getFloorY()) + 1;
                    $sizeZ = abs($p1->getFloorZ() - $p2->getFloorZ()) + 1;
                    $volume = $sizeX * $sizeY * $sizeZ;
                    $player->sendMessage("§e§l  Размер: §f§l" . $sizeX . "§7§lx§f§l" . $sizeY . "§7§lx§f§l" . $sizeZ . " §7§l(§6§l" . $volume . " §7§lблоков)");
                }
                return;
            }
            return;
        }

        // ====== ТАБЛИЧКА КВАРТИРЫ ======
        if ($action === PlayerInteractEvent::RIGHT_CLICK_BLOCK && $block instanceof BaseSign) {
            $pos = $block->getPosition();
            $worldName = $pos->getWorld()->getFolderName();
            $region = $this->getRegionBySign($pos->asVector3(), $worldName);

            if ($region !== null && ($region["type"] ?? 0) === 1) {
                $event->cancel();

                $distance = $this->getDistanceToRegion($player, $region);
                if ($distance > 5.0) {
                    $player->sendMessage("§c§l✦ §c§lВы слишком далеко от квартиры");
                    return;
                }

                $regionName = $region["name"];
                $owner = $region["owner"] ?? null;

                if ($owner === null) {
                    $this->forms->openBuyForm($player, $this->regions[$regionName]);
                } elseif ($this->isOwner($region, $player->getName())) {
                    $this->forms->openOwnerForm($player, $this->regions[$regionName], $regionName);
                } else {
                    $this->forms->openOccupiedForm($player, $this->regions[$regionName]);
                }
                return;
            }
        }

        // ====== ЗАЩИТА БЛОКОВ ======
        if ($action === PlayerInteractEvent::RIGHT_CLICK_BLOCK) {
            $this->handleBlockInteraction($event, $player, $block);
        }
    }

    private function handleBlockInteraction(PlayerInteractEvent $event, Player $player, Block $block): void {
        if ($player->hasPermission("rcrg.admin")) return;

        $pos = $block->getPosition();
        $worldName = $pos->getWorld()->getFolderName();
        $vec = new Vector3($pos->getFloorX(), $pos->getFloorY(), $pos->getFloorZ());

        // ПРИОРИТЕТ: Если игрок в своей купленной квартире — разрешаем всё
        $ownedApartment = $this->getOwnedApartmentAccess($vec, $worldName, $player->getName());
        if ($ownedApartment !== null) {
            return; // Владелец/жилец купленной квартиры — полный доступ
        }

        $regions = $this->getRegionsAt($vec, $worldName);
        if (empty($regions)) return;

        // Проверяем серверные регионы
        foreach ($regions as $region) {
            if (($region["type"] ?? 0) === 0) {
                if ($block instanceof Door || $block instanceof FenceGate) {
                    return;
                }
                if ($block instanceof Trapdoor || $block instanceof Lever || $block instanceof Button) {
                    $event->cancel();
                    $player->sendMessage("§c§l✦ §c§lВзаимодействие запрещено на территории г. Береговой");
                    return;
                }
                if ($block instanceof Chest || $block instanceof Barrel ||
                    $block instanceof ShulkerBox || $block instanceof Furnace) {
                    $event->cancel();
                    $player->sendMessage("§c§l✦ §c§lВзаимодействие запрещено на территории г. Береговой");
                    return;
                }
                return;
            }
        }

        // Проверяем квартирные регионы
        foreach ($regions as $region) {
            if (($region["type"] ?? 0) === 1) {
                $owner = $region["owner"] ?? null;

                // Не куплена — двери можно
                if ($owner === null) {
                    if ($block instanceof Door || $block instanceof FenceGate) {
                        return;
                    }
                    return;
                }

                // Куплена, но не наша — запрещено
                $event->cancel();
                $player->sendMessage("§c§l✦ §c§lЧастная собственность гражданина §f§l" . $owner);
                return;
            }
        }
    }

    /**
     * @priority HIGHEST
     */
    public function onBlockBreak(BlockBreakEvent $event): void {
        $player = $event->getPlayer();
        $item = $player->getInventory()->getItemInHand();

        if ($this->isWand($item) && $player->hasPermission("rcrg.create")) {
            $event->cancel();
            return;
        }

        if ($player->hasPermission("rcrg.admin")) return;

        $block = $event->getBlock();
        $pos = $block->getPosition();
        $worldName = $pos->getWorld()->getFolderName();
        $vec = new Vector3($pos->getFloorX(), $pos->getFloorY(), $pos->getFloorZ());

        // ПРИОРИТЕТ: Если игрок в своей купленной квартире — проверяем только границы
        $ownedApartment = $this->getOwnedApartmentAccess($vec, $worldName, $player->getName());
        if ($ownedApartment !== null) {
            // Владелец/жилец — запрещены только несущие конструкции
            if ($this->isBorderOfRegion($ownedApartment, $vec, $worldName)) {
                $event->cancel();
                $player->sendMessage("§c§l✦ §c§lРазрушение несущих конструкций запрещено");
                return;
            }
            return; // Внутри своей кв — можно всё
        }

        $regions = $this->getRegionsAt($vec, $worldName);
        if (empty($regions)) return;

        // Серверный регион
        foreach ($regions as $region) {
            if (($region["type"] ?? 0) === 0) {
                $event->cancel();
                $player->sendMessage("§c§l✦ §c§lРазрушение запрещено на территории г. Береговой");
                return;
            }
        }

        // Квартирный регион (чужой или не куплен)
        foreach ($regions as $region) {
            if (($region["type"] ?? 0) === 1) {
                $owner = $region["owner"] ?? null;

                if ($owner !== null) {
                    $event->cancel();
                    $player->sendMessage("§c§l✦ §c§lЧастная собственность гражданина §f§l" . $owner);
                    return;
                }

                // Не куплена — запрещено
                $event->cancel();
                $player->sendMessage("§c§l✦ §c§lРазрушение запрещено в данном объекте");
                return;
            }
        }
    }

    /**
     * @priority HIGHEST
     */
    public function onBlockPlace(BlockPlaceEvent $event): void {
        $player = $event->getPlayer();
        if ($player->hasPermission("rcrg.admin")) return;

        $transaction = $event->getTransaction();
        $blocks = $transaction->getBlocks();
        $worldName = $player->getWorld()->getFolderName();

        foreach ($blocks as [$bx, $by, $bz, $block]) {
            $vec = new Vector3($bx, $by, $bz);

            // ПРИОРИТЕТ: Если игрок в своей купленной квартире — разрешаем строить
            $ownedApartment = $this->getOwnedApartmentAccess($vec, $worldName, $player->getName());
            if ($ownedApartment !== null) {
                continue; // Владелец/жилец — может строить везде в своей кв
            }

            $regions = $this->getRegionsAt($vec, $worldName);
            if (empty($regions)) continue;

            // Серверный регион
            foreach ($regions as $region) {
                if (($region["type"] ?? 0) === 0) {
                    $event->cancel();
                    $player->sendMessage("§c§l✦ §c§lСтроительство запрещено на территории г. Береговой");
                    return;
                }
            }

            // Квартирный регион (чужой или не куплен)
            foreach ($regions as $region) {
                if (($region["type"] ?? 0) === 1) {
                    $owner = $region["owner"] ?? null;

                    if ($owner !== null) {
                        $event->cancel();
                        $player->sendMessage("§c§l✦ §c§lЧастная собственность гражданина §f§l" . $owner);
                        return;
                    }

                    // Не куплена — запрещено
                    $event->cancel();
                    $player->sendMessage("§c§l✦ §c§lСтроительство запрещено в данном объекте");
                    return;
                }
            }
        }
    }
}
