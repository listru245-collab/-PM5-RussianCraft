<?php

declare(strict_types=1);

namespace InzeOwr\RcSupport;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\player\Player;
use pocketmine\Server;
use pocketmine\scheduler\ClosureTask;

class Main extends PluginBase implements Listener {

    private const TAG = "§l§8[§4Ангелочек§8] Карина§a: ";
    private const COOLDOWN_SECONDS = 20;

    private array $responses = [];
    private array $cooldowns = [];
    private bool $restartInProgress = false;

    private array $cuteWords = [
        "милашка",
        "солнышко",
        "зайчик",
        "котик",
        "лапочка",
        "сладкий",
        "родной",
        "малыш",
        "мишка",
        "любимчик",
        "ангелочек",
        "звёздочка",
        "пупсик",
        "кисуля",
        "рыбка",
        "птичка",
        "ягодка",
        "цветочек",
        "бусинка",
        "капелька",
        "снежинка",
        "пушинка",
        "радость моя",
        "конфетка",
        "персик",
        "вишенка",
        "лучик",
        "зёрнышко",
        "карамелька",
        "облачко"
    ];

    public function onEnable(): void {
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
        $this->loadResponses();
        $this->saveDefaultConfig();
        $this->loadAutoRestart();
        $this->getLogger()->info("RcSupport загружен! Помощник Карина активна.");
    }

    private function loadAutoRestart(): void {
        $this->saveResource("config.yml", false);
        $config = $this->getConfig();

        if ($config->get("auto-restart-enabled", false)) {
            $interval = $config->get("auto-restart-interval", "12h");
            $ticks = $this->parseTimeToTicks($interval);

            if ($ticks > 0) {
                $this->getScheduler()->scheduleDelayedTask(new ClosureTask(function(): void {
                    $this->startRestartCountdown();
                }), $ticks);
                $this->getLogger()->info("Авторестарт запланирован каждые: " . $interval);
            }
        }
    }

    private function parseTimeToTicks(string $time): int {
        $time = strtolower(trim($time));

        if (preg_match('/^(\d+)\s*(s|m|h|d)$/', $time, $matches)) {
            $value = (int)$matches[1];
            $unit = $matches[2];

            return match($unit) {
                "s" => $value * 20,
                "m" => $value * 20 * 60,
                "h" => $value * 20 * 60 * 60,
                "d" => $value * 20 * 60 * 60 * 24,
                default => 0
            };
        }

        return 0;
    }

    private function getCuteWord(): string {
        return $this->cuteWords[array_rand($this->cuteWords)];
    }

    private function loadResponses(): void {
        $this->responses[] = [
            "keywords" => ["вк", "vk", "вконтакте", "контакт"],
            "answer" => "§l§aЛови наш ВК: §b§lhttps://vk.ru/rp.russian_craft"
        ];

        $this->responses[] = [
            "keywords" => ["тг", "tg", "телеграм", "telegram", "телега"],
            "answer" => "§l§aДержи ТГ канал: §b§lhttps://t.me/rcrpmcbe"
        ];

        $this->responses[] = [
            "keywords" => ["соц сети", "соцсети", "ссылки", "ссылка", "социальные сети"],
            "answer" => "§l§aВот все наши соцсети, подписывайся:\n§l§bТГ: https://t.me/rcrpmcbe\n§l§bВК: https://vk.ru/rp.russian_craft"
        ];

        $this->responses[] = [
            "keywords" => ["донат", "донатить", "привилегии", "привилегия", "купить", "ключи", "ключ", "валюта", "валюту", "монеты"],
            "answer" => "§l§aХочешь задонатить? Залетай сюда: §b§lrc-rp.online §l§aТам есть донат, ключи и валюта"
        ];

        $this->responses[] = [
            "keywords" => ["правила", "правило", "правил", "rules"],
            "answer" => "§l§aПравила обязательно глянь в нашем ВК, там всё расписано: §b§lhttps://vk.ru/rp.russian_craft"
        ];

        $this->responses[] = [
            "keywords" => ["помощь", "помоги", "хелп", "help", "что ты умеешь", "что умеешь", "функции"],
            "answer" => "§l§aЯ много чего умею, смотри:\n§l§7- Кину ссылки на соцсети §e(Карина тг / вк)\n§l§7- Расскажу про правила §e(Карина правила)\n§l§7- Покажу где донатить §e(Карина донат)\n§l§7- Скажу точное время §e(Карина время)\n§l§7- Посчитаю что угодно §e(Карина посчитай 5+5)"
        ];

        $this->responses[] = [
            "keywords" => ["привет", "здравствуй", "хай", "hi", "hello", "здарова", "прив", "хеллоу"],
            "answer" => "§l§aЙоу, привет! Чем помочь? Напиши §e§lКарина помощь §l§aи я всё расскажу"
        ];

        $this->responses[] = [
            "keywords" => ["версия", "version"],
            "answer" => ""
        ];

        $this->responses[] = [
            "keywords" => ["онлайн", "online", "сколько игроков", "сколько людей"],
            "answer" => ""
        ];

        $this->responses[] = [
            "keywords" => ["админ", "администрация", "модератор", "модер", "стафф", "staff"],
            "answer" => "§l§aИнфу по админам ищи в наших соцсетях:\n§l§bТГ: https://t.me/rcrpmcbe\n§l§bВК: https://vk.ru/rp.russian_craft"
        ];

        $this->responses[] = [
            "keywords" => ["как играть", "как начать", "как зайти", "новичок", "гайд"],
            "answer" => "§l§aО, ты новенький? Круто! Сначала глянь правила, потом загляни в наши соцсети, там есть гайды:\n§l§bТГ: https://t.me/rcrpmcbe\n§l§bВК: https://vk.ru/rp.russian_craft"
        ];

        $this->responses[] = [
            "keywords" => ["баг", "bug", "ошибка", "жалоба", "репорт", "report"],
            "answer" => "§l§aНашёл баг? Скорее пиши нам в соцсети, разберёмся:\n§l§bТГ: https://t.me/rcrpmcbe\n§l§bВК: https://vk.ru/rp.russian_craft"
        ];
    }

    private function sendKarinaMessage(Player $player, string $message): void {
        $cuteWord = $this->getCuteWord();
        $player->sendMessage(self::TAG . $message . "§l§a, " . $cuteWord);
    }

    private function sendKarinaMessageSimple(Player $player, string $message): void {
        $player->sendMessage(self::TAG . $message);
    }

    private function broadcastKarina(string $message): void {
        $this->getServer()->broadcastMessage(self::TAG . $message);
    }

    public function onJoin(PlayerJoinEvent $event): void {
        $player = $event->getPlayer();
        $cuteWord = $this->getCuteWord();
        $player->sendMessage(self::TAG . "§l§aЙоу, привет! Я Карина, твой игровой помощник! Если чё-то непонятно, просто напиши мне, например: \"§e§lКарина вк§l§a\", " . $cuteWord);
    }

    public function onChat(PlayerChatEvent $event): void {
        $player = $event->getPlayer();
        $message = $event->getMessage();
        $lowerMessage = mb_strtolower(trim($message), "UTF-8");

        if (!$this->startsWithKarina($lowerMessage)) {
            return;
        }

        $event->cancel();

        // Проверка кулдауна (опы без кулдауна)
        if (!$player->hasPermission("rcsupport.nocooldown")) {
            if ($this->isOnCooldown($player)) {
                $remaining = $this->getRemainingCooldown($player);
                $this->sendKarinaMessage($player, "§l§aЭй, не так быстро! Подожди ещё §e§l" . $remaining . " сек.");
                return;
            }
            $this->setCooldown($player);
        }

        $query = $this->removeKarinaPrefix($lowerMessage);
        $originalQuery = $this->removeKarinaPrefixOriginal(trim($message));

        if (trim($query) === "") {
            $this->sendKarinaMessage($player, "§l§aТы позвал меня, но ничего не спросил! Напиши §e§lКарина помощь");
            return;
        }

        // Проверка на рассылку всем
        if ($this->isBroadcastRequest($query)) {
            $this->handleBroadcast($player, $query);
            return;
        }

        if ($this->isRestartRequest($query)) {
            $this->handleRestart($player, $query);
            return;
        }

        if ($this->isCalculator($query)) {
            $this->handleCalculator($player, $query);
            return;
        }

        if ($this->isTimeRequest($query)) {
            $this->handleTime($player);
            return;
        }

        if ($this->isCommand($originalQuery)) {
            $this->handleCommand($player, $originalQuery);
            return;
        }

        $answer = $this->findAnswer($query, $player);

        if ($answer !== null) {
            if (strpos($answer, "\n") !== false) {
                $this->sendKarinaMessageSimple($player, $answer);
            } else {
                $this->sendKarinaMessage($player, $answer);
            }
        } else {
            $this->sendKarinaMessage($player, "§l§aХм, не поняла тебя. Попробуй написать §e§lКарина помощь §l§aи глянь что я умею");
        }
    }

    /**
     * Проверка на запрос рассылки
     */
    private function isBroadcastRequest(string $query): bool {
        $keywords = ["напиши всем", "скажи всем", "объяви", "объявление"];
        foreach ($keywords as $keyword) {
            if (str_starts_with($query, $keyword)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Обработка рассылки
     */
    private function handleBroadcast(Player $player, string $query): void {
        if (!$player->hasPermission("rcsupport.broadcast")) {
            $this->sendKarinaMessage($player, "§l§cНе-а, у тебя нет прав на это");
            return;
        }

        // Убираем ключевые слова
        $keywords = ["напиши всем", "скажи всем", "объяви", "объявление"];
        $msg = $query;

        foreach ($keywords as $keyword) {
            if (str_starts_with($msg, $keyword)) {
                $msg = trim(mb_substr($msg, mb_strlen($keyword, "UTF-8"), null, "UTF-8"));
                break;
            }
        }

        if (trim($msg) === "") {
            $this->sendKarinaMessage($player, "§l§aА что написать-то? Пример: §e§lКарина напиши всем Привет всем!");
            return;
        }

        // Делаем первую букву заглавной
        $msg = mb_strtoupper(mb_substr($msg, 0, 1, "UTF-8"), "UTF-8") . mb_substr($msg, 1, null, "UTF-8");

        $cuteWord = $this->getCuteWord();
        $this->broadcastKarina("§l§a" . $msg . ", " . $cuteWord . "§l§a ❤");

        $this->sendKarinaMessage($player, "§l§aГотово! Написала всем");
    }

    private function isRestartRequest(string $query): bool {
        return str_starts_with($query, "рестарт") || str_starts_with($query, "restart");
    }

    private function handleRestart(Player $player, string $query): void {
        if (!$player->hasPermission("rcsupport.restart")) {
            $this->sendKarinaMessage($player, "§l§cНе-а, у тебя нет прав на рестарт сервера");
            return;
        }

        if ($this->restartInProgress) {
            $this->sendKarinaMessage($player, "§l§cРестарт уже запущен, подожди");
            return;
        }

        $parts = explode(" ", trim($query));

        if (count($parts) >= 2) {
            $secondWord = $parts[1];

            if (preg_match('/^\d+(s|m|h|d)$/i', $secondWord)) {
                $this->setupAutoRestart($player, $secondWord);
                return;
            }
        }

        $this->startRestartCountdown();
        $this->sendKarinaMessage($player, "§l§aЛадно, запускаю рестарт");
    }

    private function setupAutoRestart(Player $player, string $interval): void {
        $ticks = $this->parseTimeToTicks($interval);

        if ($ticks <= 0) {
            $this->sendKarinaMessage($player, "§l§cНеправильный формат времени. Пиши так: §e§l12h, 30m, 1d");
            return;
        }

        $this->getConfig()->set("auto-restart-enabled", true);
        $this->getConfig()->set("auto-restart-interval", $interval);
        $this->getConfig()->save();

        $this->getScheduler()->cancelAllTasks();
        $this->getScheduler()->scheduleDelayedTask(new ClosureTask(function(): void {
            $this->startRestartCountdown();
        }), $ticks);

        $this->sendKarinaMessage($player, "§l§aГотово! Авторестарт теперь каждые §e§l" . $interval);
    }

    private function startRestartCountdown(): void {
        if ($this->restartInProgress) {
            return;
        }

        $this->restartInProgress = true;

        $this->broadcastKarina("§l§cВнимание! Рестарт сервера через §e§l30 секунд");

        $this->getScheduler()->scheduleDelayedTask(new ClosureTask(function(): void {
            $this->broadcastKarina("§l§cРестарт через §e§l20 секунд");
        }), 20 * 10);

        $this->getScheduler()->scheduleDelayedTask(new ClosureTask(function(): void {
            $this->broadcastKarina("§l§cРестарт через §e§l10 секунд");
        }), 20 * 20);

        for ($i = 9; $i >= 1; $i--) {
            $seconds = $i;
            $delay = 20 * (30 - $i);
            $this->getScheduler()->scheduleDelayedTask(new ClosureTask(function() use ($seconds): void {
                $this->broadcastKarina("§l§cРестарт через §e§l" . $seconds);
            }), $delay);
        }

        $this->getScheduler()->scheduleDelayedTask(new ClosureTask(function(): void {
            $this->broadcastKarina("§l§c§lСервер перезапускается...");
            $this->getScheduler()->scheduleDelayedTask(new ClosureTask(function(): void {
                $this->performRestart();
            }), 20);
        }), 20 * 30);
    }

    private function performRestart(): void {
        foreach ($this->getServer()->getOnlinePlayers() as $player) {
            $player->kick("§l§cСервер перезапускается, зайди через минутку!");
        }

        foreach ($this->getServer()->getWorldManager()->getWorlds() as $world) {
            $world->save(true);
        }

        $this->getServer()->getLogger()->info("RcSupport: Рестарт сервера...");

        $this->getServer()->shutdown();

        $this->getScheduler()->scheduleDelayedTask(new ClosureTask(function(): void {
            $this->getServer()->forceShutdown();
        }), 40);

        $this->getScheduler()->scheduleDelayedTask(new ClosureTask(function(): void {
            // @phpstan-ignore-next-line
            trigger_error("RcSupport: Forced restart", E_USER_ERROR);
        }), 60);
    }

    private function isOnCooldown(Player $player): bool {
        $name = $player->getName();
        if (!isset($this->cooldowns[$name])) {
            return false;
        }
        return (time() - $this->cooldowns[$name]) < self::COOLDOWN_SECONDS;
    }

    private function getRemainingCooldown(Player $player): int {
        $name = $player->getName();
        if (!isset($this->cooldowns[$name])) {
            return 0;
        }
        $remaining = self::COOLDOWN_SECONDS - (time() - $this->cooldowns[$name]);
        return max(0, $remaining);
    }

    private function setCooldown(Player $player): void {
        $this->cooldowns[$player->getName()] = time();
    }

    private function startsWithKarina(string $lowerMessage): bool {
        $prefixes = ["карина", "karina"];
        foreach ($prefixes as $prefix) {
            if (str_starts_with($lowerMessage, $prefix)) {
                return true;
            }
        }
        return false;
    }

    private function removeKarinaPrefix(string $lowerMessage): string {
        $prefixes = ["карина", "karina"];
        foreach ($prefixes as $prefix) {
            if (str_starts_with($lowerMessage, $prefix)) {
                return trim(mb_substr($lowerMessage, mb_strlen($prefix, "UTF-8"), null, "UTF-8"));
            }
        }
        return $lowerMessage;
    }

    private function removeKarinaPrefixOriginal(string $message): string {
        $lowerMessage = mb_strtolower($message, "UTF-8");
        $prefixes = ["карина", "karina"];
        foreach ($prefixes as $prefix) {
            if (str_starts_with($lowerMessage, $prefix)) {
                return trim(mb_substr($message, mb_strlen($prefix, "UTF-8"), null, "UTF-8"));
            }
        }
        return $message;
    }

    private function isCalculator(string $query): bool {
        $calcKeywords = ["посчитай", "вычисли", "калькулятор", "сколько будет", "calc", "корень", "sqrt"];
        foreach ($calcKeywords as $keyword) {
            if (mb_strpos($query, $keyword, 0, "UTF-8") !== false) {
                return true;
            }
        }
        return false;
    }

    private function handleCalculator(Player $player, string $query): void {
        $calcKeywords = ["посчитай", "вычисли", "калькулятор", "сколько будет", "calc"];
        $expression = $query;

        foreach ($calcKeywords as $keyword) {
            $expression = str_replace($keyword, "", $expression);
        }

        $expression = trim($expression);

        if ($expression === "") {
            $this->sendKarinaMessage($player, "§l§aА что считать-то? Напиши, например: §e§lКарина посчитай 10+5*2");
            return;
        }

        $result = $this->calculate($expression);

        if ($result !== null) {
            $this->sendKarinaMessage($player, "§l§aСчитаем: §e§l" . $expression . " §l§a= §b§l" . $result);
        } else {
            $this->sendKarinaMessage($player, "§l§cНе смогла это посчитать. Используй: §e§l+ - * / ( ) sqrt корень дроби");
        }
    }

    private function calculate(string $expression): ?string {
        $expression = trim($expression);
        $expression = str_replace(" ", "", $expression);

        $expression = str_replace(["х", "Х", "×"], "*", $expression);
        $expression = str_replace([":", "÷"], "/", $expression);

        $expression = preg_replace('/корень\(([^)]+)\)/ui', 'sqrt($1)', $expression);
        $expression = preg_replace('/корень(\d+\.?\d*)/ui', 'sqrt($1)', $expression);
        $expression = preg_replace('/√\(([^)]+)\)/', 'sqrt($1)', $expression);
        $expression = preg_replace('/√(\d+\.?\d*)/', 'sqrt($1)', $expression);

        $expression = str_replace("^", "**", $expression);

        if (preg_match('/^(-?\d*\.?\d*)x\*?\*?2([+-]\d*\.?\d*)x([+-]\d+\.?\d*)=0$/i', $expression, $matches)) {
            return $this->solveQuadratic($matches);
        }

        if (!preg_match('/^[0-9+\-*\/().sqrt\s]+$/i', $expression)) {
            return null;
        }

        if (preg_match('/\/0(?![0-9.])/', $expression)) {
            return "§l§cОшибка, на ноль делить нельзя";
        }

        $openBrackets = substr_count($expression, "(");
        $closeBrackets = substr_count($expression, ")");
        if ($openBrackets !== $closeBrackets) {
            return null;
        }

        if (preg_match('/sqrt\((-\d+\.?\d*)\)/', $expression)) {
            return "§l§cОшибка, корень из отрицательного числа нельзя";
        }

        try {
            $result = @eval("return " . $expression . ";");

            if ($result === false && $result !== 0) {
                return null;
            }

            if (!is_numeric($result)) {
                return null;
            }

            if (is_float($result)) {
                if (floor($result) == $result) {
                    return (string)(int)$result;
                }
                $result = round($result, 6);
            }

            return (string)$result;
        } catch (\Throwable $e) {
            return null;
        }
    }

    private function solveQuadratic(array $matches): string {
        $a = $matches[1] === "" || $matches[1] === "+" ? 1 : ($matches[1] === "-" ? -1 : (float)$matches[1]);
        $b = $matches[2] === "" || $matches[2] === "+" ? 1 : ($matches[2] === "-" ? -1 : (float)str_replace(["+", " "], "", $matches[2]));
        $c = (float)str_replace(["+", " "], "", $matches[3]);

        if ($a == 0) {
            return "§l§cОшибка, a не может быть 0";
        }

        $discriminant = $b * $b - 4 * $a * $c;

        if ($discriminant < 0) {
            return "§l§cКорней нет, D = " . round($discriminant, 4);
        } elseif ($discriminant == 0) {
            $x = -$b / (2 * $a);
            return "§l§ax = " . round($x, 6) . " §l§7(D = 0)";
        } else {
            $x1 = (-$b + sqrt($discriminant)) / (2 * $a);
            $x2 = (-$b - sqrt($discriminant)) / (2 * $a);
            return "§l§ax1 = " . round($x1, 6) . ", x2 = " . round($x2, 6) . " §l§7(D = " . round($discriminant, 4) . ")";
        }
    }

    private function isTimeRequest(string $query): bool {
        $timeKeywords = ["время", "который час", "сколько времени", "time", "час"];
        foreach ($timeKeywords as $keyword) {
            if (mb_strpos($query, $keyword, 0, "UTF-8") !== false) {
                return true;
            }
        }
        return false;
    }

    private function handleTime(Player $player): void {
        $timezone = new \DateTimeZone("Europe/Moscow");
        $dateTime = new \DateTime("now", $timezone);

        $time = $dateTime->format("H:i:s");
        $date = $dateTime->format("d.m.Y");
        $dayOfWeek = $this->getRussianDayOfWeek((int)$dateTime->format("N"));

        $cuteWord = $this->getCuteWord();
        $this->sendKarinaMessageSimple($player, "§l§aВот точное время по МСК:");
        $player->sendMessage("§l§7Время: §e§l" . $time);
        $player->sendMessage("§l§7Дата: §e§l" . $date . " §l§7(" . $dayOfWeek . "), " . $cuteWord);
    }

    private function getRussianDayOfWeek(int $day): string {
        $days = [
            1 => "Понедельник",
            2 => "Вторник",
            3 => "Среда",
            4 => "Четверг",
            5 => "Пятница",
            6 => "Суббота",
            7 => "Воскресенье"
        ];
        return $days[$day] ?? "Неизвестно";
    }

    private function isCommand(string $query): bool {
        return str_starts_with(trim($query), "/");
    }

    private function handleCommand(Player $player, string $query): void {
        if (!$player->hasPermission("rcsupport.command")) {
            $this->sendKarinaMessage($player, "§l§cНе-а, у тебя нет прав на это");
            return;
        }

        $command = ltrim(trim($query), "/");

        if (trim($command) === "") {
            $this->sendKarinaMessage($player, "§l§aА какую команду-то? Пиши так: §e§lКарина /rcsetg Player PLAYER");
            return;
        }

        $this->sendKarinaMessage($player, "§l§aОкей, выполняю: §e§l/" . $command);

        $this->getServer()->dispatchCommand(
            new \pocketmine\console\ConsoleCommandSender($this->getServer(), $this->getServer()->getLanguage()),
            $command
        );

        $this->sendKarinaMessage($player, "§l§aГотово! Команда §e§l/" . $command . " §l§aвыполнена");
    }

    private function findAnswer(string $query, Player $player): ?string {
        $onlineKeywords = ["онлайн", "online", "сколько игроков", "сколько людей"];
        foreach ($onlineKeywords as $keyword) {
            if (mb_strpos($query, $keyword, 0, "UTF-8") !== false) {
                $count = count($this->getServer()->getOnlinePlayers());
                $max = $this->getServer()->getMaxPlayers();
                return "§l§aСейчас на сервере §e§l" . $count . "§l§a/§e§l" . $max . " §l§aчеловек";
            }
        }

        $versionKeywords = ["версия", "version"];
        foreach ($versionKeywords as $keyword) {
            if (mb_strpos($query, $keyword, 0, "UTF-8") !== false) {
                return "§l§aВерсия сервера: §e§l" . Server::getInstance()->getVersion() . " §l§a| API: §e§l" . Server::getInstance()->getApiVersion();
            }
        }

        $bestMatch = null;
        $bestScore = 0;

        foreach ($this->responses as $response) {
            if ($response["answer"] === "") {
                continue;
            }

            foreach ($response["keywords"] as $keyword) {
                if (mb_strpos($query, $keyword, 0, "UTF-8") !== false) {
                    $score = mb_strlen($keyword, "UTF-8");
                    if ($score > $bestScore) {
                        $bestScore = $score;
                        $bestMatch = $response["answer"];
                    }
                }
            }
        }

        return $bestMatch;
    }
}
