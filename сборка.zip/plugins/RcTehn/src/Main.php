<?php

declare(strict_types=1);

namespace InzeOwr\RcTehn;

use pocketmine\plugin\PluginBase;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\scheduler\Task;
use pocketmine\Server;
use pocketmine\entity\object\ItemEntity;
use pocketmine\utils\TextFormat;

class Main extends PluginBase {

    private bool $clearActive = false;
    private int $remainingTime = 0;
    private ?int $taskId = null;

    public function onEnable(): void {
        $this->getLogger()->info(TextFormat::GREEN . "RcTehn by InzeOwr enabled!");
    }

    public function onDisable(): void {
        $this->getLogger()->info(TextFormat::RED . "RcTehn by InzeOwr disabled!");
    }

    public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool {
        if ($command->getName() === "rccl") {

            // Проверка прав
            if (!$sender->hasPermission("rctehn.clear")) {
                $sender->sendMessage("§l§cУ вас нет прав для использования этой команды!");
                return true;
            }

            // Проверка: уже запущена отчистка?
            if ($this->clearActive) {
                $sender->sendMessage("§l§cОтчистка предметов уже запущена! Дождитесь завершения.");
                return true;
            }

            // Запуск таймера на 60 секунд
            $this->clearActive = true;
            $this->remainingTime = 60;

            $sender->sendMessage("§l§aОтчистка предметов с пола запущена! До отчистки: §e60 §aсекунд.");

            // Broadcast начальное сообщение
            Server::getInstance()->broadcastMessage("§l§fДо отчистки предметов с пола §e60 §fсекунд.");

            // Запуск задачи
            $task = new ClearTask($this);
            $this->getScheduler()->scheduleRepeatingTask($task, 20); // каждую секунду (20 тиков)

            return true;
        }

        return false;
    }

    public function getRemainingTime(): int {
        return $this->remainingTime;
    }

    public function decrementTime(): void {
        $this->remainingTime--;
    }

    public function isClearActive(): bool {
        return $this->clearActive;
    }

    public function setClearActive(bool $active): void {
        $this->clearActive = $active;
    }

    /**
     * Выполняет отчистку предметов со всех миров
     * @return int количество удалённых предметов
     */
    public function performClear(): int {
        $count = 0;

        foreach (Server::getInstance()->getWorldManager()->getWorlds() as $world) {
            foreach ($world->getEntities() as $entity) {
                if ($entity instanceof ItemEntity) {
                    $entity->flagForDespawn();
                    $count++;
                }
            }
        }

        return $count;
    }
}

class ClearTask extends Task {

    private Main $plugin;

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
    }

    public function onRun(): void {
        // Проверка что плагин всё ещё активен
        if (!$this->plugin->isEnabled()) {
            $this->plugin->setClearActive(false);
            $this->getHandler()?->cancel();
            return;
        }

        $time = $this->plugin->getRemainingTime();

        // Определяем, нужно ли отправлять сообщение
        if ($this->shouldBroadcast($time)) {
            Server::getInstance()->broadcastMessage(
                "§l§fДо отчистки предметов с пола §e" . $time . " §fсек."
            );
        }

        // Уменьшаем время
        $this->plugin->decrementTime();

        // Время вышло — выполняем отчистку
        if ($this->plugin->getRemainingTime() <= 0) {
            $count = $this->plugin->performClear();

            Server::getInstance()->broadcastMessage(
                "§l§fБыло отчищено с пола §e" . $count . " §fпредметов."
            );

            $this->plugin->setClearActive(false);
            $this->getHandler()?->cancel();
        }
    }

    /**
     * Определяет, нужно ли отправлять сообщение в чат на данной секунде
     */
    private function shouldBroadcast(int $time): bool {
        // На 30 секунде
        if ($time === 30) {
            return true;
        }

        // На 20 секунде
        if ($time === 20) {
            return true;
        }

        // На 10 и ниже (10, 9, 8, 7, 6, 5, 4, 3, 2, 1)
        if ($time <= 10 && $time >= 1) {
            return true;
        }

        return false;
    }
}
