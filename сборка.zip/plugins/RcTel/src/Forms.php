<?php

declare(strict_types=1);

namespace InzeOwr\RcTel;

use pocketmine\player\Player;
use pocketmine\world\Position;
use jojoe77777\FormAPI\SimpleForm;
use jojoe77777\FormAPI\CustomForm;
use jojoe77777\FormAPI\ModalForm;

class Forms {

    // ==================== ГЛАВНОЕ МЕНЮ ТЕЛЕФОНА ====================

    public static function openPhoneMain(Player $player): void {
        $plugin = Main::getInstance();
        $name = $player->getName();
        $number = $plugin->getPhoneNumber($name);
        $phoneBalance = $plugin->getPhoneBalance($name);
        $battery = $plugin->getBatteryPercent($name);
        $unreadSms = $plugin->getUnreadSmsCount($name);
        $contacts = $plugin->getContacts($name);
        $contactCount = count($contacts);

        if ($battery <= 20) {
            $batteryColor = "§c";
        } elseif ($battery <= 50) {
            $batteryColor = "§e";
        } else {
            $batteryColor = "§a";
        }

        $batteryBar = "";
        $filled = (int)($battery / 10);
        for ($i = 0; $i < 10; $i++) {
            $batteryBar .= $i < $filled ? "§a|" : "§8|";
        }

        $form = new SimpleForm(function(Player $player, ?int $data) {
            if ($data === null) return;
            match ($data) {
                0 => Forms::openContactsMenu($player),
                1 => Forms::openBankMainMenu($player),
                2 => Forms::openTaxiMainMenu($player),
                3 => Forms::openTransferMenu($player),
                4 => Forms::openSmsMenu($player),
                5 => $player->sendMessage("§8§l[§6Телефон§8] §r§7Выключен."),
                default => null
            };
        });

        $form->setTitle("§l§8[ §6Телефон §8]");
        $form->setContent(
            "§e§l--- Информация ---§r\n\n" .
            "§b§l> §fВладелец: §e§l" . $name . "§r\n" .
            "§b§l> §fНомер: §b" . $number . "§r\n" .
            "§b§l> §fБаланс: §6" . number_format($phoneBalance, 2) . "р.§r\n" .
            "§b§l> §fБатарея: " . $batteryColor . "§l" . $battery . "% §r[" . $batteryBar . "§r]§r\n" .
            "§b§l> §fСМС: §c" . $unreadSms . " §7новых§r\n" .
            "§b§l> §fКонтакты: §a" . $contactCount . "§r\n\n" .
            "§e§l--- Приложения ---§r"
        );

        $form->addButton("§l§aКонтакты §8[" . $contactCount . "]\n§r§8Телефонная книга");
        $form->addButton("§l§3Банк\n§r§8Счета и вклады");
        $form->addButton("§l§eТакси\n§r§8Поездки по городу");
        $form->addButton("§l§6Переводы\n§r§8Отправить деньги");
        $form->addButton("§l§9СМС §8[§c" . $unreadSms . "§8]\n§r§8Сообщения");
        $form->addButton("§l§cВыключить");

        $player->sendForm($form);
    }

    // ==================== КОНТАКТЫ ====================

    public static function openContactsMenu(Player $player): void {
        $plugin = Main::getInstance();
        $contacts = $plugin->getContacts($player->getName());
        $contactNames = array_keys($contacts);

        $form = new SimpleForm(function(Player $player, ?int $data) use ($contactNames) {
            if ($data === null) return;
            if ($data === 0) {
                Forms::openAddContactForm($player);
            } elseif ($data <= count($contactNames)) {
                Forms::openContactActionMenu($player, $contactNames[$data - 1]);
            } else {
                Forms::openPhoneMain($player);
            }
        });

        $form->setTitle("§l§8[ §aКонтакты §8]");

        if (empty($contacts)) {
            $form->setContent(
                "§e§l--- Телефонная книга ---§r\n\n" .
                "§7Контактов пока нет.§r\n" .
                "§7Нажмите кнопку чтобы добавить.§r"
            );
        } else {
            $form->setContent(
                "§e§l--- Телефонная книга ---§r\n\n" .
                "§b§l> §fСохранено: §a" . count($contacts) . " §7контактов§r\n\n" .
                "§7Нажмите на контакт:§r"
            );
        }

        $form->addButton("§l§a+ Добавить\n§r§8Новый контакт");

        foreach ($contacts as $contactName => $contactData) {
            $cNumber = $contactData["number"] ?? "???";
            $isOnline = $plugin->getServer()->getPlayerExact($contactData["name"] ?? $contactName) !== null;
            $status = $isOnline ? "§aВ сети" : "§cОффлайн";
            $form->addButton("§l§f" . ($contactData["name"] ?? $contactName) . "\n§r" . $status . " §8| §7" . $cNumber);
        }

        $form->addButton("§l§cНазад");

        $player->sendForm($form);
    }

    public static function openAddContactForm(Player $player): void {
        $plugin = Main::getInstance();

        $onlinePlayers = [];
        foreach ($plugin->getServer()->getOnlinePlayers() as $p) {
            if ($p->getName() !== $player->getName() && $plugin->hasSim($p->getName())) {
                $onlinePlayers[] = $p->getName();
            }
        }

        $form = new CustomForm(function(Player $player, ?array $data) use ($onlinePlayers) {
            if ($data === null) return;
            $plugin = Main::getInstance();

            $inputNick = trim($data[1] ?? "");
            $dropdownIndex = (int)($data[2] ?? 0);

            $targetName = "";

            if ($inputNick !== "") {
                $found = $plugin->findPlayerByPartialName($inputNick);
                if ($found !== null) {
                    $targetName = $found;
                } else {
                    $player->sendMessage("§8§l[§cОшибка§8] §r§fИгрок §e" . $inputNick . " §fне найден.");
                    return;
                }
            } elseif (!empty($onlinePlayers) && $dropdownIndex > 0) {
                $targetName = $onlinePlayers[$dropdownIndex - 1];
            } else {
                $player->sendMessage("§8§l[§cОшибка§8] §r§fУкажите ник или выберите из списка.");
                return;
            }

            if (strtolower($targetName) === strtolower($player->getName())) {
                $player->sendMessage("§8§l[§cОшибка§8] §r§fНельзя добавить себя.");
                return;
            }
            if (!$plugin->hasSim($targetName)) {
                $player->sendMessage("§8§l[§cОшибка§8] §r§fУ §e" . $targetName . " §fнет сим-карты.");
                return;
            }

            $contacts = $plugin->getContacts($player->getName());
            if (isset($contacts[strtolower($targetName)])) {
                $player->sendMessage("§8§l[§cОшибка§8] §r§f" . $targetName . " уже в контактах.");
                return;
            }
            if (count($contacts) >= 20) {
                $player->sendMessage("§8§l[§cОшибка§8] §r§fМаксимум 20 контактов.");
                return;
            }

            $plugin->addContact($player->getName(), $targetName);
            $number = $plugin->getPhoneNumber($targetName);
            $player->sendMessage("§8§l[§aКонтакты§8] §r§e" . $targetName . " §f(§b" . $number . "§f) добавлен!");
        });

        $form->setTitle("§l§8[ §a+ Контакт §8]");

        $dropdownList = ["§7-- Не выбрано --"];
        foreach ($onlinePlayers as $op) {
            $dropdownList[] = $op . " | " . $plugin->getPhoneNumber($op);
        }

        $form->addLabel(
            "§e§l--- Добавление контакта ---§r\n\n" .
            "§7Введите ник или выберите из онлайна.§r\n" .
            "§7Можно ввести часть ника.§r"
        );
        $form->addInput("§fВвести ник:", "Часть ника");
        $form->addDropdown("§fВыбрать из онлайна:", $dropdownList);

        $player->sendForm($form);
    }

    public static function openContactActionMenu(Player $player, string $contactName): void {
        $plugin = Main::getInstance();
        $contacts = $plugin->getContacts($player->getName());

        if (!isset($contacts[$contactName])) {
            $player->sendMessage("§8§l[§cОшибка§8] §r§fКонтакт не найден.");
            return;
        }

        $contactData = $contacts[$contactName];
        $realName = $contactData["name"] ?? $contactName;
        $cNumber = $contactData["number"] ?? "???";
        $isOnline = $plugin->getServer()->getPlayerExact($realName) !== null;
        $status = $isOnline ? "§a§lВ сети" : "§c§lОффлайн";

        $form = new SimpleForm(function(Player $player, ?int $data) use ($contactName) {
            if ($data === null) return;
            match ($data) {
                0 => Forms::openContactTransferForm($player, $contactName),
                1 => Forms::openContactSmsForm($player, $contactName),
                2 => Forms::openDeleteContactConfirm($player, $contactName),
                3 => Forms::openContactsMenu($player),
                default => null
            };
        });

        $form->setTitle("§l§8[ §f" . $realName . " §8]");
        $form->setContent(
            "§e§l--- Контакт ---§r\n\n" .
            "§b§l> §fИмя: §e§l" . $realName . "§r\n" .
            "§b§l> §fНомер: §b" . $cNumber . "§r\n" .
            "§b§l> §fСтатус: " . $status . "§r\n\n" .
            "§e§l--- Действия ---§r"
        );

        $form->addButton("§l§6Перевести деньги\n§r§8Отправить средства");
        $form->addButton("§l§9Написать СМС\n§r§8Отправить сообщение");
        $form->addButton("§l§cУдалить\n§r§8Убрать из контактов");
        $form->addButton("§l§7Назад");

        $player->sendForm($form);
    }

    public static function openContactTransferForm(Player $player, string $contactName): void {
        $plugin = Main::getInstance();
        $contacts = $plugin->getContacts($player->getName());
        $realName = $contacts[$contactName]["name"] ?? $contactName;
        $phoneBalance = $plugin->getPhoneBalance($player->getName());
        $remaining = $plugin->getRemainingLimit($player->getName());

        $form = new CustomForm(function(Player $player, ?array $data) use ($contactName, $realName) {
            if ($data === null) return;
            $plugin = Main::getInstance();
            $amount = (float)($data[1] ?? 0);

            if ($amount <= 0) {
                $player->sendMessage("§8§l[§cОшибка§8] §r§fУкажите сумму.");
                return;
            }
            if (!$plugin->hasSim($realName) || !$plugin->hasPhone($realName)) {
                $player->sendMessage("§8§l[§cОшибка§8] §r§fУ §e" . $realName . " §fнет телефона.");
                return;
            }
            if ($amount > $plugin->getRemainingLimit($player->getName())) {
                $player->sendMessage("§8§l[§cОшибка§8] §r§fПревышен лимит.");
                return;
            }
            if (!$plugin->takePhoneBalance($player->getName(), $amount)) {
                $player->sendMessage("§8§l[§cОшибка§8] §r§fНедостаточно средств.");
                return;
            }

            $plugin->addDailyTransferred($player->getName(), $amount);

            $targetPlayer = $plugin->getServer()->getPlayerExact($realName);
            if ($targetPlayer !== null) {
                $plugin->addPhoneBalance($targetPlayer->getName(), $amount);
                $targetPlayer->sendMessage("§8§l[§aПеревод§8] §r§fОт §b" . $player->getName() . " §f- §e" . number_format($amount, 2) . "р.");
            } else {
                $plugin->addPhoneBalance($realName, $amount);
                $plugin->addPendingTransfer($realName, $player->getName(), $amount);
            }

            $player->sendMessage("§8§l[§aПеревод§8] §r§e" . number_format($amount, 2) . "р. §fотправлено §b" . $realName . "§f.");
        });

        $form->setTitle("§l§8[ §6Перевод §8]");
        $form->addLabel(
            "§e§l--- Перевод контакту ---§r\n\n" .
            "§b§l> §fКому: §e§l" . $realName . "§r\n" .
            "§b§l> §fВаш баланс: §6" . number_format($phoneBalance, 2) . "р.§r\n" .
            "§b§l> §fОстаток лимита: §a" . number_format($remaining, 2) . "р.§r"
        );
        $form->addInput("§fСумма:", "1000");

        $player->sendForm($form);
    }

    public static function openContactSmsForm(Player $player, string $contactName): void {
        $plugin = Main::getInstance();
        $contacts = $plugin->getContacts($player->getName());
        $realName = $contacts[$contactName]["name"] ?? $contactName;
        $smsPrice = $plugin->getConfig()->get("sms-price", 70);
        $phoneBalance = $plugin->getPhoneBalance($player->getName());

        $form = new CustomForm(function(Player $player, ?array $data) use ($contactName, $realName) {
            if ($data === null) return;
            $plugin = Main::getInstance();
            $message = trim($data[1] ?? "");
            $smsPrice = $plugin->getConfig()->get("sms-price", 70);

            if ($message === "") {
                $player->sendMessage("§8§l[§cОшибка§8] §r§fВведите текст.");
                return;
            }
            if (!$plugin->hasSim($realName) || !$plugin->hasPhone($realName)) {
                $player->sendMessage("§8§l[§cОшибка§8] §r§fУ §e" . $realName . " §fнет телефона.");
                return;
            }
            if (!$plugin->takePhoneBalance($player->getName(), (float)$smsPrice)) {
                $player->sendMessage("§8§l[§cОшибка§8] §r§fНедостаточно средств. Нужно §e" . $smsPrice . "р.");
                return;
            }

            $plugin->addSmsMessage($realName, $player->getName(), $message);

            $targetPlayer = $plugin->getServer()->getPlayerExact($realName);
            if ($targetPlayer !== null) {
                $targetPlayer->sendMessage("§8§l[§9СМС§8] §r§fОт §b" . $player->getName() . "§f: §7\"" . $message . "\"");
            }

            $player->sendMessage("§8§l[§aСМС§8] §r§fОтправлено §b" . $realName . "§f. Списано §e" . $smsPrice . "р.");
        });

        $form->setTitle("§l§8[ §9СМС §8]");
        $form->addLabel(
            "§e§l--- СМС контакту ---§r\n\n" .
            "§b§l> §fКому: §e§l" . $realName . "§r\n" .
            "§b§l> §fЦена: §e" . $smsPrice . "р.§r\n" .
            "§b§l> §fБаланс: §6" . number_format($phoneBalance, 2) . "р.§r"
        );
        $form->addInput("§fСообщение:", "Текст...");

        $player->sendForm($form);
    }

    public static function openDeleteContactConfirm(Player $player, string $contactName): void {
        $plugin = Main::getInstance();
        $contacts = $plugin->getContacts($player->getName());
        $realName = $contacts[$contactName]["name"] ?? $contactName;

        $form = new ModalForm(function(Player $player, ?bool $data) use ($contactName, $realName) {
            if ($data === null || $data === false) {
                Forms::openContactActionMenu($player, $contactName);
                return;
            }
            $plugin = Main::getInstance();
            $plugin->removeContact($player->getName(), $contactName);
            $player->sendMessage("§8§l[§aКонтакты§8] §r§e" . $realName . " §fудалён.");
            Forms::openContactsMenu($player);
        });

        $form->setTitle("§l§8[ §cУдаление §8]");
        $form->setContent(
            "§e§l--- Подтверждение ---§r\n\n" .
            "§fУдалить §e§l" . $realName . " §r§fиз контактов?\n\n" .
            "§7Отменить нельзя.§r"
        );
        $form->setButton1("§l§cДа, удалить");
        $form->setButton2("§l§aОтмена");

        $player->sendForm($form);
    }

    // ==================== МАГАЗИН ====================

    public static function openShopMenu(Player $player): void {
        $plugin = Main::getInstance();
        $simPrice = $plugin->getConfig()->get("sim-price", 600);
        $phonePrice = $plugin->getConfig()->get("phone-price", 1600);
        $hasSim = $plugin->hasSim($player->getName());
        $hasPhone = $plugin->hasPhone($player->getName());

        $form = new SimpleForm(function(Player $player, ?int $data) {
            if ($data === null) return;
            $plugin = Main::getInstance();
            match ($data) {
                0 => $plugin->buySim($player),
                1 => $plugin->buyPhone($player),
                default => null
            };
        });

        $form->setTitle("§l§8[ §6Салон связи §8]");

        $sSim = $hasSim ? "§a§lЕсть" : "§c§lНет";
        $sPhone = $hasPhone ? "§a§lЕсть" : "§c§lНет";
        $numText = $hasSim ? "\n§b§l> §fНомер: §b" . $plugin->getPhoneNumber($player->getName()) : "";

        $form->setContent(
            "§e§l--- Салон связи ---§r\n\n" .
            "§b§l> §fСим-карта: " . $sSim . "§r\n" .
            "§b§l> §fТелефон: " . $sPhone . "§r" . $numText . "\n\n" .
            "§e§l--- Товары ---§r"
        );

        $form->addButton("§l§fСим-карта\n§r§8" . number_format($simPrice) . " руб.");
        $form->addButton("§l§fТелефон\n§r§8" . number_format($phonePrice) . " руб.");
        $form->addButton("§l§cЗакрыть");

        $player->sendForm($form);
    }

    // ==================== БАНК ====================

    public static function openBankMainMenu(Player $player): void {
        $plugin = Main::getInstance();
        $name = $player->getName();
        $accounts = $plugin->getPlayerAccounts($name);
        $accountCount = count($accounts);
        $accountIds = array_keys($accounts);

        $form = new SimpleForm(function(Player $player, ?int $data) use ($accountIds) {
            if ($data === null) return;
            $plugin = Main::getInstance();
            if ($data === 0) {
                Forms::openCreateAccountForm($player);
            } elseif ($data <= count($accountIds)) {
                $accId = $accountIds[$data - 1];
                if ($plugin->hasPinSession($player->getName(), $accId)) {
                    Forms::openAccountMenu($player, $accId);
                } else {
                    Forms::openPinForm($player, $accId);
                }
            }
        });

        $form->setTitle("§l§8[ §3Банк §8]");
        $form->setContent(
            "§e§l--- Городской банк ---§r\n\n" .
            "§b§l> §fКлиент: §e§l" . $name . "§r\n" .
            "§b§l> §fСчетов: §a" . $accountCount . "§f/§a3§r\n\n" .
            "§e§l--- Счета ---§r"
        );

        $form->addButton("§l§a+ Новый счёт\n§r§8Открыть счёт");
        foreach ($accounts as $accId => $accData) {
            $form->addButton("§l§f" . $accData["name"] . "\n§r§8" . number_format($accData["balance"], 2) . " руб.");
        }
        $form->addButton("§l§cНазад");

        $player->sendForm($form);
    }

    public static function openCreateAccountForm(Player $player): void {
        $plugin = Main::getInstance();
        if ($plugin->getAccountCount($player->getName()) >= 3) {
            $player->sendMessage("§8§l[§cОшибка§8] §r§fМаксимум 3 счёта.");
            return;
        }

        $form = new CustomForm(function(Player $player, ?array $data) {
            if ($data === null) return;
            $plugin = Main::getInstance();
            $accountName = trim($data[1] ?? "");
            $pin = trim($data[2] ?? "");

            if ($accountName === "") {
                $player->sendMessage("§8§l[§cОшибка§8] §r§fУкажите название.");
                return;
            }
            if (strlen($pin) < 4 || strlen($pin) > 6 || !ctype_digit($pin)) {
                $player->sendMessage("§8§l[§cОшибка§8] §r§fПИН: 4-6 цифр.");
                return;
            }

            $accId = $plugin->createAccount($player->getName(), $accountName, $pin);
            if ($accId !== null) {
                $player->sendMessage("§8§l[§aБанк§8] §r§fСчёт §e" . $accountName . " §fсоздан!");
                $player->sendMessage("§8§l[§aБанк§8] §r§fID: §b" . $accId . " §f| ПИН: §e§l" . $pin);
            }
        });

        $form->setTitle("§l§8[ §3Новый счёт §8]");
        $form->addLabel(
            "§e§l--- Открытие счёта ---§r\n\n" .
            "§7Придумайте название и ПИН.§r\n" .
            "§c§lПИН: 4-6 цифр, запомните!§r"
        );
        $form->addInput("§fНазвание:", "Основной");
        $form->addInput("§fПИН-код:", "1234");

        $player->sendForm($form);
    }

    public static function openPinForm(Player $player, string $accountId): void {
        $plugin = Main::getInstance();
        $accounts = $plugin->getPlayerAccounts($player->getName());
        $accName = $accounts[$accountId]["name"] ?? "???";

        $form = new CustomForm(function(Player $player, ?array $data) use ($accountId) {
            if ($data === null) return;
            $plugin = Main::getInstance();
            $pin = trim($data[1] ?? "");
            if ($plugin->verifyPin($player->getName(), $accountId, $pin)) {
                $plugin->setPinSession($player->getName(), $accountId);
                $player->sendMessage("§8§l[§aБанк§8] §r§fДоступ разрешён.");
                Forms::openAccountMenu($player, $accountId);
            } else {
                $player->sendMessage("§8§l[§cОшибка§8] §r§fНеверный ПИН.");
            }
        });

        $form->setTitle("§l§8[ §3ПИН-код §8]");
        $form->addLabel(
            "§e§l--- Авторизация ---§r\n\n" .
            "§b§l> §fСчёт: §e" . $accName . "§r\n\n" .
            "§7Введите ПИН для доступа:§r"
        );
        $form->addInput("§fПИН:", "****");

        $player->sendForm($form);
    }

    public static function openAccountMenu(Player $player, string $accountId): void {
        $plugin = Main::getInstance();
        $name = $player->getName();
        $accounts = $plugin->getPlayerAccounts($name);
        if (!isset($accounts[$accountId])) return;

        $account = $accounts[$accountId];
        $deposits = $plugin->getDeposits($name, $accountId);

        $form = new SimpleForm(function(Player $player, ?int $data) use ($accountId) {
            if ($data === null) return;
            match ($data) {
                0 => Forms::openDepositToAccountForm($player, $accountId),
                1 => Forms::openWithdrawForm($player, $accountId),
                2 => Forms::openTopUpPhoneForm($player, $accountId),
                3 => Forms::openDepositMenu($player, $accountId),
                4 => Forms::openBankMainMenu($player),
                default => null
            };
        });

        $form->setTitle("§l§8[ §3" . $account["name"] . " §8]");
        $form->setContent(
            "§e§l--- Информация ---§r\n\n" .
            "§b§l> §fНазвание: §e§l" . $account["name"] . "§r\n" .
            "§b§l> §fID: §b" . $accountId . "§r\n" .
            "§b§l> §fВладелец: §a" . $name . "§r\n" .
            "§b§l> §fБаланс: §6§l" . number_format($account["balance"], 2) . " руб.§r\n" .
            "§b§l> §fВкладов: §d" . count($deposits) . "§r\n" .
            "§b§l> §fОткрыт: §7" . date("d.m.Y", $account["created"]) . "§r\n\n" .
            "§e§l--- Операции ---§r"
        );

        $form->addButton("§l§aПополнить\n§r§8Внести наличные");
        $form->addButton("§l§6Снять\n§r§8Получить наличные");
        $form->addButton("§l§bНа телефон\n§r§8Пополнить номер");
        $form->addButton("§l§dДепозиты\n§r§8Вклады");
        $form->addButton("§l§cНазад");

        $player->sendForm($form);
    }

    public static function openDepositToAccountForm(Player $player, string $accountId): void {
        $plugin = Main::getInstance();
        $accounts = $plugin->getPlayerAccounts($player->getName());
        $cash = $plugin->getMoney($player->getName());

        $form = new CustomForm(function(Player $player, ?array $data) use ($accountId) {
            if ($data === null) return;
            $plugin = Main::getInstance();
            $amount = (float)($data[1] ?? 0);
            if ($amount <= 0) {
                $player->sendMessage("§8§l[§cОшибка§8] §r§fУкажите сумму.");
                return;
            }
            if ($plugin->getMoney($player->getName()) < $amount) {
                $player->sendMessage("§8§l[§cОшибка§8] §r§fНедостаточно наличных.");
                return;
            }
            $plugin->takeMoney($player->getName(), $amount);
            $plugin->addAccountBalance($player->getName(), $accountId, $amount);
            $nb = $plugin->getAccountBalance($player->getName(), $accountId);
            $player->sendMessage("§8§l[§aБанк§8] §r§fЗачислено §e" . number_format($amount, 2) . "р. §fБаланс: §6" . number_format($nb, 2) . "р.");
        });

        $form->setTitle("§l§8[ §aПополнение §8]");
        $form->addLabel(
            "§e§l--- Внесение средств ---§r\n\n" .
            "§b§l> §fНаличные: §6" . number_format($cash, 2) . "р.§r\n" .
            "§b§l> §fНа счёте: §e" . number_format($accounts[$accountId]["balance"], 2) . "р.§r"
        );
        $form->addInput("§fСумма:", "5000");

        $player->sendForm($form);
    }

    public static function openWithdrawForm(Player $player, string $accountId): void {
        $plugin = Main::getInstance();
        $accounts = $plugin->getPlayerAccounts($player->getName());

        $form = new CustomForm(function(Player $player, ?array $data) use ($accountId) {
            if ($data === null) return;
            $plugin = Main::getInstance();
            $amount = (float)($data[1] ?? 0);
            if ($amount <= 0) {
                $player->sendMessage("§8§l[§cОшибка§8] §r§fУкажите сумму.");
                return;
            }
            if ($plugin->takeAccountBalance($player->getName(), $accountId, $amount)) {
                $plugin->addMoney($player->getName(), $amount);
                $nb = $plugin->getAccountBalance($player->getName(), $accountId);
                $player->sendMessage("§8§l[§aБанк§8] §r§fСнято §e" . number_format($amount, 2) . "р. §fОстаток: §6" . number_format($nb, 2) . "р.");
            } else {
                $player->sendMessage("§8§l[§cОшибка§8] §r§fНедостаточно средств.");
            }
        });

        $form->setTitle("§l§8[ §6Снятие §8]");
        $form->addLabel(
            "§e§l--- Снятие средств ---§r\n\n" .
            "§b§l> §fНа счёте: §6" . number_format($accounts[$accountId]["balance"], 2) . "р.§r"
        );
        $form->addInput("§fСумма:", "3000");

        $player->sendForm($form);
    }

    public static function openTopUpPhoneForm(Player $player, string $accountId): void {
        $plugin = Main::getInstance();
        $accounts = $plugin->getPlayerAccounts($player->getName());
        $phoneBalance = $plugin->getPhoneBalance($player->getName());
        $phoneNumber = $plugin->getPhoneNumber($player->getName());

        $form = new CustomForm(function(Player $player, ?array $data) use ($accountId) {
            if ($data === null) return;
            $plugin = Main::getInstance();
            $amount = (float)($data[1] ?? 0);
            if ($amount <= 0) {
                $player->sendMessage("§8§l[§cОшибка§8] §r§fУкажите сумму.");
                return;
            }
            if (!$plugin->hasSim($player->getName())) {
                $player->sendMessage("§8§l[§cОшибка§8] §r§fНет сим-карты.");
                return;
            }
            if ($plugin->takeAccountBalance($player->getName(), $accountId, $amount)) {
                $plugin->addPhoneBalance($player->getName(), $amount);
                $nb = $plugin->getPhoneBalance($player->getName());
                $player->sendMessage("§8§l[§aБанк§8] §r§fНомер пополнен на §e" . number_format($amount, 2) . "р. §fБаланс: §a" . number_format($nb, 2) . "р.");
            } else {
                $player->sendMessage("§8§l[§cОшибка§8] §r§fНедостаточно средств на счёте.");
            }
        });

        $form->setTitle("§l§8[ §bНа телефон §8]");
        $form->addLabel(
            "§e§l--- Пополнение номера ---§r\n\n" .
            "§b§l> §fНомер: §b" . $phoneNumber . "§r\n" .
            "§b§l> §fБаланс номера: §a" . number_format($phoneBalance, 2) . "р.§r\n" .
            "§b§l> §fНа счёте: §6" . number_format($accounts[$accountId]["balance"], 2) . "р.§r"
        );
        $form->addInput("§fСумма:", "500");

        $player->sendForm($form);
    }

    // ==================== ДЕПОЗИТЫ ====================

    public static function openDepositMenu(Player $player, string $accountId): void {
        $plugin = Main::getInstance();
        $deposits = $plugin->getDeposits($player->getName(), $accountId);
        $accounts = $plugin->getPlayerAccounts($player->getName());
        $depositIds = array_keys($deposits);

        $form = new SimpleForm(function(Player $player, ?int $data) use ($accountId, $depositIds) {
            if ($data === null) return;
            if ($data === 0) {
                Forms::openCreateDepositForm($player, $accountId);
            } elseif ($data <= count($depositIds)) {
                Forms::openDepositDetailsMenu($player, $accountId, $depositIds[$data - 1]);
            } else {
                Forms::openAccountMenu($player, $accountId);
            }
        });

        $form->setTitle("§l§8[ §dДепозиты §8]");

        $info = empty($deposits) ? "§7Нет вкладов.§r" : "§7Нажмите на вклад:§r";

        $form->setContent(
            "§e§l--- Вклады ---§r\n\n" .
            "§b§l> §fНа счёте: §6" . number_format($accounts[$accountId]["balance"], 2) . "р.§r\n" .
            "§b§l> §fВкладов: §d" . count($deposits) . "§r\n\n" . $info
        );

        $form->addButton("§l§a+ Новый вклад\n§r§8Открыть депозит");
        foreach ($deposits as $depId => $dep) {
            $daysLeft = max(0, (int)(($dep["expires"] - time()) / 86400));
            $form->addButton("§l§d" . $depId . "\n§r§8" . number_format($dep["amount"], 2) . "р. | " . $daysLeft . " дн.");
        }
        $form->addButton("§l§cНазад");

        $player->sendForm($form);
    }

    public static function openCreateDepositForm(Player $player, string $accountId): void {
        $plugin = Main::getInstance();
        $rates = $plugin->getConfig()->get("deposit-rates", []);
        $dropdownOptions = [];
        $dropdownDays = [];
        $ratesText = "";

        foreach ($rates as $days => $rateData) {
            $dropdownOptions[] = $rateData["name"] . " - " . $rateData["percent"] . "%";
            $dropdownDays[] = (int)$days;
            $ratesText .= "§b§l> §f" . $rateData["name"] . ": §a" . $rateData["percent"] . "%§r\n";
        }

        $accounts = $plugin->getPlayerAccounts($player->getName());

        $form = new CustomForm(function(Player $player, ?array $data) use ($accountId, $dropdownDays) {
            if ($data === null) return;
            $plugin = Main::getInstance();
            $periodIndex = (int)($data[1] ?? 0);
            $amount = (float)($data[2] ?? 0);

            if ($amount < 100) {
                $player->sendMessage("§8§l[§cОшибка§8] §r§fМинимум §e100р.");
                return;
            }

            $days = $dropdownDays[$periodIndex] ?? 7;
            $rates = $plugin->getConfig()->get("deposit-rates", []);
            $percent = $rates[$days]["percent"] ?? 5;

            if ($plugin->createDeposit($player->getName(), $accountId, $amount, $days)) {
                $player->sendMessage("§8§l[§aБанк§8] §r§fВклад: §e" . number_format($amount, 2) . "р. §fна §b" . $days . " дн. §fпод §a" . $percent . "%§f.");
            } else {
                $player->sendMessage("§8§l[§cОшибка§8] §r§fНедостаточно средств.");
            }
        });

        $form->setTitle("§l§8[ §dНовый вклад §8]");
        $form->addLabel(
            "§e§l--- Открытие вклада ---§r\n\n" .
            "§b§l> §fНа счёте: §6" . number_format($accounts[$accountId]["balance"], 2) . "р.§r\n" .
            "§b§l> §fМинимум: §e100р.§r\n\n" .
            "§e§lСтавки:§r\n" . $ratesText
        );
        $form->addDropdown("§fСрок:", $dropdownOptions);
        $form->addInput("§fСумма:", "10000");

        $player->sendForm($form);
    }

    public static function openDepositDetailsMenu(Player $player, string $accountId, string $depositId): void {
        $plugin = Main::getInstance();
        $deposits = $plugin->getDeposits($player->getName(), $accountId);
        if (!isset($deposits[$depositId])) return;

        $dep = $deposits[$depositId];
        $daysLeft = max(0, (int)(($dep["expires"] - time()) / 86400));
        $profit = $dep["amount"] - $dep["original_amount"];
        $isExpired = time() >= $dep["expires"];
        $statusText = $isExpired ? "§a§lЗавершён" : "§e§lАктивен";

        $form = new SimpleForm(function(Player $player, ?int $data) use ($accountId, $depositId) {
            if ($data === null) return;
            $plugin = Main::getInstance();
            match ($data) {
                0 => (function() use ($plugin, $player, $accountId, $depositId) {
                    $amount = $plugin->withdrawDeposit($player->getName(), $accountId, $depositId);
                    if ($amount > 0) {
                        $player->sendMessage("§8§l[§aБанк§8] §r§fВклад снят: §e" . number_format($amount, 2) . "р. §fна счёт.");
                    }
                })(),
                1 => Forms::openAddToDepositForm($player, $accountId, $depositId),
                2 => Forms::openDepositMenu($player, $accountId),
                default => null
            };
        });

        $form->setTitle("§l§8[ §d" . $depositId . " §8]");
        $form->setContent(
            "§e§l--- Вклад ---§r\n\n" .
            "§b§l> §fID: §d" . $depositId . "§r\n" .
            "§b§l> §fВложено: §7" . number_format($dep["original_amount"], 2) . "р.§r\n" .
            "§b§l> §fСейчас: §6§l" . number_format($dep["amount"], 2) . "р.§r\n" .
            "§b§l> §fДоход: §a+" . number_format($profit, 2) . "р.§r\n" .
            "§b§l> §fСтавка: §a" . $dep["percent"] . "%§r\n" .
            "§b§l> §fСрок: §b" . $dep["days"] . " дн.§r\n" .
            "§b§l> §fОсталось: §b" . $daysLeft . " дн.§r\n" .
            "§b§l> §fОткрыт: §7" . date("d.m.Y", $dep["created"]) . "§r\n" .
            "§b§l> §fСтатус: " . $statusText . "§r\n\n" .
            "§e§l--- Действия ---§r"
        );

        $form->addButton("§l§6Снять вклад\n§r§8Закрыть депозит");
        $form->addButton("§l§aПополнить\n§r§8Добавить средства");
        $form->addButton("§l§cНазад");

        $player->sendForm($form);
    }

    public static function openAddToDepositForm(Player $player, string $accountId, string $depositId): void {
        $plugin = Main::getInstance();
        $accounts = $plugin->getPlayerAccounts($player->getName());

        $form = new CustomForm(function(Player $player, ?array $data) use ($accountId, $depositId) {
            if ($data === null) return;
            $plugin = Main::getInstance();
            $amount = (float)($data[1] ?? 0);
            if ($amount <= 0) {
                $player->sendMessage("§8§l[§cОшибка§8] §r§fУкажите сумму.");
                return;
            }
            if ($plugin->addToDeposit($player->getName(), $accountId, $depositId, $amount)) {
                $player->sendMessage("§8§l[§aБанк§8] §r§fВклад пополнен на §e" . number_format($amount, 2) . "р.");
            } else {
                $player->sendMessage("§8§l[§cОшибка§8] §r§fНедостаточно средств.");
            }
        });

        $form->setTitle("§l§8[ §a+ Вклад §8]");
        $form->addLabel(
            "§e§l--- Пополнение вклада ---§r\n\n" .
            "§b§l> §fВклад: §d" . $depositId . "§r\n" .
            "§b§l> §fНа счёте: §6" . number_format($accounts[$accountId]["balance"], 2) . "р.§r"
        );
        $form->addInput("§fСумма:", "5000");

        $player->sendForm($form);
    }

    // ==================== ТАКСИ ====================

    public static function openTaxiMainMenu(Player $player): void {
        $plugin = Main::getInstance();
        $categories = $plugin->getTaxiCategories();
        $categoryKeys = array_keys($categories);
        $phoneBalance = $plugin->getPhoneBalance($player->getName());

        $form = new SimpleForm(function(Player $player, ?int $data) use ($categoryKeys) {
            if ($data === null) return;
            if ($data < count($categoryKeys)) {
                Forms::openTaxiCategoryMenu($player, $categoryKeys[$data]);
            }
        });

        $form->setTitle("§l§8[ §eТакси §8]");
        $form->setContent(
            "§e§l--- Служба такси ---§r\n\n" .
            "§b§l> §fБаланс номера: §6" . number_format($phoneBalance, 2) . "р.§r\n\n" .
            "§7Цена зависит от расстояния.§r\n" .
            "§7Оплата с баланса номера.§r\n\n" .
            "§e§l--- Категории ---§r"
        );

        foreach ($categories as $cat) {
            $form->addButton("§l§f" . $cat["name"] . "\n§r§8" . $cat["desc"]);
        }
        $form->addButton("§l§cНазад");

        $player->sendForm($form);
    }

    public static function openTaxiCategoryMenu(Player $player, string $category): void {
        $plugin = Main::getInstance();
        $points = $plugin->getConfig()->getNested("taxi-points." . $category, []);
        if (empty($points)) {
            $player->sendMessage("§8§l[§cОшибка§8] §r§fНет точек.");
            return;
        }

        $categories = $plugin->getTaxiCategories();
        $pointNames = array_keys($points);
        $phoneBalance = $plugin->getPhoneBalance($player->getName());

        // Предрассчитываем цены
        $prices = [];
        foreach ($points as $pName => $coords) {
            $prices[$pName] = $plugin->calculateTaxiPrice($player, (float)$coords["x"], (float)$coords["y"], (float)$coords["z"], (string)$coords["world"]);
        }

        $form = new SimpleForm(function(Player $player, ?int $data) use ($pointNames, $points, $prices) {
            if ($data === null) return;
            if ($data < count($pointNames)) {
                $destination = $pointNames[$data];
                $coords = $points[$destination];
                $price = $prices[$destination];
                $plugin = Main::getInstance();

                // Сразу телепорт без подтверждения
                if (!$plugin->takePhoneBalance($player->getName(), $price)) {
                    $player->sendMessage("§8§l[§cТакси§8] §r§fНедостаточно средств. Нужно §e" . number_format($price) . "р.");
                    return;
                }

                $world = $plugin->getServer()->getWorldManager()->getWorldByName($coords["world"]);
                if ($world === null) {
                    $plugin->addPhoneBalance($player->getName(), $price);
                    $player->sendMessage("§8§l[§cТакси§8] §r§fМаршрут недоступен. Деньги возвращены.");
                    return;
                }

                $player->teleport(new Position((float)$coords["x"], (float)$coords["y"], (float)$coords["z"], $world));
                $player->sendMessage("§8§l[§aТакси§8] §r§fВы прибыли: §e" . $destination);
                $player->sendMessage("§8§l[§aТакси§8] §r§fСписано §6" . number_format($price) . "р. §fс номера.");
            } else {
                Forms::openTaxiMainMenu($player);
            }
        });

        $catName = $categories[$category]["name"] ?? "Категория";
        $form->setTitle("§l§8[ §e" . $catName . " §8]");
        $form->setContent(
            "§e§l--- " . $catName . " ---§r\n\n" .
            "§b§l> §fБаланс: §6" . number_format($phoneBalance, 2) . "р.§r\n\n" .
            "§7Нажмите для мгновенной поездки:§r"
        );

        foreach ($points as $pointName => $coords) {
            $price = $prices[$pointName];
            $canAfford = $phoneBalance >= $price;
            $priceColor = $canAfford ? "§a" : "§c";
            $form->addButton("§l§f" . $pointName . "\n§r" . $priceColor . number_format($price) . " руб.");
        }
        $form->addButton("§l§cНазад");

        $player->sendForm($form);
    }

    // ==================== ПЕРЕВОДЫ ====================

    public static function openTransferMenu(Player $player): void {
        $plugin = Main::getInstance();
        $limit = $plugin->getConfig()->get("transfer-daily-limit", 100000);
        $transferred = $plugin->getDailyTransferred($player->getName());
        $remaining = $plugin->getRemainingLimit($player->getName());
        $phoneBalance = $plugin->getPhoneBalance($player->getName());

        $form = new CustomForm(function(Player $player, ?array $data) {
            if ($data === null) return;
            $plugin = Main::getInstance();
            $targetInput = trim($data[1] ?? "");
            $amount = (float)($data[2] ?? 0);

            if ($targetInput === "" || $amount <= 0) {
                $player->sendMessage("§8§l[§cОшибка§8] §r§fЗаполните все поля.");
                return;
            }

            $targetName = $plugin->findPlayerByPartialName($targetInput);
            if ($targetName === null) {
                $player->sendMessage("§8§l[§cОшибка§8] §r§fИгрок не найден.");
                return;
            }
            if (strtolower($targetName) === strtolower($player->getName())) {
                $player->sendMessage("§8§l[§cОшибка§8] §r§fНельзя перевести себе.");
                return;
            }
            if (!$plugin->hasSim($targetName) || !$plugin->hasPhone($targetName)) {
                $player->sendMessage("§8§l[§cОшибка§8] §r§fУ §e" . $targetName . " §fнет телефона.");
                return;
            }
            if ($amount > $plugin->getRemainingLimit($player->getName())) {
                $player->sendMessage("§8§l[§cОшибка§8] §r§fПревышен лимит.");
                return;
            }
            if (!$plugin->takePhoneBalance($player->getName(), $amount)) {
                $player->sendMessage("§8§l[§cОшибка§8] §r§fНедостаточно средств.");
                return;
            }

            $plugin->addDailyTransferred($player->getName(), $amount);

            $targetPlayer = $plugin->getServer()->getPlayerByPrefix($targetInput);
            if ($targetPlayer !== null) {
                $plugin->addPhoneBalance($targetPlayer->getName(), $amount);
                $targetPlayer->sendMessage("§8§l[§aПеревод§8] §r§fОт §b" . $player->getName() . " §f- §e" . number_format($amount, 2) . "р.");
            } else {
                $plugin->addPhoneBalance($targetName, $amount);
                $plugin->addPendingTransfer($targetName, $player->getName(), $amount);
            }

            $nb = $plugin->getPhoneBalance($player->getName());
            $player->sendMessage("§8§l[§aПеревод§8] §r§e" . number_format($amount, 2) . "р. §fотправлено §b" . $targetName . "§f. Остаток: §6" . number_format($nb, 2) . "р.");
        });

        $form->setTitle("§l§8[ §6Переводы §8]");
        $form->addLabel(
            "§e§l--- Денежный перевод ---§r\n\n" .
            "§b§l> §fЛимит 24ч: §e" . number_format($limit) . "р.§r\n" .
            "§b§l> §fОтправлено: §6" . number_format($transferred, 2) . "р.§r\n" .
            "§b§l> §fОсталось: §a" . number_format($remaining, 2) . "р.§r\n" .
            "§b§l> §fБаланс: §b" . number_format($phoneBalance, 2) . "р.§r\n\n" .
            "§7Можно ввести часть ника.§r"
        );
        $form->addInput("§fНик получателя:", "Часть ника");
        $form->addInput("§fСумма:", "5000");

        $player->sendForm($form);
    }

    // ==================== СМС ====================

    public static function openSmsMenu(Player $player): void {
        $plugin = Main::getInstance();
        $smsPrice = $plugin->getConfig()->get("sms-price", 70);
        $unread = $plugin->getUnreadSmsCount($player->getName());
        $phoneBalance = $plugin->getPhoneBalance($player->getName());
        $totalMessages = count($plugin->getSmsInbox($player->getName()));

        $form = new SimpleForm(function(Player $player, ?int $data) {
            if ($data === null) return;
            match ($data) {
                0 => Forms::openWriteSmsForm($player),
                1 => Forms::openSmsInboxForm($player),
                default => null
            };
        });

        $form->setTitle("§l§8[ §9СМС §8]");
        $form->setContent(
            "§e§l--- Сообщения ---§r\n\n" .
            "§b§l> §fЦена СМС: §e" . $smsPrice . "р.§r\n" .
            "§b§l> §fБаланс: §b" . number_format($phoneBalance, 2) . "р.§r\n" .
            "§b§l> §fНовых: §c" . $unread . "§r\n" .
            "§b§l> §fВсего: §7" . $totalMessages . "§r\n\n" .
            "§e§l--- Действия ---§r"
        );

        $form->addButton("§l§fНаписать\n§r§8Отправить СМС");
        $form->addButton("§l§fВходящие §8[§c" . $unread . "§8]\n§r§8Прочитать");
        $form->addButton("§l§cНазад");

        $player->sendForm($form);
    }

    public static function openWriteSmsForm(Player $player): void {
        $plugin = Main::getInstance();
        $smsPrice = $plugin->getConfig()->get("sms-price", 70);

        $form = new CustomForm(function(Player $player, ?array $data) {
            if ($data === null) return;
            $plugin = Main::getInstance();
            $targetInput = trim($data[1] ?? "");
            $message = trim($data[2] ?? "");
            $smsPrice = $plugin->getConfig()->get("sms-price", 70);

            if ($targetInput === "" || $message === "") {
                $player->sendMessage("§8§l[§cОшибка§8] §r§fЗаполните все поля.");
                return;
            }

            $targetName = $plugin->findPlayerByPartialName($targetInput);
            if ($targetName === null) {
                $player->sendMessage("§8§l[§cОшибка§8] §r§fАбонент не найден.");
                return;
            }
            if (strtolower($targetName) === strtolower($player->getName())) {
                $player->sendMessage("§8§l[§cОшибка§8] §r§fНельзя отправить себе.");
                return;
            }
            if (!$plugin->hasSim($targetName) || !$plugin->hasPhone($targetName)) {
                $player->sendMessage("§8§l[§cОшибка§8] §r§fУ §e" . $targetName . " §fнет телефона.");
                return;
            }
            if (!$plugin->takePhoneBalance($player->getName(), (float)$smsPrice)) {
                $player->sendMessage("§8§l[§cОшибка§8] §r§fНедостаточно средств. Нужно §e" . $smsPrice . "р.");
                return;
            }

            $plugin->addSmsMessage($targetName, $player->getName(), $message);

            $targetPlayer = $plugin->getServer()->getPlayerByPrefix($targetInput);
            if ($targetPlayer !== null) {
                $targetPlayer->sendMessage("§8§l[§9СМС§8] §r§fОт §b" . $player->getName() . "§f: §7\"" . $message . "\"");
            }

            $player->sendMessage("§8§l[§aСМС§8] §r§fОтправлено §b" . $targetName . "§f. Списано §e" . $smsPrice . "р.");
        });

        $form->setTitle("§l§8[ §9Написать §8]");
        $form->addLabel(
            "§e§l--- Отправка СМС ---§r\n\n" .
            "§b§l> §fЦена: §e" . $smsPrice . "р.§r\n\n" .
            "§7Можно ввести часть ника.§r"
        );
        $form->addInput("§fНик получателя:", "Часть ника");
        $form->addInput("§fСообщение:", "Текст...");

        $player->sendForm($form);
    }

    public static function openSmsInboxForm(Player $player): void {
        $plugin = Main::getInstance();
        $inbox = $plugin->getSmsInbox($player->getName());

        if (empty($inbox)) {
            $player->sendMessage("§8§l[§9СМС§8] §r§7Входящих нет.");
            return;
        }

        $recent = array_slice(array_reverse($inbox), 0, 15);
        $content = "§e§l--- Входящие ---§r\n\n";

        foreach ($recent as $msg) {
            $timeStr = date("d.m H:i", $msg["time"]);
            $readMark = ($msg["read"] ?? false) ? "§7" : "§a§l";
            $content .= $readMark . "От: §b" . $msg["from"] . " §8[" . $timeStr . "]§r\n";
            $content .= "§7\"" . $msg["message"] . "\"§r\n\n";
        }

        if (count($inbox) > 15) {
            $content .= "§8Показано 15 из " . count($inbox) . "§r\n";
        }

        $plugin->markAllSmsRead($player->getName());

        $form = new SimpleForm(function(Player $player, ?int $data) {});
        $form->setTitle("§l§8[ §9Входящие §8]");
        $form->setContent($content);
        $form->addButton("§l§cЗакрыть");

        $player->sendForm($form);
    }
}