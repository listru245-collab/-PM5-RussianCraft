<?php

declare(strict_types=1);

namespace InzeOwr\RcWeapons;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerItemUseEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\player\Player;
use pocketmine\item\Item;
use pocketmine\item\StringToItemParser;
use pocketmine\utils\Config;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\math\Vector3;
use pocketmine\scheduler\ClosureTask;

class Main extends PluginBase implements Listener {

    /** @var array */
    private array $weapons = [];
    
    /** @var array */
    private array $playerCooldown = [];

    public function onEnable(): void {
        $this->saveDefaultConfig();
        $this->loadWeapons();
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
        $this->getLogger()->info("§aRcWeapons успешно загружен!");
        $this->getLogger()->info("§eЗагружено оружия: §b" . count($this->weapons));
    }

    public function onDisable(): void {
        $this->getLogger()->info("§cRcWeapons выгружен!");
    }

    /**
     * Загрузка всех оружий из папки weapons/
     */
    private function loadWeapons(): void {
        $weaponsPath = $this->getDataFolder() . "weapons/";
        
        if (!is_dir($weaponsPath)) {
            mkdir($weaponsPath, 0755, true);
            $this->saveResource("weapons/toz34.yml");
        }

        $files = glob($weaponsPath . "*.yml");
        
        if (empty($files)) {
            $this->getLogger()->warning("§eНет конфигов оружия! Создайте файлы в папке weapons/");
            return;
        }

        foreach ($files as $file) {
            $config = new Config($file, Config::YAML);
            $data = $config->getAll();
            
            if (isset($data["id"])) {
                $this->weapons[$data["id"]] = $data;
                $this->getLogger()->info("§a✔ Загружено: §f" . $data["id"] . " §7(" . ($data["display_name"] ?? $data["id"]) . ")");
            } else {
                $this->getLogger()->error("§c✖ Ошибка в файле: " . basename($file) . " (нет поля 'id')");
            }
        }
    }

    /**
     * Получить конфиг оружия по ID
     */
    public function getWeapon(string $id): ?array {
        return $this->weapons[$id] ?? null;
    }

    /**
     * Получить все оружия
     */
    public function getWeapons(): array {
        return $this->weapons;
    }

    /**
     * Проверка - является ли предмет оружием
     */
    public function isWeapon(Item $item): ?array {
        $tag = $item->getNamedTag();
        
        if ($tag->getTag("rcweapon_id") !== null) {
            $weaponId = $tag->getString("rcweapon_id");
            return $this->getWeapon($weaponId);
        }
        
        return null;
    }

    /**
     * Создание предмета оружия
     */
    public function createWeaponItem(string $weaponId): ?Item {
        $weapon = $this->getWeapon($weaponId);
        
        if ($weapon === null) {
            return null;
        }

        // Базовый предмет (по умолчанию железная мотыга)
        $baseItemId = $weapon["base_item"] ?? "iron_hoe";
        $item = StringToItemParser::getInstance()->parse($baseItemId);
        
        if ($item === null) {
            $this->getLogger()->error("§cНеизвестный базовый предмет: " . $baseItemId);
            return null;
        }

        // Устанавливаем название
        $displayName = $weapon["display_name"] ?? $weaponId;
        $item->setCustomName("§r§l§6" . $displayName);
        
        // Устанавливаем лор
        $maxAmmo = $weapon["stats"]["magazine"] ?? 30;
        $lore = [
            "§r§7▪ Урон: §c" . ($weapon["stats"]["damage"] ?? 10),
            "§r§7▪ Магазин: §e" . $maxAmmo,
            "§r§7▪ Скорострельность: §b" . ($weapon["stats"]["fire_rate"] ?? 1.0) . "s",
            "§r§7▪ Дальность: §a" . ($weapon["stats"]["range"] ?? 50) . " блоков",
            "",
            "§r§aПКМ §7- Стрелять",
            "§r§eShift + ПКМ §7- Перезарядка"
        ];
        $item->setLore($lore);

        // NBT данные
        $tag = $item->getNamedTag();
        $tag->setString("rcweapon_id", $weaponId);
        $tag->setInt("rcweapon_ammo", $maxAmmo);
        $tag->setInt("rcweapon_max_ammo", $maxAmmo);
        $item->setNamedTag($tag);

        return $item;
    }

    /**
     * Выстрел
     */
    public function shoot(Player $player, array $weapon): void {
        $item = $player->getInventory()->getItemInHand();
        $tag = $item->getNamedTag();
        
        $ammo = $tag->getInt("rcweapon_ammo", 0);
        
        // Проверка наличия патронов
        if ($ammo <= 0) {
            $player->sendTip("§c✖ Нет патронов! Перезарядите §e[Shift + ПКМ]");
            return;
        }

        // Проверка кулдауна (скорострельность)
        $weaponId = $weapon["id"];
        $fireRate = $weapon["stats"]["fire_rate"] ?? 1.0;
        $now = microtime(true);
        
        $lastShot = $this->playerCooldown[$player->getName()][$weaponId] ?? 0;
        
        if ($now - $lastShot < $fireRate) {
            return; // Слишком быстро
        }
        
        $this->playerCooldown[$player->getName()][$weaponId] = $now;

        // Расход патрона
        $ammo--;
        $tag->setInt("rcweapon_ammo", $ammo);
        $item->setNamedTag($tag);
        $player->getInventory()->setItemInHand($item);

        // Параметры оружия
        $damage = $weapon["stats"]["damage"] ?? 10;
        $range = $weapon["stats"]["range"] ?? 50;
        $spread = $weapon["stats"]["spread"] ?? 0.0;
        $pellets = $weapon["stats"]["pellets"] ?? 1; // Для дробовиков

        // Рейкаст для каждой дробинки/пули
        for ($i = 0; $i < $pellets; $i++) {
            $this->fireRaycast($player, $damage, $range, $spread);
        }

        // UI патронов
        $maxAmmo = $tag->getInt("rcweapon_max_ammo", 30);
        $player->sendTip("§f⌇ §e" . $ammo . " §7/ §a" . $maxAmmo);
        
        $this->getLogger()->debug($player->getName() . " выстрелил из " . $weaponId . " (" . $ammo . "/" . $maxAmmo . ")");
    }

    /**
     * Рейкаст для определения попадания
     */
    private function fireRaycast(Player $player, float $damage, float $range, float $spread): void {
        $start = $player->getEyePos();
        $direction = $player->getDirectionVector();
        
        // Добавляем разброс
        if ($spread > 0) {
            $spreadFactor = $spread / 10;
            $direction = $direction->add(
                (lcg_value() - 0.5) * $spreadFactor,
                (lcg_value() - 0.5) * $spreadFactor,
                (lcg_value() - 0.5) * $spreadFactor
            )->normalize();
        }

        $end = $start->addVector($direction->multiply($range));

        // Ищем попадание в сущности
        $hitEntity = null;
        $closestDistance = $range;

        foreach ($player->getWorld()->getNearbyEntities($player->getBoundingBox()->expandedCopy($range, $range, $range)) as $entity) {
            if ($entity === $player) {
                continue;
            }

            $entityPos = $entity->getPosition()->add(0, $entity->getSize()->getHeight() / 2, 0);
            
            // Вектор к сущности
            $toEntity = $entityPos->subtractVector($start);
            $dot = $toEntity->dot($direction);
            
            // Проверяем, находится ли сущность в направлении выстрела
            if ($dot > 0 && $dot < $range) {
                $closest = $start->addVector($direction->multiply($dot));
                $distance = $closest->distance($entityPos);
                
                // Проверяем попадание (хитбокс ~1.5 блока)
                if ($distance < 1.5 && $dot < $closestDistance) {
                    $hitEntity = $entity;
                    $closestDistance = $dot;
                }
            }
        }

        // Если попали - наносим урон
        if ($hitEntity !== null) {
            $event = new EntityDamageByEntityEvent(
                $player,
                $hitEntity,
                EntityDamageEvent::CAUSE_PROJECTILE,
                $damage
            );
            $hitEntity->attack($event);
            
            $this->getLogger()->debug($player->getName() . " попал в " . $hitEntity->getName() . " (урон: " . $damage . ")");
        }
    }

    /**
     * Перезарядка
     */
    public function reload(Player $player, array $weapon): void {
        $item = $player->getInventory()->getItemInHand();
        $tag = $item->getNamedTag();
        
        $maxAmmo = $tag->getInt("rcweapon_max_ammo", 30);
        $currentAmmo = $tag->getInt("rcweapon_ammo", 0);
        
        // Проверка - уже полный магазин
        if ($currentAmmo >= $maxAmmo) {
            $player->sendTip("§e✔ Магазин полон!");
            return;
        }

        $reloadTime = $weapon["stats"]["reload_time"] ?? 2.0;
        
        $player->sendTip("§b⟳ Перезарядка... §7(" . $reloadTime . "s)");
        $this->getLogger()->debug($player->getName() . " начал перезарядку " . $weapon["id"]);
        
        // Задержка перезарядки
        $this->getScheduler()->scheduleDelayedTask(
            new ClosureTask(function() use ($player, $weapon, $maxAmmo): void {
                if (!$player->isOnline()) {
                    return;
                }
                
                $currentItem = $player->getInventory()->getItemInHand();
                $tag = $currentItem->getNamedTag();
                
                // Проверяем, что игрок все еще держит это оружие
                if ($tag->getTag("rcweapon_id") !== null && $tag->getString("rcweapon_id") === $weapon["id"]) {
                    $tag->setInt("rcweapon_ammo", $maxAmmo);
                    $currentItem->setNamedTag($tag);
                    $player->getInventory()->setItemInHand($currentItem);
                    $player->sendTip("§a✔ Перезаряжено! §f⌇ §e" . $maxAmmo . " §7/ §a" . $maxAmmo);
                    
                    $this->getLogger()->debug($player->getName() . " завершил перезарядку " . $weapon["id"]);
                }
            }),
            (int)($reloadTime * 20) // Тики (20 тиков = 1 секунда)
        );
    }

    /**
     * Обработка использования предмета
     */
    public function onItemUse(PlayerItemUseEvent $event): void {
        $player = $event->getPlayer();
        $item = $event->getItem();
        
        $weapon = $this->isWeapon($item);
        
        if ($weapon !== null) {
            $event->cancel();
            
            if ($player->isSneaking()) {
                // Shift + ПКМ = Перезарядка
                $this->reload($player, $weapon);
            } else {
                // ПКМ = Выстрел
                $this->shoot($player, $weapon);
            }
        }
    }

    /**
     * Команды плагина
     */
    public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool {
        if ($command->getName() === "rcweapons") {
            
            if (!isset($args[0])) {
                $sender->sendMessage("§6=== §lRcWeapons §r§6Команды ===");
                $sender->sendMessage("§e/rcweapons give <игрок> <оружие> §7- Выдать оружие");
                $sender->sendMessage("§e/rcweapons list §7- Список оружия");
                $sender->sendMessage("§e/rcweapons reload §7- Перезагрузить конфиги");
                return true;
            }

            switch (strtolower($args[0])) {
                
                case "give":
                    // ✅ ИСПРАВЛЕННАЯ ПРОВЕРКА НА OP
                    if ($sender instanceof Player && !$this->getServer()->isOp($sender->getName())) {
                        $sender->sendMessage("§c✖ Эта команда только для администраторов!");
                        return true;
                    }
                    
                    if (!isset($args[1], $args[2])) {
                        $sender->sendMessage("§cИспользование: §e/rcweapons give <игрок> <оружие>");
                        $sender->sendMessage("§7Пример: §f/rcweapons give Steve toz34");
                        return true;
                    }
                    
                    $target = $this->getServer()->getPlayerByPrefix($args[1]);
                    
                    if ($target === null) {
                        $sender->sendMessage("§c✖ Игрок §e" . $args[1] . " §cне найден или не в сети!");
                        return true;
                    }
                    
                    $weaponId = strtolower($args[2]);
                    $weaponItem = $this->createWeaponItem($weaponId);
                    
                    if ($weaponItem === null) {
                        $sender->sendMessage("§c✖ Оружие §e" . $weaponId . " §cне найдено!");
                        $sender->sendMessage("§7Доступные: §f" . implode("§7, §f", array_keys($this->weapons)));
                        return true;
                    }
                    
                    $target->getInventory()->addItem($weaponItem);
                    
                    $weaponName = $this->weapons[$weaponId]["display_name"] ?? $weaponId;
                    $sender->sendMessage("§a✔ Выдано оружие §e" . $weaponName . " §aигроку §e" . $target->getName());
                    $target->sendMessage("§a✔ Вы получили оружие: §e" . $weaponName);
                    
                    $this->getLogger()->info($sender->getName() . " выдал оружие " . $weaponId . " игроку " . $target->getName());
                    break;

                case "list":
                    if (empty($this->weapons)) {
                        $sender->sendMessage("§c✖ Нет загруженного оружия!");
                        $sender->sendMessage("§7Создайте файлы в папке §fplugin_data/RcWeapons/weapons/");
                        return true;
                    }
                    
                    $sender->sendMessage("§6=== §lДоступное оружие §r§7(" . count($this->weapons) . ") §6===");
                    foreach ($this->weapons as $id => $data) {
                        $displayName = $data["display_name"] ?? $id;
                        $damage = $data["stats"]["damage"] ?? "?";
                        $magazine = $data["stats"]["magazine"] ?? "?";
                        $sender->sendMessage("§e• §f" . $id . " §7(" . $displayName . ")");
                        $sender->sendMessage("  §8├ §cУрон: " . $damage . " §8| §eПатроны: " . $magazine);
                    }
                    break;

                case "reload":
                    // ✅ ИСПРАВЛЕННАЯ ПРОВЕРКА НА OP
                    if ($sender instanceof Player && !$this->getServer()->isOp($sender->getName())) {
                        $sender->sendMessage("§c✖ Эта команда только для администраторов!");
                        return true;
                    }
                    
                    $sender->sendMessage("§e⟳ Перезагрузка конфигов оружия...");
                    
                    $oldCount = count($this->weapons);
                    $this->weapons = [];
                    $this->loadWeapons();
                    $newCount = count($this->weapons);
                    
                    $sender->sendMessage("§a✔ Конфиги перезагружены!");
                    $sender->sendMessage("§7Было: §e" . $oldCount . " §7| Стало: §e" . $newCount);
                    
                    $this->getLogger()->info($sender->getName() . " перезагрузил конфиги оружия");
                    break;

                default:
                    $sender->sendMessage("§c✖ Неизвестная подкоманда: §e" . $args[0]);
                    $sender->sendMessage("§7Используйте §e/rcweapons §7для списка команд");
                    break;
            }
            
            return true;
        }
        
        return false;
    }
}
